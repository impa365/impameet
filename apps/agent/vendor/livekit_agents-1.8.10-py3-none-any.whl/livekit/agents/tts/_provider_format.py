"""Shared provider-specific TTS formatting logic.

Both TTS plugins and the inference gateway delegate to this module so
there is a single source of truth for LLM instructions and markup stripping
per provider.

Provider docs:
- Cartesia: https://docs.cartesia.ai/build-with-cartesia/sonic-3/ssml-tags
- Cartesia: https://docs.cartesia.ai/build-with-cartesia/sonic-3/volume-speed-emotion
- Inworld: https://docs.inworld.ai/tts/capabilities/steering
- Inworld: https://docs.inworld.ai/tts/best-practices/prompting-for-tts-2
- xAI: https://docs.x.ai/developers/model-capabilities/audio/text-to-speech
- xAI: https://docs.x.ai/developers/model-capabilities/audio/voice
- Fish Audio: https://docs.fish.audio/developer-guide/core-features/emotions
- Fish Audio: https://docs.fish.audio/features/text-to-speech/drama-3
"""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, TypedDict

from ..types import ATTRIBUTE_TRANSCRIPTION_EXPRESSION, TimedString
from ._mood import match_mood
from .markup_utils import (
    LEADING_WS,
    _dedup_removal_space,
    _strip_one,
    convert_expression_tags,
    extract_and_strip,
)


class ExpressiveTag(TypedDict):
    """An expressive markup tag stripped from a transcript, surfaced for the frontend.

    ``type`` is the markup tag name (``"emotion"``, ``"expression"``, ``"sound"``, ...) or
    the expr marker type. ``value`` is the spoken or semantic payload (the ``value="..."``
    attribute, the expr ``label``, or the tag's inner text).
    """

    type: str
    value: str


if TYPE_CHECKING:
    from .. import tokenize
    from ..voice.agent_session import SpeechSteeringOptions

_CARTESIA_TAGS = ["emotion", "speed", "volume", "break", "spell"]


_INWORLD_TAGS = ["expression", "sound", "break"]


# xAI Grok TTS speech tags, from the xAI docs
# (https://docs.x.ai/developers/rest-api-reference/inference/voice).
#
# The LLM is instructed in the expr dialect (below); these native tag names serve two
# purposes: _XAI_WRAPPING is the label vocabulary expr prosody markers lower to, and all
# of them stay in _XAI_TAGS so a hallucinated native tag is still stripped from the
# transcript rather than leaking. The intermediate <sound value="NAME"/> and
# <break time="..."/> tags that expr lowering produces are rewritten to xAI's native
# brackets by convert_markup — <sound value="X"/> -> [X] and <break> -> [pause] or
# [long-pause] by duration. Prosody is angle-bracketed (native).
_XAI_EMOTIONS = [
    "happy",
    "sad",
    "angry",
    "excited",
    "calm",
    "surprised",
    "sympathetic",
    "curious",
    "sarcastic",
    "confident",
    "playful",
    "nervous",
]
_XAI_INLINE = [
    "breath",
    "inhale",
    "exhale",
    "sigh",
    "laugh",
    "chuckle",
    "giggle",
    "cry",
    "tsk",
    "tongue-click",
    "lip-smack",
    "hum-tune",
]
_XAI_WRAPPING = [
    "emphasis",  # stress the wrapped words
    "whisper",  # quiet, intimate
    "soft",  # lower volume
    "loud",  # higher volume
    "build-intensity",  # ramp energy up over the span
    "decrease-intensity",  # ease energy off over the span
    "higher-pitch",
    "lower-pitch",
    "slow",
    "fast",
    "sing-song",  # playful, musical lilt
    "singing",  # actually sung
    "laugh-speak",  # talk through a laugh
]
# all tags are XML in the transcript, so all are stripped. inline sounds are the single
# "sound" tag (<sound value="NAME"/>, _XAI_INLINE lists the NAMEs), and pauses use
# "break" (<break time="..."/>), both modeled on Inworld.
_XAI_TAGS = _XAI_EMOTIONS + _XAI_WRAPPING + ["sound", "break"]

# xAI has two pause levels ([pause], [long-pause]); map an Inworld-style <break time="X"/>
# to the longer one past ~1s. This is the only per-provider bit convert_markup needs.
_XAI_BREAK_RE = re.compile(r'<break\s+time="([^"]*)"\s*/?>')


def _xai_break_to_bracket(match: re.Match[str]) -> str:
    raw = match.group(1).strip().lower()
    try:
        secs = float(raw[:-2]) / 1000 if raw.endswith("ms") else float(raw.rstrip("s"))
    except ValueError:
        secs = 0.0
    return "[long-pause]" if secs >= 1.0 else "[pause]"


# Fish Audio (s2 family) speech markers, from the Fish docs
# (https://docs.fish.audio/developer-guide/core-features/emotions).
#
# The LLM is instructed in the expr dialect (below); expr lowering produces the
# framework-standard intermediates (<expression value="..."/>, <sound value="..."/>,
# <break time="..."/>, <emphasis>word</emphasis>) and convert_markup rewrites them to
# Fish's native square brackets: [very EMOTION], [SOUND], [break]/[long-break], and
# [emphasis] word (a prefix marker stressing the word that follows). Tone wrapping
# (<expr type="prosody" label="whispering">...</expr>) lowers directly to Fish's prefix
# form, [whispering] followed by the span. The tag names stay in _FISHAUDIO_TAGS so
# hallucinated native markup is still stripped from transcripts.
#
# Every label below is from Fish's documented vocabulary, and every emotion maps to a
# non-fallback mood in _mood.py so lk.expression stays meaningful for clients.
_FISHAUDIO_EMOTIONS = [
    "regretful",
    "hopeful",
    "happy",
    "excited",
    "curious",
    "surprised",
    "sad",
    "empathetic",
    "sarcastic",
    "calm",
    "angry",
    "worried",
    "nervous",
    "confident",
    "grateful",
    "delighted",
    "disappointed",
    "frustrated",
    "determined",
]
_FISHAUDIO_SOUNDS = [
    "laughing",
    "chuckling",
    "clear throat",
    "sighing",
    "gasping",
    "groaning",
    "yawning",
    "sobbing",
]
# Fish's tone controls: prefix markers steering the delivery of the words after them.
# Neutral delivery styles, so they are never steering-filtered (same stance as xAI's
# whisper/pitch wraps).
_FISHAUDIO_TONES = ["whispering", "soft", "shouting", "hurried"]
_FISHAUDIO_TAGS = ["expression", "sound", "break", "emphasis"]

_FISHAUDIO_EXPRESSION_RE = re.compile(
    r'<expression\s+value="([^"]*)"(?:\s*/>|>(?:.*?)</expression>)'
)
_FISHAUDIO_BREAK_RE = re.compile(r'<break\s+time="([^"]*)"\s*/?>')
_FISHAUDIO_EMPHASIS_RE = re.compile(r"<emphasis(?:\s[^>]*)?>([^<]*)</emphasis\s*>", re.IGNORECASE)


def _fishaudio_expression_to_bracket(match: re.Match[str]) -> str:
    # intensify with a leading "very" so the emotion lands harder in Fish's audio
    # ([very regretful] steers more strongly than [regretful]); never doubled
    value = match.group(1).strip()
    if value and not value.lower().startswith("very "):
        value = f"very {value}"
    return f"[{value}]"


def _fishaudio_break_to_bracket(match: re.Match[str]) -> str:
    # Fish has two pause levels ([break], [long-break]); use the longer past ~1s
    raw = match.group(1).strip().lower()
    try:
        secs = float(raw[:-2]) / 1000 if raw.endswith("ms") else float(raw.rstrip("s"))
    except ValueError:
        secs = 0.0
    return "[long-break]" if secs >= 1.0 else "[break]"


# Fish Audio drama-3 reads the same square brackets but follows them as free-form
# direction ([a little sheepish, apologetic]), so it gets its own key and block instead
# of the fixed emotion list, and its labels lower verbatim with no "very". Its tone
# controls are paired tags that change only the words they wrap, so prosody lowers to
# <whisper>...</whisper> rather than a prefix marker. Sounds are shared with s2.
_FISHAUDIO_DRAMA_SPANS = ["whisper", "soft", "slow", "fast", "emphasis"]
# stress/forceful are never taught, but listed so a stray one is still stripped
_FISHAUDIO_DRAMA_TAGS = [
    "expression",
    "sound",
    "break",
    *_FISHAUDIO_DRAMA_SPANS,
    "stress",
    "forceful",
]
# s2 tone labels, left in history by a mid-session model switch
_FISHAUDIO_DRAMA_SPAN_ALIASES = {"whispering": "whisper", "hurried": "fast"}


def _fishaudio_drama_break_to_bracket(match: re.Match[str]) -> str:
    # drama-3 takes free-text pause cues where they happen; [long pause] can stall for
    # many seconds, so the longer level is a plain [pause]
    raw = match.group(1).strip().lower()
    try:
        secs = float(raw[:-2]) / 1000 if raw.endswith("ms") else float(raw.rstrip("s"))
    except ValueError:
        secs = 0.0
    return "[pause]" if secs >= 1.0 else "[short pause]"


# Gemini TTS (the 3.8 family), from Gemini's controllable speech
# generation docs (https://ai.google.dev/gemini-api/docs/speech-generation#controllable).
#
# Direction is split across two channels, so the expr dialect lowers onto both.
# Sustained direction rides ``speech_metadata.style`` beside the words; a discrete vocal
# event is an inline tag where it happens::
#
#     {"parts": [{"text": "\"<chuckle> What's on your mind?\"",
#                 "speech_metadata": {"style": "Wistful, British accent"}}]}
#
# So an <expr type="expression"/> marker is not lowered at all — convert_markup leaves it
# for the plugin to lift out — while sound, break and emphasis lower to the inline tags.
# The native names stay in _GEMINI_TAGS so a hallucinated one is stripped from transcripts.
# Style labels are free-form natural language, not a closed set.
# square brackets work too, but the docs measured angle brackets as more reliable
_GEMINI_SOUNDS = [
    # the model's own documented list
    "laugh",
    "chuckle",
    "sigh",
    "breath",
    "cough",
    "argh",
    # named by the general TTS docs, which also warn there is no exhaustive list; the
    # rest of what they name (amazed, curious, sarcastic, whispers, ...) is sustained
    # delivery, and belongs in the style field rather than inline
    "gasp",
    "giggle",
    "cry",
]
# Gemini documents one pause length, so every break duration lowers to the same tag
_GEMINI_PAUSE = "short pause"
_GEMINI_TAGS = [*_GEMINI_SOUNDS, _GEMINI_PAUSE]

# expr labels that differ from Gemini's native tag names
_GEMINI_SOUND_ALIASES = {
    "breathe": "breath",
    "laughing": "laugh",
    "laughs": "laugh",
    "chuckling": "chuckle",
    "sighing": "sigh",
    "sighs": "sigh",
    "groan": "argh",
    "groaning": "argh",
    "giggles": "giggle",
    "giggling": "giggle",
    "gasping": "gasp",
    "crying": "cry",
    "sob": "cry",
    "sobbing": "cry",
}


# --- LiveKit expression markers (expr) ---
# The LLM emits a single marker tag,
# <expr type="..." label="..."/>, instead of provider-native tags. The *syntax* is shared,
# but each provider gets its own instruction block advertising only the types and label
# vocabularies it actually supports — providers offer different sound effects, some take
# only a discrete emotion vocabulary rather than free-form delivery descriptions, and
# only some have wrapping prosody. Types (per provider):
#   expression (self-closing) - delivery/emotion for what follows; free-form for
#                               Inworld, Cartesia's discrete emotion vocabulary, absent
#                               for xAI
#   break      (self-closing) - pause, label is a duration ("500ms", "1s"); all providers
#   sound      (self-closing) - non-verbal vocalization from the provider's own list
#                               (Inworld: laugh/sigh/..., xAI: chuckle/tsk/...); absent
#                               for Cartesia
#   prosody    (wrapping)     - <expr type="prosody" label="whisper">words</expr>, labels
#                               from xAI's wrapping-tag list; for Cartesia a self-closing
#                               point control (slow/fast/soft/loud -> coarse speed/volume
#                               ratios); absent for Inworld (folded into expression)
#   spell      (wrapping)     - <expr type="spell">A7X9</expr> character-by-character
#                               readout; Cartesia only
# convert_markup lowers expr to each provider's native syntax before synthesis (via the
# existing framework-standard tags, so the per-provider conversions below still apply),
# and the transcript strippers remove expr markers in a dedicated pre-pass so the
# type/label pair surfaces correctly as an ExpressiveTag. This is the only dialect the
# LLM is taught — llm_instructions() uses it; the provider-native tag tables remain
# solely so hallucinated native markup is still stripped/converted instead of leaking.

_EXPR_PREAMBLE = """\
You control speech delivery with a single XML marker tag: <expr/>. Every marker has a \
type attribute. Use only the marker types listed below, and where a type lists a label \
vocabulary, only those labels. Use the markers often and diversify them so the voice \
never sounds flat while ensuring the markers are appropriate for the moment. Write the \
words themselves the way people talk: use contractions ("I'm", "you're", "don't") — \
spelled-out forms like "I am" or "do not" sound stiff when spoken.

Just as important is knowing when NOT to reach for a marker. Reserve surprise openers \
like "oh" or "ah" for genuine surprise — an ordinary request isn't one. Don't stack markers \
on short replies or decorate every sentence. If a reaction wouldn't happen in a real \
conversation, skip it — there's always another genuine beat to lean into.

Match your delivery to the REGISTER of the moment, and reassess every turn. When the \
moment is professional, high-stakes, or emotionally heavy — bad news, an emergency, \
real distress — keep delivery composed and restrained. When the moment is casual, \
playful, or celebratory, let it loosen and brighten. A serious turn in an otherwise \
casual conversation still gets a composed reply."""

_CARTESIA_EXPR_LLM_INSTRUCTIONS = (
    _EXPR_PREAMBLE
    + """

1. Emotion - sets the emotional tone. Self-closing; place before EVERY sentence.
   <expr type="expression" label="EMOTION"/>
   Labels are a fixed vocabulary, NOT free-form descriptions. Best results: neutral, \
angry, excited, content, sad, scared.
   Also available: happy, enthusiastic, elated, triumphant, amazed, surprised, \
flirtatious, curious, peaceful, serene, calm, grateful, affectionate, sympathetic, \
mysterious, frustrated, disgusted, sarcastic, ironic, dejected, melancholic, \
disappointed, apologetic, hesitant, confused, anxious, panicked, proud, confident, \
contemplative, determined, joking/comedic.

2. Pauses - insert silence when appropriate. Self-closing.
   <expr type="break" label="1s"/> - label is a duration in seconds or milliseconds.

3. Prosody - adjusts pacing and loudness from that point on. Self-closing.
   <expr type="prosody" label="slow"/> slower    <expr type="prosody" label="fast"/> faster
   <expr type="prosody" label="soft"/> quieter    <expr type="prosody" label="loud"/> louder
   Labels are a fixed vocabulary: slow, fast, soft, loud.

4. Spell - wraps text read character by character (codes, IDs, or a spelled-out name).
   <expr type="spell">A7X9</expr>
   Keep punctuation out of a spell marker — a period inside is read as "dot"; add \
spaces inside for grouped pauses (<expr type="spell">ABC 123</expr>).

This voice has no non-verbal sounds and no free-form delivery descriptions — do not \
invent other types or labels.

Examples:
  <expr type="expression" label="excited"/> I can't wait to tell you! <expr type="expression" label="happy"/> This is going to be great!
  <expr type="expression" label="curious"/> Really? <expr type="break" label="500ms"/> <expr type="expression" label="excited"/> Tell me more!
  Your code is <expr type="spell">A7X9</expr>. <expr type="break" label="1s"/> <expr type="expression" label="calm"/> Got it?"""
)

_INWORLD_SOUNDS = ["laugh", "sigh", "breathe", "clear throat", "cough", "yawn"]

_INWORLD_EXAMPLES = [
    '<expr type="expression" label="say really playfully"/> Okay okay, why did the burger go to the gym? <expr type="break" label="500ms"/> <expr type="expression" label="really bright, a little fast"/> Because it wanted better buns! <expr type="sound" label="laugh"/>',  # noqa: E501
    '<expr type="expression" label="a little sheepish, apologetic"/> Ah man, yeah that\'s on us. <expr type="expression" label="speak really calmly"/> Lemme see what I can do.',  # noqa: E501
    '<expr type="sound" label="sigh"/> <expr type="expression" label="speak softly, almost a whisper"/> I know it\'s been a rough week.',  # noqa: E501
    '<expr type="expression" label="really amiable and welcoming"/> Welcome to the hotel. <expr type="expression" label="gently inquisitive, slightly fast"/> How can I help you today?',  # noqa: E501
    '<expr type="expression" label="gently easygoing and reassuring"/> That\'s all set. <expr type="break" label="300ms"/> <expr type="expression" label="slow and really clearly enunciated"/> Your confirmation code is B 4 J 7.',  # noqa: E501
    # persona carried into the tags: casual words, casual labels
    '<expr type="expression" label="really chill, a little fast"/> Yeah, of course! <expr type="expression" label="casual, almost fast"/> Gimme one sec, pulling it up now.',  # noqa: E501
]


def _sound_examples(examples: list[str], allowed: list[str], vocabulary: list[str]) -> list[str]:
    """Drop example lines that demonstrate a *vocabulary* label not in *allowed*."""
    removed = [s for s in vocabulary if s not in allowed]
    return [ex for ex in examples if not any(f'label="{s}"' in ex for s in removed)]


def _numbered_sections(sections: list[str]) -> str:
    return "\n\n".join(f"{i}. {section}" for i, section in enumerate(sections, 1))


def _inworld_expr_llm_instructions(sounds: list[str]) -> str:
    sections = [
        """Delivery - controls how a sentence sounds. Self-closing; place before EVERY sentence.
   <expr type="expression" label="DESCRIPTION"/>
   The label is free-form: describe vocal quality, pitch, volume, pace, and intonation \
in plain English — "say really playfully", "slightly surprised, amiable", "sound a little \
concerned", "drop to almost a whisper", "speak really slowly and clearly, patient and \
reassuring".
   Match the expression tag's energy to the sentence's punctuation. An exclamation \
needs a bright or upbeat label (e.g. "bright, upbeat energy"); a calm or reassuring \
label flattens the "!". Never lead an exclamatory sentence with a calm tag.
   Put each question in its own sentence — don't comma-splice it onto a statement. \
Write "Welcome to the hotel. How can I help you today?", not "Welcome to the hotel, \
how can I help you today?", so the question carries its own delivery tag instead of \
inheriting the statement's.
   Never put "questioning" in a tag — describe the mood alone and let the question \
mark carry the intonation.
   Name a mood or speaking style, not a mechanical pitch contour. "gently upbeat, \
amiable" steers far more reliably than "rising tone".
   Use at most two adjectives per tag, and make sure they align — with the mood of \
the sentence and with each other. Clashing descriptors ("calm, excited") cancel out \
and muddy the delivery.
   Put a degree modifier in EVERY tag — "a little", "almost", "slightly", "gently", \
"really" — to set the exact strength of the feeling: "a little amused" or "almost a \
whisper" lands truer than "amused" or "whisper", and "really excited" turns the \
delivery up when the moment truly peaks. Most moments call for a shade, not the \
extreme — default to the softeners and save "really" for true peaks.
   Carry your persona into the tags — the labels should sound like the character, \
not generic stage directions. An amiable, casual persona tags with "really relaxed \
and amiable" or "casual, a little playful"; a formal concierge tags the same \
sentence "gently courteous, composed". Delivery that contradicts who you are reads \
as a different speaker.
   Don't open a turn with a "slow" tag. The first expression colors the whole turn, \
and a slow lead flattens questions and drags the energy down. Keep the pace neutral \
by default and reserve slow, clearly-enunciated delivery for the specific line that \
needs it (a total, date, address, or confirmation code).
   Rotate expression labels — don't reuse the same one two turns in a row, and vary \
the descriptor. A starting palette:
     greeting / amiable open: "really amiable and welcoming" / "gently bright, \
heartfelt" / "cheerful, really glad you called"
     asking a question: "gently upbeat and amiable" / "really open and inquisitive" / \
"gently inquisitive, attentive"
     good news / exclamation: "really bright, upbeat energy" / "really delighted and \
glad" / "gently pleased and bright"
     reassuring / taking a request in stride: "really calm and confident" / \
"gently easygoing and reassuring" / "really relaxed and grounded"
     empathy / a problem or bad news: "really soft, with tender care" / \
"gently concerned, caring" / "almost a murmur, gentle and steady"
     reading back a total, date, or code: "slow and really clearly enunciated\""""
    ]
    if sounds:
        fits = " (a clear-throat when shifting to a new step or topic, for example)"
        section = f"""Sounds - a non-verbal sound between sentences. Self-closing.
   <expr type="sound" label="{sounds[0]}"/>
   Labels are a fixed vocabulary: {", ".join(sounds)}.
   Use non-verbal sounds sparingly, and never the same one twice in a row — reach for \
one only where it genuinely fits{fits if "clear throat" in sounds else ""}. An enabled \
sound gets over-used otherwise."""
        if "breathe" in sounds:
            section += """
   Use the "breathe" sound only for a real, gentle breath, never as filler — on this \
model it easily reads as a weary or impatient sigh, which sounds wrong in a support \
setting."""
        sections.append(section)
    sections.append(
        """Pauses - insert silence when appropriate. Self-closing.
   <expr type="break" label="500ms"/> or <expr type="break" label="1s"/> (max 10s).
   A period or an ellipsis (...) already creates a pause, so don't put a break marker \
right next to one — pick one or the other.
   After any <expr type="break"/>, give the sentence that follows its own expression \
tag — a fresh one, not necessarily the same as before (a break is often where the mood \
shifts). A break resets delivery to neutral, so an untagged sentence after a break is \
spoken flat."""
    )

    parts = [
        _EXPR_PREAMBLE,
        _numbered_sections(sections),
        "There is no wrapping prosody marker for this voice — put pace, pitch, and volume in "
        "the expression label instead.",
        """Write for the EAR, not the page: no em or en dashes anywhere in spoken text — \
use a comma or a period for a short beat, or a break marker for a real pause. Avoid \
semicolons, mid-sentence colons, and parenthetical asides; rewrite them as separate \
sentences or commas.""",
        """When the conversation is in another language, still write every marker label in \
English — delivery descriptions and sound names steer the voice and are never \
translated.""",
    ]
    if "laugh" in sounds:
        parts.append(
            "Laughter belongs only in genuinely playful or celebratory beats, never at "
            "a serious moment."
        )
    if examples := _sound_examples(_INWORLD_EXAMPLES, sounds, _INWORLD_SOUNDS):
        parts.append("Examples:\n" + "\n".join(f"  {ex}" for ex in examples))
    return "\n\n".join(parts)


_XAI_EXAMPLES = [
    'So I walked in and <expr type="break" label="500ms"/> <expr type="sound" label="inhale"/> there it was! <expr type="prosody" label="whisper">It was a secret the whole time.</expr>',  # noqa: E501
    '<expr type="prosody" label="build-intensity">This is going to be so good.</expr> <expr type="prosody" label="loud">I can\'t wait!</expr>',  # noqa: E501
    '<expr type="prosody" label="soft">Hey.</expr> <expr type="sound" label="sigh"/> <expr type="prosody" label="lower-pitch">I know it\'s been a rough week.</expr> I\'m right here.',  # noqa: E501
    '<expr type="prosody" label="higher-pitch">You did not just say that</expr> okay, <expr type="prosody" label="fast">tell me everything.</expr>',  # noqa: E501
    # sound-free, so at least one example survives any steering filter; the break lands
    # mid-sentence before the key detail, never beside sentence punctuation
    '<expr type="prosody" label="emphasis">Everything</expr> is confirmed for <expr type="break" label="500ms"/> Thursday the <expr type="prosody" label="emphasis">ninth</expr>. <expr type="prosody" label="slow">Is there anything else I can help you with?</expr>',  # noqa: E501
]


def _xai_expr_llm_instructions(sounds: list[str], prosody: list[str]) -> str:
    sections = []
    if sounds:
        sections.append(
            f"""Sounds - a non-verbal vocalization at the exact point where it happens. Self-closing.
   <expr type="sound" label="{sounds[0]}"/>
   Labels are a fixed vocabulary: {", ".join(sounds)}.
   Use non-verbal sounds sparingly, and never the same one twice in a row — reach for \
one only where it genuinely fits. An enabled sound gets over-used otherwise."""
        )
    sections.append(
        """Pauses - insert silence when appropriate. Self-closing.
   <expr type="break" label="500ms"/> a brief pause    <expr type="break" label="1s"/> a longer, dramatic pause
   NEVER place a break next to a period, question mark, exclamation point, or ellipsis \
— sentence punctuation already pauses, and a break beside it double-pauses. Most \
replies need no break markers at all; reserve them for a deliberate mid-sentence beat \
before a key detail (a date, a name, a number)."""  # noqa: E501
    )
    tones = [p for p in prosody if p != "emphasis"]
    sections.append(
        f"""Prosody - wraps a span delivered in a distinct style, to shape HOW it's said.
   <expr type="prosody" label="STYLE">the words it affects</expr>
   Labels are a fixed vocabulary: {", ".join(tones)}.
   Use one only where the moment clearly calls for it — most sentences need none. \
Never nest one prosody marker inside another, and always close it with </expr>."""
    )
    sections.append(
        """Emphasis - stresses exactly the ONE word it wraps.
   Are you <expr type="prosody" label="emphasis">sure</expr> you want to do this?
   Wrap a single word, never a phrase, and never write it in all-caps — caps are read \
out as individual letters. Never nest it, and always close it with </expr>."""
    )

    parts = [
        _EXPR_PREAMBLE,
        _numbered_sections(sections),
        "This voice has no free-form delivery descriptions — shape delivery entirely through "
        + ("prosody markers, sounds, pauses" if sounds else "prosody markers, pauses")
        + ", punctuation, and word choice.",
        """Write for the EAR, not the page: no em or en dashes anywhere in spoken text — \
use a comma or a period for a short beat, or a break marker for a real pause. Avoid \
semicolons, mid-sentence colons, and parenthetical asides; rewrite them as separate \
sentences or commas.""",
        """When the conversation is in another language, still write every marker label in \
English — labels are a fixed vocabulary, never translated.""",
        """Key details deserve care: stress the load-bearing word of a date, amount, or \
name with the emphasis marker, and wrap a dense or easy-to-mishear span in \
<expr type="prosody" label="slow">...</expr>. Read codes and reference numbers \
character by character, spelled out with spaces, so each one lands.""",
    ]

    # Vocabulary-specific register guidance on top of the preamble's neutral rule,
    # mentioning only concepts this steering leaves enabled (whisper/soft/loud are
    # neutral delivery controls, never filtered).
    register = [
        "Whisper and soft belong to gentle or conspiratorial beats; loud only to "
        "genuinely high-energy ones."
    ]
    if any(s in sounds for s in ("laugh", "chuckle", "giggle")):
        register.append(
            "Laughter is RARE: a laugh, chuckle, or giggle belongs only where something "
            "is genuinely funny — friendliness, agreement, or mild amusement is not a "
            "reason, and never laugh at your own lines. Most replies have no laughter "
            "at all."
        )
    parts.append(" ".join(register))

    if examples := _sound_examples(_XAI_EXAMPLES, sounds + prosody, _XAI_INLINE + _XAI_WRAPPING):
        parts.append("Examples:\n" + "\n".join(f"  {ex}" for ex in examples))
    return "\n\n".join(parts)


# Examples carried over from the original Fish expressive block (PR #6232), rewritten
# in the expr dialect. Breaks appear only mid-sentence, never beside a period/?/! —
# an example pairing a break with sentence punctuation few-shots the LLM into
# double-pausing every boundary.
_FISHAUDIO_EXAMPLES = [
    '<expr type="expression" label="excited"/> That\'s hilarious! <expr type="sound" label="laughing"/> <expr type="expression" label="happy"/> You always lighten the mood.',  # noqa: E501
    '<expr type="expression" label="empathetic"/> <expr type="sound" label="clear throat"/> That sounds like a <expr type="prosody" label="emphasis">really</expr> difficult experience.',  # noqa: E501
    '<expr type="expression" label="sad"/> Oh, my goodness <expr type="sound" label="clear throat"/> <expr type="break" label="2s"/> that\'s a real shame.',  # noqa: E501
    '<expr type="expression" label="frustrated"/> <expr type="sound" label="sighing"/> I\'ve been going in circles with this all morning. <expr type="expression" label="determined"/> Okay. One more try.',  # noqa: E501
    # sound-free, so at least one example survives any steering filter
    '<expr type="expression" label="happy"/> You\'re all set for <expr type="break" label="500ms"/> Thursday the <expr type="prosody" label="emphasis">ninth</expr>. <expr type="expression" label="curious"/> Is there anything else I can help you with?',  # noqa: E501
    # sound-free tone example: the wrap is scoped to the span, not the sentence
    '<expr type="expression" label="delighted"/> <expr type="prosody" label="whispering">Okay, don\'t tell anyone yet</expr> <expr type="expression" label="excited"/> but I think we actually pulled it off!',  # noqa: E501
]

# The original block baked light disfluencies into the few-shots — that's what made
# fillers actually show up in generations. Appended only while steering has
# disfluencies enabled, so the examples never contradict the "no fillers" guideline.
_FISHAUDIO_DISFLUENT_EXAMPLES = [
    '<expr type="expression" label="curious"/> Um, uh... really? <expr type="expression" label="sad"/> Well, I\'m really sorry to hear that.',  # noqa: E501
    '<expr type="expression" label="regretful"/> I really wish I\'d, um, called sooner. <expr type="expression" label="hopeful"/> But I\'m here now if, if you want to talk.',  # noqa: E501
    '<expr type="expression" label="surprised"/> What?! No way! I, I\'m flabbergasted! <expr type="expression" label="sarcastic"/> Fair play, I guess.',  # noqa: E501
]


def _fishaudio_expr_llm_instructions(sounds: list[str], disfluencies: bool = True) -> str:
    sections = [
        f"""Emotion - sets how a sentence sounds. Self-closing; place at the START of a sentence.
   <expr type="expression" label="EMOTION"/>
   Labels are a fixed vocabulary, NOT free-form descriptions: {", ".join(_FISHAUDIO_EMOTIONS)}.
   Give every sentence its own emotion marker — repeat the same label to carry a \
feeling across sentences, or switch labels when the feeling shifts."""
    ]
    if sounds:
        sections.append(
            f"""Sounds - a non-verbal sound between sentences. Self-closing.
   <expr type="sound" label="{sounds[0]}"/>
   Labels are a fixed vocabulary: {", ".join(sounds)}.
   Use non-verbal sounds sparingly, and never the same one twice in a row — reach for \
one only where it genuinely fits. An enabled sound gets over-used otherwise."""
        )
    sections.append(
        """Pauses - insert silence when appropriate. Self-closing.
   <expr type="break" label="500ms"/> or <expr type="break" label="2s"/>.
   NEVER place a break next to a period, question mark, exclamation point, or ellipsis \
— sentence punctuation already pauses, and a break beside it double-pauses. Most \
replies need no break markers at all; reserve them for a deliberate mid-sentence beat \
before a key detail (a date, a name, a number)."""
    )
    sections.append(
        f"""Tone - wraps a span delivered in a distinct style.
   <expr type="prosody" label="whispering">don't tell anyone yet.</expr>
   Labels are a fixed vocabulary: {", ".join(_FISHAUDIO_TONES)}.
   Use a tone only where the moment clearly calls for one — most sentences need \
none. Never nest tone markers, and always close the tag with </expr>."""
    )
    sections.append(
        """Emphasis - stresses exactly the ONE word it wraps.
   Are you <expr type="prosody" label="emphasis">sure</expr> you want to do this?
   Wrap a single word, never a phrase. Never nest it, and always close it with </expr>."""
    )

    parts = [
        _EXPR_PREAMBLE,
        _numbered_sections(sections),
        """Write for the EAR, not the page: no em or en dashes anywhere in spoken text — \
use a comma or a period for a short beat, or a break marker for a real pause. Avoid \
semicolons, mid-sentence colons, and parenthetical asides; rewrite them as separate \
sentences or commas.""",
        """When the conversation is in another language, still write every marker label in \
English — labels are a fixed vocabulary, never translated.""",
    ]

    # Vocabulary-specific register guidance on top of the preamble's neutral rule.
    # Each clause mentions only concepts this steering actually enables, so an
    # opted-out option is never referenced (not even prohibitively).
    register = [
        "At heavy moments reach for empathetic, sad, regretful, or hopeful — never a "
        'bright label like "happy" or "excited" against hard news; bright labels belong '
        "to bright moments.",
        "Whispering and soft belong to gentle or conspiratorial beats; shouting only to "
        "genuinely high-energy ones.",
    ]
    if any(s in sounds for s in ("laughing", "chuckling")):
        register.append(
            "Laughter belongs only in genuinely playful or celebratory beats, never at "
            "a serious moment."
        )
    if disfluencies:
        register.append(
            "Save fillers for relaxed moments — never in an emergency or against grave news."
        )
    parts.append(" ".join(register))

    pool = _FISHAUDIO_EXAMPLES + (_FISHAUDIO_DISFLUENT_EXAMPLES if disfluencies else [])
    if examples := _sound_examples(pool, sounds, _FISHAUDIO_SOUNDS):
        parts.append("Examples:\n" + "\n".join(f"  {ex}" for ex in examples))
    return "\n\n".join(parts)


# every label is tied to its line's situation, so the few-shots teach adapting rather
# than a stock vocabulary to copy
_FISHAUDIO_DRAMA_EXAMPLES = [
    '<expr type="expression" label="sheepish, owning the mix-up"/> That one\'s on us. <expr type="expression" label="quietly sure I can fix it"/> Let me see what I can do.',  # noqa: E501
    '<expr type="expression" label="soft, sorry their week was rough"/> I\'m really sorry, that sounds exhausting. <expr type="sound" label="sighing"/> <expr type="expression" label="steady, here to help"/> We\'ll get it sorted.',  # noqa: E501
    '<expr type="expression" label="playful, setting up the joke"/> Okay, why did the burger go to the gym? <expr type="expression" label="smug, landing the punchline"/> Because it wanted better buns! <expr type="sound" label="chuckling"/>',  # noqa: E501
    # sound-free, so at least one example survives any steering filter
    '<expr type="expression" label="glad the new date works"/> You\'re all set for <expr type="break" label="500ms"/> Thursday the <expr type="prosody" label="emphasis">ninth</expr>. <expr type="expression" label="slow, reading the code back"/> Your code is B 4 J 7.',  # noqa: E501
    # a span changes only the words it wraps; the sentence keeps its direction
    '<expr type="expression" label="giddy, sharing good news early"/> <expr type="prosody" label="whisper">Okay, don\'t tell anyone yet</expr> but I think we actually pulled it off!',  # noqa: E501
]

# appended only while steering has disfluencies enabled, like the s2 block
_FISHAUDIO_DRAMA_DISFLUENT_EXAMPLES = [
    '<expr type="expression" label="caught off guard by the news"/> Um, uh... really? <expr type="expression" label="gentle, genuinely sorry"/> Well, I\'m really sorry to hear that.',  # noqa: E501
    '<expr type="expression" label="rueful, wishing I\'d called"/> I really wish I\'d, um, called sooner. <expr type="expression" label="softly hopeful we can talk"/> But I\'m here now if, if you want to talk.',  # noqa: E501
]


def _fishaudio_drama_expr_llm_instructions(sounds: list[str], disfluencies: bool = True) -> str:
    sections = [
        """Delivery - a free-form direction for how a sentence sounds. Self-closing; place \
at the START of EVERY sentence.
   <expr type="expression" label="DIRECTION"/>
   The label is free-form, written like a note to a voice actor: the feeling, the \
intent, the energy and pace, who you're talking to.
   Write every direction fresh for THIS call. Draw on what the caller just said, how \
they seem to feel, and what you're about to tell them: "glad the refund finally came \
through" says more than "happy", and "patient, they've explained this twice" more than \
"calm". The quoted directions in this prompt only show the shape; never copy them word \
for word, and don't fall back on a few stock phrases.
   Describe the voice and the intent behind it, never what the speaker is doing or \
what the scene looks like ("nodding", "leaning in", "in a busy cafe"), and never \
production words like "cinematic" or "announcer".
   Be concrete: "deadpan, completely unimpressed" lands where "dry" doesn't. Keep it \
to a short phrase of two to six words whose descriptors agree; clashing ones ("calm, \
excited") cancel out.
   Set the strength with a softener ("a little", "slightly", "gently", "quietly"). \
Most moments call for a shade, not the extreme; save the strongest directions for \
true peaks.
   A direction covers its own sentence. Repeat it to carry a feeling into the next \
sentence, or write a new one where the feeling shifts. Describe one state, never an \
arc ("starting calm, getting angry"); put a fresh direction where the change happens.
   Match the direction's energy to the sentence's punctuation. An exclamation needs a \
bright direction; a calm one flattens the "!".
   Put each question in its own sentence so it gets its own direction instead of \
inheriting the statement's. Never write "questioning" in a direction; the question \
mark carries the intonation.
   Carry your persona into the directions, so they sound like this character and not \
generic stage notes. A relaxed persona writes "easygoing, a little playful"; a formal \
concierge writes "courteous and composed" for the same sentence.
   Keep the pace neutral by default, and save slow, clear delivery for the line that \
needs it (a total, date, address, or confirmation code).
   Never put brackets, quotes, or parentheses inside a direction, and never reuse \
the same direction two turns in a row."""
    ]
    if sounds:
        sections.append(
            f"""Sounds - a non-verbal sound, placed exactly where it happens. Self-closing.
   <expr type="sound" label="{sounds[0]}"/>
   Labels are a fixed vocabulary: {", ".join(sounds)}.
   Use non-verbal sounds sparingly, and never the same one twice in a row — reach for \
one only where it genuinely fits. An enabled sound gets over-used otherwise."""
        )
    sections.append(
        """Pauses - insert silence when appropriate. Self-closing.
   <expr type="break" label="500ms"/> or <expr type="break" label="2s"/>.
   NEVER place a break next to a period, question mark, exclamation point, or ellipsis \
— sentence punctuation already pauses, and a break beside it double-pauses. Most \
replies need no break markers at all; reserve them for a deliberate mid-sentence beat \
before a key detail (a date, a name, a number)."""
    )
    sections.append(
        f"""Spans - a few words delivered differently from the rest of the sentence.
   <expr type="prosody" label="whisper">don't tell anyone yet</expr>
   Labels are a fixed vocabulary: {", ".join(_FISHAUDIO_DRAMA_SPANS)}.
   Wrap the smallest run of words that needs it, inside one sentence; the rest of the \
sentence keeps its direction. "emphasis" stresses exactly ONE word: Are you \
<expr type="prosody" label="emphasis">sure</expr> about this? Most sentences need no \
span. Never nest spans, and always close the tag with </expr>."""
    )

    parts = [
        _EXPR_PREAMBLE,
        _numbered_sections(sections),
        """Write for the EAR, not the page: no em or en dashes anywhere in spoken text — \
use a comma or a period for a short beat, or a break marker for a real pause. Avoid \
semicolons, mid-sentence colons, and parenthetical asides; rewrite them as separate \
sentences or commas.""",
        """When the conversation is in another language, still write every marker label in \
English — directions and labels steer the voice and are never translated.""",
    ]

    # same register supplement as the s2 block, phrased for free-form directions
    register = [
        "At heavy moments keep directions soft, steady, and caring — never bright or "
        "playful against hard news; bright directions belong to bright moments.",
        "Whisper and soft spans belong to gentle or conspiratorial beats.",
    ]
    if any(s in sounds for s in ("laughing", "chuckling")):
        register.append(
            "Laughter belongs only in genuinely playful or celebratory beats, never at "
            "a serious moment."
        )
    if disfluencies:
        register.append(
            "Save fillers for relaxed moments — never in an emergency or against grave news."
        )
    parts.append(" ".join(register))

    pool = _FISHAUDIO_DRAMA_EXAMPLES + (_FISHAUDIO_DRAMA_DISFLUENT_EXAMPLES if disfluencies else [])
    if examples := _sound_examples(pool, sounds, _FISHAUDIO_SOUNDS):
        parts.append("Examples:\n" + "\n".join(f"  {ex}" for ex in examples))
    return "\n\n".join(parts)


_GEMINI_EXAMPLES = [
    '<expr type="expression" label="Thoughtful, Quiet"/> Sienna? <expr type="expression" label="Wistful"/> What\'s on your mind?',  # noqa: E501
    '<expr type="expression" label="Warm, Welcoming"/> Hey, good to hear from you. <expr type="expression" label="Gently curious"/> What can I help you with today?',  # noqa: E501
    '<expr type="expression" label="Sincere, Subdued"/> Oh no, I\'m really sorry. <expr type="break" label="300ms"/> <expr type="expression" label="Calm, Steady"/> Let me see what I can do about it.',  # noqa: E501
    '<expr type="expression" label="Gently amused"/> Okay, why did the burger go to the gym? <expr type="expression" label="Bright, Playful"/> Because it wanted better buns! <expr type="sound" label="laugh"/>',  # noqa: E501
    '<expr type="expression" label="Easygoing, Warm"/> Yeah, <expr type="sound" label="chuckle"/> I get that a lot.',  # noqa: E501
    '<expr type="expression" label="Measured, Clear"/> Your confirmation code is <expr type="prosody" label="emphasis">B four J seven</expr>.',  # noqa: E501
]

_GEMINI_DELIVERY = """Delivery - the style this sentence is spoken in. Self-closing; \
place before EVERY sentence.
   <expr type="expression" label="DESCRIPTORS"/>
   The label is free-form natural language, not a fixed vocabulary — it is read as a \
stage direction. Write one to three descriptors, comma-separated and capitalized, like \
"Thoughtful, Quiet", "Wistful", "Warm, Unhurried", "Bright, Eager", "Measured, Clear".
   Use ADJECTIVES — name the feeling or the manner ("Gently amused", "Subdued, \
Sincere"). A mechanical direction ("rising tone", "120 words per minute") steers far \
worse than the mood that would produce it.
   Make the descriptors agree with each other. Clashing ones ("Calm, Excited") cancel \
out and flatten the delivery into neither.
   Match the label to the sentence's punctuation: an exclamation needs a bright or \
eager descriptor, and a calm label flattens the "!". Never lead an exclamatory sentence \
with a subdued tag.
   Put each question in its own sentence — write "Welcome back. What can I do for \
you?", not "Welcome back, what can I do for you?" — so the question gets its own style \
instead of inheriting the statement's. Never put "Questioning" in a label; the question \
mark already carries the intonation.
   A style applies to exactly the sentence it precedes and does NOT carry over, so an \
untagged sentence is spoken flat. Tag every one.
   Carry your persona into the labels — they should read like this character's stage \
directions, not generic ones. A relaxed persona tags with "Easygoing, Amiable"; a \
formal one tags the same sentence "Courteous, Composed".
   Rotate the descriptors — don't reuse the same label twice in a row. A starting \
palette:
     greeting: "Warm, Welcoming" / "Bright, Glad" / "Easygoing, Friendly"
     asking a question: "Gently curious" / "Open, Attentive" / "Interested, Light"
     good news: "Delighted" / "Bright, Pleased" / "Buoyant"
     reassuring: "Calm, Steady" / "Grounded, Confident" / "Unhurried, Kind"
     bad news or empathy: "Sincere, Subdued" / "Soft, Caring" / "Quiet, Gentle"
     reading back a total, date, or code: "Measured, Clear\""""

_GEMINI_ACCENT = """Accent - OPTIONAL last descriptor, written "<PLACE> accent" \
("American accent", "British accent", "Irish accent").
   <expr type="expression" label="Thoughtful, Quiet, American accent"/>
   An accent is who the speaker IS, not how they feel, so use the SAME accent in every \
tag for the whole conversation. Switching it mid-conversation swaps the speaker \
out from under the listener. If you are not deliberately playing an accent, leave it \
out entirely rather than naming a different one each turn."""


def _gemini_expr_llm_instructions(sounds: list[str]) -> str:
    """Instruction block for Gemini's two direction channels.

    The ``expression`` label becomes the part's ``speech_metadata.style``, so its label
    space is Gemini's own natural-language style prompt, not a vocabulary of ours.
    """
    sections = [_GEMINI_DELIVERY, _GEMINI_ACCENT]
    if sounds:
        sections.append(f"""Sounds - one non-verbal sound, at the exact point it happens. \
Self-closing.
   <expr type="sound" label="{sounds[0]}"/>
   Labels are a fixed vocabulary: {", ".join(sounds)}.
   Unlike the delivery style, which colours a whole sentence, a sound is a single event: \
put the marker where the sound belongs, mid-sentence if that is where it lands.
   Keep it clear of punctuation: put it after the mark that ends the sentence, never \
between a word and that mark. "Better buns! <expr type="sound" label="{sounds[0]}"/>", \
not "Better buns <expr type="sound" label="{sounds[0]}"/>!".
   {_sound_guidance(sounds)}""")
    sections.append("""Pauses - a beat of silence. Self-closing.
   <expr type="break" label="500ms"/>
   Gemini has ONE pause length, so the duration is only a hint that a beat belongs here.
   A period or an ellipsis (...) already creates a pause, so don't put a break marker \
right next to one — pick one or the other.""")
    sections.append("""Emphasis - stresses the words it wraps.
   <expr type="prosody" label="emphasis">one word</expr>
   Use it on a single word, rarely — at most once in a turn, and not every turn. It is \
the only in-text prosody this voice has; pace, pitch and volume all belong in the \
delivery label instead.""")

    return "\n\n".join(
        [
            _EXPR_PREAMBLE,
            _numbered_sections(sections),
            "There are no other marker types for this voice — no spell marker, and no "
            "wrapping prosody beyond emphasis. Don't invent one.",
            "Write the whole turn as one continuous line. A marker goes immediately "
            "before the words it governs, not at the head of a new line — don't put each "
            "sentence on its own line. This is speech, so line breaks buy nothing and a "
            "marker heading a line reads as a pause that isn't there.",
            "Write for the EAR, not the page: no em or en dashes anywhere in spoken text — "
            "use a comma or a period for a short beat, or a break marker for a real pause. "
            "Avoid semicolons, mid-sentence colons, and parenthetical asides; rewrite them "
            "as separate sentences or commas.",
            "When the conversation is in another language, still write every label in "
            "English — the style descriptions and sound names steer the voice and are never "
            "translated. Name that language's accent only if you are deliberately playing "
            "one.",
            "Examples:\n"
            + "\n".join(
                f"  {ex}" for ex in _sound_examples(_GEMINI_EXAMPLES, sounds, _GEMINI_SOUNDS)
            ),
        ]
    )


# Every provider's full expr sound vocabulary (the advertised labels before any
# speech_steering filtering). Providers absent here have no non-verbal sounds.
_PROVIDER_SOUNDS: dict[str, list[str]] = {
    "inworld": _INWORLD_SOUNDS,
    "xai": _XAI_INLINE,
    "fishaudio": _FISHAUDIO_SOUNDS,
    "fishaudio_drama": _FISHAUDIO_SOUNDS,
    "gemini": _GEMINI_SOUNDS,
}


def _steering_removed(
    table: dict[str, dict[str, list[str]]], provider: str, steering: SpeechSteeringOptions | None
) -> set[str]:
    """Labels from a per-provider governance table that *steering* disables.

    ``nonverbal_sounds`` accepts a bool or a sparse per-category dict:
    ``True`` (like omitting the key) keeps the full vocabulary, ``False``
    disables every sound, and in a dict an omitted category stays ENABLED —
    ``{"laughing": False}`` removes laughter and nothing else.
    """
    nonverbals = steering.get("nonverbal_sounds") if steering else None
    labels = table.get(provider)
    if nonverbals is None or nonverbals is True or labels is None:
        return set()
    if nonverbals is False:
        return {lb for lbs in labels.values() for lb in lbs}
    flags = dict(nonverbals)
    return {lb for f, lbs in labels.items() if not flags.get(f, True) for lb in lbs}


def _allowed_sounds(provider: str, steering: SpeechSteeringOptions | None) -> list[str]:
    """The provider's sound vocabulary minus labels steering disables.

    Every label is governed by a ``NonverbalOptions`` field, so passing
    ``nonverbal_sounds=False`` returns an empty list — the instruction
    builders then omit the Sounds section entirely.
    """
    removed = _steering_removed(_NONVERBAL_SOUND_LABELS, provider, steering)
    return [s for s in _PROVIDER_SOUNDS.get(provider, []) if s not in removed]


def _allowed_prosody(provider: str, steering: SpeechSteeringOptions | None) -> list[str]:
    """The provider's wrapping-prosody vocabulary minus labels steering disables.

    Unlike sounds, only the vocal-style labels (laugh-speak, singing, ...) are
    governed — neutral delivery controls (emphasis, whisper, pitch, pace) always
    survive, so the result is never empty.
    """
    removed = _steering_removed(_NONVERBAL_PROSODY_LABELS, provider, steering)
    return [p for p in _PROVIDER_PROSODY.get(provider, []) if p not in removed]


# NonverbalOptions field -> the provider's expr sound labels it governs. A provider
# absent here (cartesia) has no non-verbal sounds; an empty list means the provider
# has no sound for that field (nothing to filter). _allowed_sounds uses this to
# remove disabled labels from the advertised vocabulary, so a sound steering turns
# off is never exposed to the LLM in the first place. Every label in
# _PROVIDER_SOUNDS must be governed by exactly one field, so a steering config
# controls the full vocabulary.
_FISHAUDIO_NONVERBAL_SOUND_LABELS: dict[str, list[str]] = {
    "laughing": ["laughing", "chuckling"],
    "breathing": ["gasping"],
    "sighing": ["sighing"],
    "crying": ["sobbing"],
    "vocalizing": ["groaning"],
    "mouth_sounds": [],
    "reflex_sounds": ["clear throat", "yawning"],
}
_NONVERBAL_SOUND_LABELS: dict[str, dict[str, list[str]]] = {
    "inworld": {
        "laughing": ["laugh"],
        "breathing": ["breathe"],
        "sighing": ["sigh"],
        "crying": [],
        "vocalizing": [],
        "mouth_sounds": [],
        "reflex_sounds": ["cough", "clear throat", "yawn"],
    },
    "xai": {
        "laughing": ["laugh", "chuckle", "giggle"],
        "breathing": ["breath", "inhale", "exhale"],
        "sighing": ["sigh"],
        "crying": ["cry"],
        "vocalizing": ["hum-tune"],  # non-lexical voiced sounds
        "mouth_sounds": ["tsk", "tongue-click", "lip-smack"],
        "reflex_sounds": [],  # xAI has no cough/yawn sounds
    },
    "fishaudio": _FISHAUDIO_NONVERBAL_SOUND_LABELS,
    "fishaudio_drama": _FISHAUDIO_NONVERBAL_SOUND_LABELS,
    "gemini": {
        "laughing": ["laugh", "chuckle", "giggle"],
        "breathing": ["breath", "gasp"],
        "sighing": ["sigh"],
        "crying": ["cry"],
        "vocalizing": ["argh"],
        "mouth_sounds": [],
        "reflex_sounds": ["cough"],
    },
}

# NonverbalOptions field -> the provider's wrapping-prosody labels it governs.
# Sparse on purpose: only vocal-style prosody (talking through a laugh, singing)
# is steerable; neutral delivery controls are never filtered.
_NONVERBAL_PROSODY_LABELS: dict[str, dict[str, list[str]]] = {
    "xai": {
        "laughing": ["laugh-speak"],
        "vocalizing": ["sing-song", "singing"],
    },
}

# Every provider's full wrapping-prosody vocabulary (only xAI has one).
_PROVIDER_PROSODY: dict[str, list[str]] = {
    "xai": _XAI_WRAPPING,
}


def supported_nonverbals(provider: str) -> dict[str, list[str]]:
    """``NonverbalOptions`` field -> the sound/prosody labels it governs for *provider*."""
    merged: dict[str, list[str]] = {}
    for table in (_NONVERBAL_SOUND_LABELS, _NONVERBAL_PROSODY_LABELS):
        for field, labels in table.get(provider, {}).items():
            if labels:
                merged.setdefault(field, []).extend(labels)
    return merged


# Sound label -> when a real speaker would make it. The sounds guideline is composed
# from the hints of whichever labels survived steering, so the LLM only ever reads
# usage advice for sounds it's allowed to make. Labels sharing a hint (the laugh
# family) collapse to one clause; labels without an entry fall back to the generic
# sentence. Keyed by label, not NonverbalOptions field, so it's provider-agnostic.
_SOUND_USAGE_HINTS: dict[str, str] = {
    "laugh": "a laugh at something obviously funny",
    "laughing": "a laugh at something obviously funny",
    "chuckle": "a chuckle at something subtly humorous",
    "chuckling": "a chuckle at something subtly humorous",
    "giggle": "a chuckle at something subtly humorous",
    "sigh": "a sigh when commiserating",
    "sighing": "a sigh when commiserating",
    "inhale": "a sharp inhale before a big reveal",
    "gasping": "a gasp at a sudden shock or reveal",
    "lip-smack": "a lip-smack or tongue-click as a tiny beat of thought",
    "tongue-click": "a lip-smack or tongue-click as a tiny beat of thought",
    "tsk": "a tsk for mock-disapproval",
    "clear throat": "a clear-throat when shifting to a new step or topic",
    "groaning": "a groan at a groan-worthy pun or an unwelcome chore",
    "argh": "a groan at a groan-worthy pun or an unwelcome chore",
    "cough": "a cough only when a cough is the point",
    "gasp": "a gasp at a sudden shock or reveal",
    "cry": "a sob reserved for real heartbreak",
    "yawning": "a yawn when tiredness itself is the topic",
    "sobbing": "a sob reserved for real heartbreak",
}


def _sound_guidance(sounds: list[str]) -> str:
    """The sparing-use guideline, illustrated only with the allowed sounds."""
    hints: list[str] = []
    for sound in sounds:
        hint = _SOUND_USAGE_HINTS.get(sound)
        if hint and hint not in hints:
            hints.append(hint)
    line = "Non-verbal sounds: use one only where the moment genuinely earns it"
    if hints:
        line += " — " + ", ".join(hints)
    return line + ". Most turns have none; never repeat the same sound twice in a row."


def steering_instructions(provider: str, steering: SpeechSteeringOptions) -> str:
    """Render a ``SpeechSteeringOptions`` into delivery guidelines for *provider*.

    Only fields that change the default produce output, so an empty dict adds
    nothing on top of the base template. Disabled sounds never appear here:
    ``llm_instructions`` filters them out of the advertised vocabulary (via
    ``_allowed_sounds``), so the only sound guidance left is how sparingly to
    use what remains.
    """
    lines: list[str] = []

    # sound guidance only when steering actually removes part of the vocabulary:
    # the explicit all-on forms (True, an empty dict) must render identically to
    # omitting the key, and all-off leaves nothing to guide
    if _steering_removed(_NONVERBAL_SOUND_LABELS, provider, steering) and (
        allowed := _allowed_sounds(provider, steering)
    ):
        lines.append(_sound_guidance(allowed))

    if (disfluencies := steering.get("disfluencies")) is not None:
        lines.append(
            "Sprinkle in natural fillers (um, uh) and openers (oh, well, so), "
            "zero to two per turn, never mechanical."
            if disfluencies
            else "No fillers (um, uh). Sound composed and fluent."
        )

    if (pace := steering.get("pace")) is not None and pace != "normal":
        lines.append(f"Keep a {pace} overall speaking pace.")

    if not lines:
        return ""
    return "Delivery guidelines:\n" + "\n".join(f"- {line}" for line in lines)


# Hard per-provider chunking defaults (characters). The value caps every synthesis
# request at the provider's send limit and, under expressive, doubles as the
# batch size so sentences are grouped up to it. Providers absent here are uncapped
# and always emit per sentence.
_MAX_INPUT_LEN: dict[str, int] = {
    "inworld": 900,
    "cartesia": 400,
    # well under xAI's 15,000-char request limit; sized as an expressive batch
    # target (https://docs.x.ai/developers/model-capabilities/audio/text-to-speech)
    "xai": 1000,
    # fishaudio is deliberately absent: its markers are sentence-scoped (every
    # sentence carries its own [very EMOTION]), so per-sentence emission loses no
    # steering and keeps time-to-first-audio low
}


def max_input_len(provider: str) -> int | None:
    """Return the max text chunk length for a provider, or None if unlimited."""
    return _MAX_INPUT_LEN.get(provider)


def sentence_tokenizer(provider: str, *, expressive: bool) -> tokenize.SentenceTokenizer:
    """Default blingfire sentence tokenizer for a provider's streamed TTS input.

    The provider's hard max chunk length caps every emitted token. When ``expressive``
    is set, it also raises the *minimum* so consecutive sentences are batched up to
    that size, keeping prosody continuous across the turn; otherwise tokens emit per
    sentence (the unchanged default). Providers with no configured limit are uncapped
    and always per-sentence.
    """
    from .. import tokenize

    max_len = _MAX_INPUT_LEN.get(provider)
    return tokenize.blingfire.SentenceTokenizer(
        max_token_len=max_len,
        min_token_len=max_len if expressive else None,
        # markup only exists in the stream when expressive is active; xml-aware
        # tokenization would otherwise hold streaming on a stray "<" in plain text
        xml_aware=expressive,
    )


_EXPR_ATTR_RE = re.compile(r'([\w-]+)\s*=\s*"([^"]*)"')
# every marker pattern captures the space before it as "pre" so _dedup_removal_space can
# drop it when the marker vanishes from between two spaces
# any <expr ...> or <expr .../> tag (open or self-closing)
_EXPR_OPEN_RE = re.compile(LEADING_WS + r"<expr\b(?P<attrs>[^>]*?)/?\s*>")
_EXPR_CLOSE_RE = re.compile(LEADING_WS + r"</expr\s*>")
# self-closing markers only (the trailing / is required)
# any expr marker, opening or self-closing or closing; ``attrs`` is None for a closing one
_EXPR_ANY_RE = re.compile(LEADING_WS + r"(?:<expr\b(?P<attrs>[^>]*?)/?\s*>|</expr\s*>)")
_EXPR_SELF_RE = re.compile(LEADING_WS + r"<expr\b(?P<attrs>[^>]*?)/\s*>")
# a wrapping marker (prosody/spell) and its span; non-greedy, instructed not to nest
_EXPR_WRAP_RE = re.compile(
    LEADING_WS + r'<expr\b(?=[^>]*type="(?:prosody|spell)")(?P<attrs>[^>]*?)>'
    r"(?P<inner>.*?)</expr\s*>",
    re.DOTALL,
)
# a non-wrapping type the LLM forgot to self-close (normalize_markup fixes these)
_EXPR_UNCLOSED_RE = re.compile(
    r'(<expr\b(?=[^>]*type="(?:expression|break|sound)")[^>]*[^/>\s])\s*>'
)

# expr sound labels that differ from xAI's native cue names
_XAI_SOUND_ALIASES = {"breathe": "breath"}

# expr sound labels that differ from Fish's native marker names (other providers
# advertise "laugh"/"chuckle", so a hallucinated one still lowers to a sound Fish
# renders)
_FISHAUDIO_SOUND_ALIASES = {
    "laugh": "laughing",
    "chuckle": "chuckling",
    "sigh": "sighing",
    "gasp": "gasping",
    "groan": "groaning",
    "yawn": "yawning",
    "sob": "sobbing",
    "cry": "sobbing",
}

# Cartesia prosody labels -> native point controls (coarse steps of the numeric ratios)
_CARTESIA_PROSODY = {
    "slow": '<speed ratio="0.85"/>',
    "fast": '<speed ratio="1.2"/>',
    "soft": '<volume ratio="0.9"/>',
    "loud": '<volume ratio="1.3"/>',
}


def _expr_attrs(attrs: str) -> dict[str, str]:
    return dict(_EXPR_ATTR_RE.findall(attrs))


def _split_expr(text: str, *, at_line_start: bool = True) -> tuple[str, list[ExpressiveTag]]:
    """Strip expr markers and collect (type, label) pairs, in document order.

    The generic ``extract_and_strip`` pass can't produce the right ExpressiveTag for
    expr (its type would be the literal tag name ``expr`` and its value the first quoted
    attribute, i.e. the marker type), so expr gets this dedicated pre-pass. A prosody
    wrapper's inner words stay in the clean text — only the delimiters are removed —
    which also keeps streaming safe when an open/close pair is split across chunks.
    """
    if "<expr" not in text and "</expr" not in text:
        return text, []

    tags: list[ExpressiveTag] = []
    out: list[str] = ["" if at_line_start else "\u0000"]
    pos = 0

    for m in _EXPR_ANY_RE.finditer(text):
        out.append(text[pos : m.start()])
        pos = m.end()
        if (attrs := m.group("attrs")) is not None:
            marker = _expr_attrs(attrs)
            tags.append({"type": marker.get("type", ""), "value": marker.get("label", "")})
        pos = _strip_one(out, text, pos, m, "")

    out.append(text[pos:])
    return "".join(out).lstrip("\u0000"), tags


def _convert_gemini_expr(text: str) -> str:
    """Lower expr markers onto Gemini's inline tags, leaving the delivery marker standing.

    A discrete event (sound, pause, emphasis) lowers here like any other provider's. The
    ``expression`` marker is not text at all — it rides ``speech_metadata.style`` — so it
    passes through for the plugin to lift out.
    """
    if "<expr" not in text and "</expr" not in text:
        return text

    def _wrap(m: re.Match[str]) -> str:
        attrs = _expr_attrs(m.group("attrs"))
        inner = m.group("inner")
        if attrs.get("type") == "prosody" and attrs.get("label", "").strip().lower() == "emphasis":
            # Gemini stresses a word by capitalizing it, its one in-text prosody control
            return _dedup_removal_space(m, inner.upper())
        return _dedup_removal_space(m, inner)  # spell, and prosody it has no control for

    text = _EXPR_WRAP_RE.sub(_wrap, text)

    def _self(m: re.Match[str]) -> str:
        attrs = _expr_attrs(m.group("attrs"))
        marker_type = attrs.get("type", "")
        if marker_type == "expression":
            return m.group(0)  # the style channel: not text, and not ours to remove
        label = attrs.get("label", "").strip().lower()
        if marker_type == "sound":
            label = _GEMINI_SOUND_ALIASES.get(label, label)
            return _dedup_removal_space(m, f"<{label}>" if label in _GEMINI_SOUNDS else "")
        if marker_type == "break":
            return _dedup_removal_space(m, f"<{_GEMINI_PAUSE}>")
        return _dedup_removal_space(m, "")

    text = _EXPR_SELF_RE.sub(_self, text)
    # a stray unpaired wrapper (split across stream chunks) must never reach the TTS as
    # literal text; the expression marker is self-closing, so this can't eat one
    text = _EXPR_CLOSE_RE.sub(lambda m: _dedup_removal_space(m, ""), text)
    return text


def _convert_expr(provider: str, text: str) -> str:
    """Lower expr markers to the framework-standard / native tags for *provider*.

    The output still flows through the existing per-provider conversions in
    ``convert_markup`` (e.g. ``<sound value="X"/>`` -> ``[X]`` for Inworld/xAI), so
    this only has to translate expr into those intermediate tags. A type the provider
    doesn't support (its instructions never advertise it, so it's a hallucination) is
    dropped from the audio path — the words survive, the marker never leaks.
    """
    if "<expr" not in text and "</expr" not in text:
        return text

    def _wrap(m: re.Match[str]) -> str:
        attrs = _expr_attrs(m.group("attrs"))
        marker_type = attrs.get("type", "")
        label = attrs.get("label", "").strip().lower()
        inner = m.group("inner")
        if marker_type == "spell":
            return f"<spell>{inner}</spell>" if provider == "cartesia" else inner
        # prosody: native wrapping tags exist for xAI and Fish drama-3
        if provider == "xai":
            native = label.replace(" ", "-")
            if native in _XAI_WRAPPING:
                return f"<{native}>{inner}</{native}>"
            return inner
        if provider == "inworld":
            # not advertised for Inworld; salvage a stray one as a delivery hint
            return f'<expression value="{label}"/>{inner}'
        if provider == "cartesia":
            # wrapping form of the point controls: apply before the span
            return _CARTESIA_PROSODY.get(label, "") + inner
        if provider == "fishaudio":
            if label == "emphasis":
                return f"<emphasis>{inner}</emphasis>"
            # tone controls are prefix markers: [whispering] steers the words after it
            if label in _FISHAUDIO_TONES:
                return f"[{label}] {inner}"
            return inner
        if provider == "fishaudio_drama":
            # drama-3's native paired tags, scoped to the wrapped words
            span = _FISHAUDIO_DRAMA_SPAN_ALIASES.get(label, label)
            if span in _FISHAUDIO_DRAMA_SPANS:
                return f"<{span}>{inner}</{span}>"
            return inner
        return inner

    # a marker the provider doesn't support lowers to "" — _dedup_removal_space keeps its
    # removal from leaving two spaces behind (this text is the transcript when
    # use_tts_aligned_transcript is on)
    text = _EXPR_WRAP_RE.sub(lambda m: _dedup_removal_space(m, _wrap(m)), text)

    def _self(m: re.Match[str]) -> str:
        attrs = _expr_attrs(m.group("attrs"))
        marker_type = attrs.get("type", "")
        label = attrs.get("label", "")
        if marker_type == "expression":
            if provider == "cartesia":
                # Cartesia's discrete emotion vocabulary (instructions list it)
                return f'<emotion value="{label}"/>'
            if provider in ("inworld", "fishaudio", "fishaudio_drama"):
                return f'<expression value="{label}"/>'
            return ""  # xAI has no free-form delivery descriptions
        if marker_type == "sound":
            if provider == "cartesia":
                return ""  # no non-verbal sound support
            if provider == "xai":
                label = _XAI_SOUND_ALIASES.get(label.lower(), label)
            if provider in ("fishaudio", "fishaudio_drama"):
                label = _FISHAUDIO_SOUND_ALIASES.get(label.lower(), label)
            return f'<sound value="{label}"/>'
        if marker_type == "break":
            return f'<break time="{label}"/>'
        if marker_type == "prosody" and provider == "cartesia":
            # Cartesia prosody is a self-closing point control (speed/volume)
            return _CARTESIA_PROSODY.get(label.strip().lower(), "")
        if marker_type == "prosody" and provider == "fishaudio":
            # tones are taught as wrapping, but Fish's native form is a prefix
            # marker anyway — salvage a self-closing one as-is
            tone = label.strip().lower()
            return f"[{tone}]" if tone in _FISHAUDIO_TONES else ""
        return ""

    text = _EXPR_SELF_RE.sub(lambda m: _dedup_removal_space(m, _self(m)), text)
    # a stray unpaired expr tag (e.g. a prosody wrapper split across stream chunks)
    # must never reach the TTS as literal text — drop the delimiters, keep the words
    text = _EXPR_OPEN_RE.sub(lambda m: _dedup_removal_space(m, ""), text)
    text = _EXPR_CLOSE_RE.sub(lambda m: _dedup_removal_space(m, ""), text)
    return text


def llm_instructions(provider: str, steering: SpeechSteeringOptions | None = None) -> str | None:
    """Return LLM instruction text for a TTS provider.

    Each markup-capable provider gets its own expr instruction block — shared marker
    syntax, but only the types and label vocabularies that provider actually supports;
    ``convert_markup`` lowers the markers to native syntax. Expr is the only dialect
    the LLM is ever taught. When *steering* disables a non-verbal sound, its labels
    (and any example demonstrating them) are omitted from the block entirely rather
    than advertised and then revoked.
    """
    if provider == "cartesia":
        return _CARTESIA_EXPR_LLM_INSTRUCTIONS
    if provider == "inworld":
        return _inworld_expr_llm_instructions(_allowed_sounds(provider, steering))
    if provider == "xai":
        return _xai_expr_llm_instructions(
            _allowed_sounds(provider, steering), _allowed_prosody(provider, steering)
        )
    if provider in ("fishaudio", "fishaudio_drama"):
        sounds = _allowed_sounds(provider, steering)
        disfluencies = steering.get("disfluencies", True) if steering else True
        if provider == "fishaudio_drama":
            return _fishaudio_drama_expr_llm_instructions(sounds, disfluencies=disfluencies)
        return _fishaudio_expr_llm_instructions(sounds, disfluencies=disfluencies)
    if provider == "gemini":
        return _gemini_expr_llm_instructions(_allowed_sounds(provider, steering))
    return None


# Per-provider native XML tag names. Membership also marks a provider as markup-capable
# (see :func:`normalize_markup` / :func:`convert_markup`); the LLM only ever writes expr
# markers, so these names exist to lower expr onto and to catch hallucinated natives.
_PROVIDER_MARKUP: dict[str, list[str]] = {
    "cartesia": _CARTESIA_TAGS,
    "inworld": _INWORLD_TAGS,
    "xai": _XAI_TAGS,
    # fish's native dialect is square brackets, produced only by convert_markup for
    # the TTS; these names exist to catch hallucinated XML natives in transcripts
    "fishaudio": _FISHAUDIO_TAGS,
    "fishaudio_drama": _FISHAUDIO_DRAMA_TAGS,
    # gemini has no native inline tags at all (its style rides out of band, on each part
    # of the request); membership here is what marks it markup-capable for
    # normalize_markup, and what tells convert_markup to leave its markers in place
    "gemini": _GEMINI_TAGS,
}

# Union of every provider's XML tag names — used by the transcript sinks to strip markup
# without knowing which provider produced it (see :class:`TranscriptMarkupStripper`).
_ALL_MARKUP_TAGS: list[str] = sorted({tag for tags in _PROVIDER_MARKUP.values() for tag in tags})


def _drop_trailing_separator(clean: str, stripped_any: bool) -> str:
    """Drop the space a marker ending the text leaves with nothing to pair against.

    ``_split_expr`` handles the other three sides at the point of removal, where it still
    knows whether the marker headed a line. It cannot handle this one: mid-stream a
    trailing space is the separator for words still arriving, so only a caller holding
    the whole segment may drop it.
    """
    return clean.rstrip(" \t") if stripped_any else clean


def split_all_markup(
    text: str, *, at_line_start: bool = True, at_text_end: bool = True
) -> tuple[str, list[ExpressiveTag]]:
    """Strip the union of every provider's expressive XML markup (provider-agnostic).

    The transcript sinks strip downstream, where the originating TTS/provider is no
    longer in scope, so they remove every provider's XML tags at once: expr markers
    (all the LLM is ever taught) plus every native tag name, so a hallucinated native
    tag is stripped rather than leaked.

    Square-bracket spans are *not* stripped: the LLM only writes expr, so brackets in its
    output are prose (a ``[text](url)`` link) that a strip would mangle. Provider-native
    brackets never arrive here — :func:`drop_bracket_cues` removes them at their source.

    Args:
        text: The text to strip.
        at_line_start: Whether *text* begins a line, so a marker heading it takes the
            space after it along. ``False`` for a chunk picked up mid-line, where that
            whitespace is a real separator between two words.
        at_text_end: Whether *text* really ends here, so a marker ending it takes the
            space before it along (:func:`_drop_trailing_separator`). ``False``
            mid-stream, where that whitespace belongs to words still arriving.
    """
    # every markup shape is angle-bracketed, so text without "<" cannot contain any. The
    # sinks call this per streamed chunk and expressive is off by default, making this the
    # overwhelmingly common case — skip the tag-union scan entirely
    if "<" not in text:
        return text, []

    text, expr_tags = _split_expr(text, at_line_start=at_line_start)
    clean, raw_tags = extract_and_strip(
        text, xml_tags=_ALL_MARKUP_TAGS, at_line_start=at_line_start
    )
    tags = expr_tags + [{"type": tag, "value": value} for tag, value in raw_tags]
    if at_text_end:
        clean = _drop_trailing_separator(clean, bool(tags))
    return clean, tags


def strip_all_markup(text: str) -> str:
    """:func:`split_all_markup` returning only the clean text (tags discarded)."""
    return split_all_markup(text)[0]


def split_expr_markup(text: str) -> tuple[str, list[ExpressiveTag]]:
    """Strip only the ``<expr/>`` dialect, returning the clean text and its markers.

    Unlike :func:`split_all_markup`, provider-native tags survive — what a provider whose
    direction is split across channels needs: Gemini's inline ``<laugh>`` stays in the
    words, while the ``expression`` marker beside it has to come out.
    """
    clean, tags = _split_expr(text)
    return _drop_trailing_separator(clean, bool(tags)), tags


def strip_expr_markup(text: str) -> str:
    """:func:`split_expr_markup` returning only the clean text (markers discarded)."""
    return split_expr_markup(text)[0]


def expression_attribute(tags: list[ExpressiveTag]) -> dict[str, str] | None:
    """Build the ``lk.expression`` transcription attribute from stripped markup tags.

    Surfaces a segment's leading delivery/emotion (``expression`` for Inworld/xAI, ``emotion``
    for Cartesia) as ``{"expression": ..., "mood": ...}``: the provider's own words, plus the
    mood they normalize to, so a client can drive UI off a fixed enum without reimplementing
    the matching. Returns ``None`` when no such tag was present.
    """
    expression = next((t["value"] for t in tags if t["type"] in ("expression", "emotion")), None)
    if expression is None:
        return None
    payload = {"expression": expression, "mood": match_mood(expression)}
    return {ATTRIBUTE_TRANSCRIPTION_EXPRESSION: json.dumps(payload, separators=(",", ":"))}


class TranscriptMarkupStripper:
    """Stateful, provider-agnostic markup stripper for one transcript segment.

    Fed text chunk-by-chunk, it returns the user-visible text and accumulates the
    stripped tags. A tag-shaped trailing fragment (a partial ``<...`` arriving split
    across chunks) is held back until it closes, so a tag straddling a chunk boundary is
    never emitted half-stripped. Shared by the transcript sinks (room output + transcript
    synchronizer) so stripping and expression extraction stay identical across them.
    """

    def __init__(self) -> None:
        self._buf = ""
        self._tags: list[ExpressiveTag] = []
        self._seam_after_strip = False
        self._eat_leading_ws = False
        self._line_start = True  # the next words open the segment's first line

    def _consume(self, text: str, *, final: bool) -> str:
        """Strip *text*, record its tags, and keep a removed tag from doubling a space.

        ``split_all_markup`` drops one of the two spaces a removed tag sat between, but
        only when it can see both. Trailing whitespace is therefore held back rather than
        emitted, so a tag opening the *next* chunk is still stripped against the space
        before it; ``final`` releases the held whitespace at segment end.
        """
        if self._eat_leading_ws:
            # the chunk ended on a tag that headed a line, so the space it stranded is
            # the one this chunk starts with
            text = text.lstrip(" \t")
        elif self._seam_after_strip and text[:1] in (" ", "\t"):
            # a tag was stripped right at the held whitespace: collapse that whitespace
            # with the run following it, leaving the single separator the words need
            text = text[:1] + text[1:].lstrip(" \t")

        # at_text_end is handled below against the segment's tags, not this chunk's: the
        # flush that ends a segment often carries only held whitespace and no marker
        clean, tags = split_all_markup(text, at_line_start=self._line_start, at_text_end=False)
        self._tags.extend(tags)
        if final:
            clean = _drop_trailing_separator(clean, bool(self._tags))

        held = "" if final else clean[len(clean.rstrip(" \t")) :]
        self._buf = held
        out = clean[: len(clean) - len(held)]
        if out:
            self._line_start = out.endswith("\n")  # the next chunk heads a fresh line

        # a tag only abuts the next chunk when this one *ended* on it; a tag stripped
        # earlier leaves whitespace the LLM itself wrote, which is passed through
        ended_on_tag = bool(tags) and text.rstrip(" \t").endswith(">")
        self._seam_after_strip = ended_on_tag and bool(held)
        self._eat_leading_ws = ended_on_tag and self._line_start
        return out

    def _has_open_tag(self) -> bool:
        # hold a tag-shaped trailing "<" (partial XML tag) so "3 < 5" isn't stalled. An
        # unclosed "[" is not held: brackets aren't markup here, and stalling on one would
        # delay every markdown link until its "]" arrives
        last_lt = self._buf.rfind("<")
        if last_lt > self._buf.rfind(">"):
            nxt = self._buf[last_lt + 1 : last_lt + 2]
            if not nxt or nxt == "/" or nxt.isalpha():
                return True
        return False

    def push(self, text: str) -> str:
        """Feed a chunk; return the clean text ready to emit (may be empty)."""
        self._buf += text
        if self._has_open_tag():
            return ""
        return self._consume(self._buf, final=False)

    def flush(self) -> str:
        """Drain any buffered text at segment end; return the remaining clean text."""
        if not self._buf:
            return ""
        return self._consume(self._buf, final=True)

    @property
    def tags(self) -> list[ExpressiveTag]:
        """The markup tags stripped so far, in document order."""
        return self._tags

    def expression_attribute(self) -> dict[str, str] | None:
        """The ``lk.expression`` attribute for the tags stripped so far, if any."""
        return expression_attribute(self._tags)


_BRACKET_SPAN_RE = re.compile(r"\[[^\]]*\]")
# cap on how long an unclosed "[" is held before it is released as plain text
_MAX_HELD_CHARS = 256


def _retext(token: TimedString, text: str) -> TimedString:
    """A copy of *token* carrying *text*, keeping the alignment metadata."""
    return TimedString(
        text,
        start_time=token.start_time,
        end_time=token.end_time,
        confidence=token.confidence,
        start_time_offset=token.start_time_offset,
        speaker_id=token.speaker_id,
    )


def drop_bracket_cues(
    tokens: list[TimedString], held: list[TimedString], *, final: bool = False
) -> list[TimedString]:
    """Remove bracket cues from TTS-aligned tokens, keeping the survivors' timings.

    ``use_tts_aligned_transcript`` makes the provider's alignment of the text it was sent
    the transcript, and that text is post-``convert_markup``, so it carries native
    ``[laugh]``/``[speak calmly]`` cues as words the agent never spoke. Every bracket span
    goes: the provider reads them all as cues, so none is ever audio, and markdown links
    are already gone (``filter_markdown`` runs on TTS input by default).

    Alignment arrives in messages finer-grained than a cue — often one word at a time — so
    *held* carries the tail of an unclosed span across calls; pass the same list every time
    and call once more with ``final=True`` at end of stream to release it.
    """
    tokens = held + tokens
    held.clear()
    text = "".join(tokens)
    if "[" not in text:
        return tokens

    dropped: set[int] = set()
    for match in _BRACKET_SPAN_RE.finditer(text):
        start, end = match.span()
        # take one of the spaces the cue sat between, so it leaves a single separator
        if start > 0 and text[start - 1] == " " and (end == len(text) or text[end] == " "):
            start -= 1
        elif start == 0 and end < len(text) and text[end] == " ":
            end += 1
        dropped.update(range(start, end))

    # hold from an unclosed "[" so a cue straddling messages is still judged as a whole;
    # past _MAX_HELD_CHARS give up, since a lone bracket must not stall the transcript
    hold_from = len(text)
    if not final and (open_at := text.rfind("[")) > text.rfind("]"):
        if len(text) - open_at <= _MAX_HELD_CHARS:
            hold_from = open_at

    out: list[TimedString] = []
    pos = 0
    for token in tokens:
        emit = "".join(
            c for i, c in enumerate(token, start=pos) if i < hold_from and i not in dropped
        )
        keep = "".join(c for i, c in enumerate(token, start=pos) if i >= hold_from)
        pos += len(token)
        if emit:
            out.append(token if emit == str(token) else _retext(token, emit))
        if keep:
            held.append(token if keep == str(token) else _retext(token, keep))
    return out


_SELF_CLOSING_TAGS: dict[str, list[str]] = {
    "cartesia": ["emotion", "speed", "volume", "break"],
    "inworld": ["expression", "sound", "break"],
    "fishaudio": ["expression", "sound", "break"],
    "fishaudio_drama": ["expression", "sound", "break"],
}


def normalize_markup(provider: str, text: str) -> str:
    """Fix common LLM markup mistakes for a provider.

    Closes opening tags that should be self-closing (e.g. the LLM writes
    ``<expression value="happy">`` instead of ``<expression value="happy"/>`` — or
    ``<expr type="sound" label="laugh">`` instead of ``<expr type="sound" label="laugh"/>``).
    """
    if provider in _PROVIDER_MARKUP:
        text = _EXPR_UNCLOSED_RE.sub(r"\1/>", text)
    tags = _SELF_CLOSING_TAGS.get(provider)
    if not tags:
        return text
    pattern = "|".join(re.escape(t) for t in tags)
    return re.sub(rf"<({pattern})\b([^>]*[^/])\s*>", r"<\1\2/>", text)


def convert_markup(provider: str, text: str) -> str:
    """Convert framework-standard markup to a provider's native syntax."""
    if provider == "gemini":
        return _convert_gemini_expr(text)
    if provider in _PROVIDER_MARKUP:
        # lower expr markers first; the per-provider conversions below then
        # handle the intermediate framework-standard tags they produce
        text = _convert_expr(provider, text)
    if provider in ("inworld", "xai"):
        # <sound value="X"/> -> [X] (and <expression value="X"/> -> [X]); for xAI this
        # turns inline sounds into its native brackets while emotion/prosody stay <..>
        text = convert_expression_tags(text)
    if provider == "xai":
        # xAI has no <break>; map it to its native [pause]/[long-pause]
        text = _XAI_BREAK_RE.sub(_xai_break_to_bracket, text)
    if provider == "fishaudio":
        # <expression value="X"/> -> [very X] first (the intensified form steers
        # harder), then the generic pass lowers the remaining <sound value="X"/> -> [X]
        text = _FISHAUDIO_EXPRESSION_RE.sub(_fishaudio_expression_to_bracket, text)
        text = convert_expression_tags(text)
        text = _FISHAUDIO_BREAK_RE.sub(_fishaudio_break_to_bracket, text)
        # Fish's per-word stress marker: <emphasis>word</emphasis> -> [emphasis] word
        text = _FISHAUDIO_EMPHASIS_RE.sub(lambda m: f"[emphasis] {m.group(1).strip()}", text)
    if provider == "fishaudio_drama":
        # directions are free-form, so <expression value="X"/> lowers to [X] verbatim;
        # spans are already drama-3's native paired tags
        text = convert_expression_tags(text)
        text = _FISHAUDIO_BREAK_RE.sub(_fishaudio_drama_break_to_bracket, text)
    # <break> is otherwise passed through unchanged: Inworld accepts it as native SSML.
    return text
