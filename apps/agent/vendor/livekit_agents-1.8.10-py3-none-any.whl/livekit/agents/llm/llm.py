from __future__ import annotations

import asyncio
import contextlib
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterable, AsyncIterator, Iterator
from datetime import datetime, timezone
from types import TracebackType
from typing import Any, ClassVar, Generic, Literal, TypeVar

from opentelemetry import trace
from pydantic import BaseModel, ConfigDict, Field

from livekit import rtc
from livekit.agents.metrics.base import Metadata

from .. import utils
from .._exceptions import APIConnectionError, APIError, APIStatusError
from ..log import logger
from ..metrics import LLMMetrics
from ..telemetry import gen_ai as gen_ai_telemetry, input_delta, trace_types, tracer
from ..types import (
    DEFAULT_API_CONNECT_OPTIONS,
    NOT_GIVEN,
    APIConnectOptions,
    NotGivenOr,
)
from ..utils import aio
from .chat_context import ChatContext, ChatRole, MetricsMetadata
from .tool_context import Tool, ToolChoice


class CompletionUsage(BaseModel):
    completion_tokens: int
    """The number of tokens in the completion."""
    prompt_tokens: int
    """The number of input tokens used (includes cached tokens)."""
    prompt_cached_tokens: int = 0
    """The number of cached input tokens used."""
    cache_creation_tokens: int = 0
    """The number of tokens used to create the cache."""
    cache_read_tokens: int = 0
    """The number of tokens read from the cache."""
    reasoning_tokens: int = 0
    """The number of completion tokens spent on hidden reasoning.
    Already counted in ``completion_tokens``; do not add it to totals. Only reported by
    providers that break reasoning out separately (e.g. OpenAI-compatible responses
    carrying ``completion_tokens_details.reasoning_tokens``), 0 everywhere else.
    """
    total_tokens: int
    """The total number of tokens used (completion + prompt tokens)."""
    service_tier: str | None = None
    """The service tier used for processing the request (e.g. 'default', 'priority', 'flex').
    Returned by providers that support tiered processing (e.g. OpenAI)."""


class FunctionToolCall(BaseModel):
    type: Literal["function"] = "function"
    name: str
    arguments: str
    call_id: str
    extra: dict[str, Any] | None = None
    """Provider-specific extra data (e.g., Google thought signatures)."""


class CollectedResponse(BaseModel):
    text: str = ""
    tool_calls: list[FunctionToolCall] = Field(default_factory=list)
    usage: CompletionUsage | None = None
    extra: dict[str, Any] = Field(default_factory=dict)
    """Provider-specific extra data accumulated across chunks
    (e.g., xAI encrypted reasoning, Google thought signatures)."""


class ChoiceDelta(BaseModel):
    role: ChatRole | None = None
    content: str | None = None
    tool_calls: list[FunctionToolCall] = Field(default_factory=list)
    extra: dict[str, Any] | None = None
    """Provider-specific extra data (e.g., Google thought signatures)."""


class ChatChunk(BaseModel):
    id: str
    delta: ChoiceDelta | None = None
    usage: CompletionUsage | None = None

    def has_response(self) -> bool:
        """Whether this chunk delivered generation the caller can see.

        Token counts and provider metadata (a gateway deployment stamp, a thought
        signature) reach the caller without being output: they neither start the
        clock on time-to-first-token nor give a retry anything to duplicate.
        """
        return bool(self.delta and (self.delta.content or self.delta.tool_calls))


class LLMError(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    type: Literal["llm_error"] = "llm_error"
    timestamp: float
    label: str
    error: Exception = Field(..., exclude=True)
    recoverable: bool


TEvent = TypeVar("TEvent")


class LLM(
    ABC,
    rtc.EventEmitter[Literal["metrics_collected", "error"] | TEvent],
    Generic[TEvent],
):
    def __init__(self) -> None:
        super().__init__()
        self._label = f"{type(self).__module__}.{type(self).__name__}"
        self._prewarm_task: asyncio.Task[None] | None = None

    @property
    def label(self) -> str:
        return self._label

    @property
    def model(self) -> str:
        """Get the model name/identifier for this LLM instance.

        Returns:
            The model name if available, "unknown" otherwise.

        Note:
            Plugins should override this property to provide their model information.
        """
        return "unknown"

    @property
    def provider(self) -> str:
        """Get the provider name/identifier for this LLM instance.

        Returns:
            The provider name if available, "unknown" otherwise.

        Note:
            Plugins should override this property to provide their provider information.
        """
        return "unknown"

    @property
    def metrics_metadata(self) -> MetricsMetadata:
        """Metadata used to label turn metrics emitted for this LLM instance."""
        return {"model_name": self.model, "model_provider": self.provider}

    @abstractmethod
    def chat(
        self,
        *,
        chat_ctx: ChatContext,
        tools: list[Tool] | None = None,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
        parallel_tool_calls: NotGivenOr[bool] = NOT_GIVEN,
        tool_choice: NotGivenOr[ToolChoice] = NOT_GIVEN,
        extra_kwargs: NotGivenOr[dict[str, Any]] = NOT_GIVEN,
    ) -> LLMStream: ...

    def prewarm(self, *, loop: asyncio.AbstractEventLoop | None = None) -> None:
        """Pre-warm connection to the LLM service.

        Establishes DNS resolution and the TLS connection to the provider before the
        first inference request, reducing time-to-first-token on the initial reply.
        It is called automatically when an ``AgentSession`` is constructed and when an
        agent activity starts, but can also be called directly.

        Non-blocking (fire-and-forget) and idempotent. Providers enable it by
        overriding ``_prewarm_impl``.

        Args:
            loop: Event loop to schedule the prewarm request on. Defaults to the
                running event loop.
        """
        if type(self)._prewarm_impl is LLM._prewarm_impl:
            return  # no provider-specific prewarm implemented

        if self._prewarm_task is not None:
            return

        if loop is None:
            loop = asyncio.get_event_loop()

        async def _prewarm() -> None:
            try:
                await self._prewarm_impl()
            except Exception:
                pass

        self._prewarm_task = loop.create_task(_prewarm())

    async def _prewarm_impl(self) -> None:
        """Provider-specific prewarm request, overriding it enables ``prewarm()``.

        Implementations should perform a cheap, token-free request (e.g. listing
        models) using the same client that serves chat requests, so DNS + TLS are
        established and a keep-alive connection is left in the pool. Exceptions
        are swallowed by ``prewarm()``; subclasses overriding ``aclose`` must call
        ``await super().aclose()`` to cancel an in-flight prewarm."""

    async def aclose(self) -> None:
        if self._prewarm_task is not None:
            await aio.cancel_and_wait(self._prewarm_task)

    async def __aenter__(self) -> LLM:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()


class _LLMEventChannel(aio.Chan[ChatChunk]):
    def __init__(self) -> None:
        super().__init__()
        self.output_sent = False

    def send_nowait(self, value: ChatChunk) -> None:
        super().send_nowait(value)
        # A provider can raise before the consumer or metrics task reads the chunk.
        if value.delta and (value.delta.content or value.delta.tool_calls):
            self.output_sent = True


class LLMStream(ABC):
    _llm_request_span_name: ClassVar[str] = "llm_request"
    # None runs each attempt in the request span (an adapter whose wrapped streams have their own)
    _llm_attempt_span_name: ClassVar[str | None] = "llm_request_run"
    _genai_operation_name: ClassVar[str | None] = trace_types.GenAIOperationName.CHAT

    def __init__(
        self,
        llm: LLM,
        *,
        chat_ctx: ChatContext,
        tools: list[Tool],
        conn_options: APIConnectOptions,
    ) -> None:
        self._llm = llm
        self._chat_ctx = chat_ctx
        self._tools = tools
        self._conn_options = conn_options

        self._event_ch = _LLMEventChannel()
        self._retry_on_chunk_sent = True
        self._tee_aiter = aio.itertools.tee(self._event_ch, 2)
        self._event_aiter, monitor_aiter = self._tee_aiter
        self._current_attempt_has_error = False
        self._provider_request_ids: list[str] = []
        self._llm_request_span: trace.Span | None = None
        self._record_content = False
        self._metrics_task = asyncio.create_task(
            self._metrics_monitor_task(monitor_aiter), name="LLM._metrics_task"
        )

        # tells an enclosing `llm_node` span that this call is instrumented, so it does
        # not record the convention's attributes a second time
        gen_ai_telemetry.mark_inference_span_recorded()

        async def _traceable_main_task() -> None:
            with tracer.start_as_current_span(
                self._llm_request_span_name, end_on_exit=False
            ) as span:
                # Enabling capture later must not emit a partial response.
                self._record_content = (
                    span.is_recording() and gen_ai_telemetry.capture_content_enabled()
                )
                self._record_genai_request(span)
                await self._main_task()

        self._task = asyncio.create_task(_traceable_main_task(), name="LLM._main_task")
        self._task.add_done_callback(lambda _: self._event_ch.close())

    @abstractmethod
    async def _run(self) -> None: ...

    def _record_genai_request(self, span: trace.Span) -> None:
        """The GenAI inference span's request side, per the OTel GenAI conventions."""
        gen_ai_telemetry.set_request_attributes(
            span,
            operation=self._genai_operation_name,
            provider=self._llm.provider,
            model=self._llm.model,
            stream=True,
            output_type=trace_types.GenAIOutputType.TEXT,
        )
        # user attributes belong on the provider call, not on a delegating span (fallback)
        if self._genai_operation_name is not None and span.is_recording():
            if extra_attributes := gen_ai_telemetry.llm_request_attributes():
                span.set_attributes(extra_attributes)
        if self._record_content:
            if self._genai_operation_name is None and input_delta.active():
                # a delegating span (fallback) would only repeat the input its provider
                # span records, and take that span's place as the next delta's base
                gen_ai_telemetry.set_content_attributes(
                    span, tool_definitions=gen_ai_telemetry.to_tool_definitions(self._tools)
                )
                return
            delta = input_delta.compute(input_delta.LLM_REQUEST, self._chat_ctx, span)
            gen_ai_telemetry.set_content_attributes(
                span,
                system_instructions=delta.system_instructions(),
                input_messages=delta.input_messages(),
                tool_definitions=gen_ai_telemetry.to_tool_definitions(self._tools),
            )
            input_delta.set_attributes(span, delta)

    @contextlib.contextmanager
    def _attempt_span(self) -> Iterator[trace.Span]:
        if self._llm_attempt_span_name is None:
            yield trace.get_current_span()
            return

        with tracer.start_as_current_span(self._llm_attempt_span_name) as span:
            # a failed attempt names the model it asked without opening its parent
            gen_ai_telemetry.set_request_attributes(
                span, operation=None, provider=self._llm.provider, model=self._llm.model
            )
            yield span

    async def _main_task(self) -> None:
        self._llm_request_span = trace.get_current_span()

        for i in range(self._conn_options.max_retry + 1):
            try:
                with self._attempt_span() as attempt_span:
                    attempt_span.set_attribute(trace_types.ATTR_RETRY_COUNT, i)
                    # Reset per-attempt context ids; the monitor task populates
                    # this as ChatChunks arrive.
                    self._provider_request_ids = []
                    try:
                        await self._run()
                    finally:
                        if self._provider_request_ids:
                            attempt_span.set_attribute(
                                trace_types.ATTR_PROVIDER_REQUEST_IDS, self._provider_request_ids
                            )
                    return
            except APIError as e:
                # 499 (Client Closed Request) - close gracefully without raising
                if isinstance(e, APIStatusError) and e.status_code == 499:
                    return

                if not self._retry_on_chunk_sent and self._event_ch.output_sent:
                    e.retryable = False

                retry_interval = self._conn_options._interval_for_retry(i)

                if self._conn_options.max_retry == 0 or not e.retryable:
                    self._emit_error(e, recoverable=False)
                    raise
                elif i == self._conn_options.max_retry:
                    self._emit_error(e, recoverable=False)
                    raise APIConnectionError(
                        f"failed to generate LLM completion after {self._conn_options.max_retry + 1} attempts",  # noqa: E501
                    ) from e

                else:
                    self._emit_error(e, recoverable=True)
                    logger.warning(
                        f"failed to generate LLM completion: {e}, retrying in {retry_interval}s",  # noqa: E501
                        extra={
                            "llm": self._llm._label,
                            "attempt": i + 1,
                        },
                    )

                if retry_interval > 0:
                    await asyncio.sleep(retry_interval)

                # reset the flag when retrying
                self._current_attempt_has_error = False

            except Exception as e:
                self._emit_error(e, recoverable=False)
                raise

    def _emit_error(self, api_error: Exception, recoverable: bool) -> None:
        self._current_attempt_has_error = True
        self._llm.emit(
            "error",
            LLMError(
                timestamp=time.time(),
                label=self._llm._label,
                error=api_error,
                recoverable=recoverable,
            ),
        )

    @utils.log_exceptions(logger=logger)
    async def _metrics_monitor_task(self, event_aiter: AsyncIterable[ChatChunk]) -> None:
        start_time = time.perf_counter()
        ttft = -1.0
        request_id = ""
        usage: CompletionUsage | None = None

        response_content = ""
        tool_calls: list[FunctionToolCall] = []
        completion_start_time: str | None = None
        received_chunk = False

        async for ev in event_aiter:
            received_chunk = True
            request_id = ev.id
            if request_id and request_id not in self._provider_request_ids:
                self._provider_request_ids.append(request_id)
            # measured against generation, not the first chunk: a retry that follows a
            # contentless chunk would otherwise latch the clock on the failed attempt
            if ttft == -1.0 and ev.has_response():
                ttft = time.perf_counter() - start_time
                completion_start_time = datetime.now(timezone.utc).isoformat()

            if ev.delta:
                if ev.delta.content and self._record_content:
                    response_content += ev.delta.content
                if ev.delta.tool_calls:
                    tool_calls.extend(ev.delta.tool_calls)

            if ev.usage is not None:
                usage = ev.usage

        duration = time.perf_counter() - start_time

        # a request that never yielded a chunk has nothing to report; one that yielded
        # only metadata still carries token counts, and reports ttft as -1
        if self._current_attempt_has_error or not received_chunk:
            return

        metrics = LLMMetrics(
            timestamp=time.time(),
            request_id=request_id,
            ttft=ttft,
            duration=duration,
            cancelled=self._task.cancelled(),
            label=self._llm._label,
            completion_tokens=usage.completion_tokens if usage else 0,
            prompt_tokens=usage.prompt_tokens if usage else 0,
            prompt_cached_tokens=usage.prompt_cached_tokens if usage else 0,
            cache_creation_tokens=usage.cache_creation_tokens if usage else 0,
            reasoning_tokens=usage.reasoning_tokens if usage else 0,
            total_tokens=usage.total_tokens if usage else 0,
            tokens_per_second=usage.completion_tokens / duration if usage else 0.0,
            metadata=Metadata(
                model_name=self._llm.model,
                model_provider=self._llm.provider,
            ),
        )
        if self._llm_request_span:
            # livekit metrics attribute
            self._llm_request_span.set_attribute(
                trace_types.ATTR_LLM_METRICS, metrics.model_dump_json()
            )

            # the GenAI response side; the request side was recorded at span creation
            if self._genai_operation_name is not None:
                gen_ai_telemetry.set_usage_attributes(self._llm_request_span, metrics)
            finish_reason = gen_ai_telemetry.finish_reason_for(
                function_calls=tool_calls, interrupted=metrics.cancelled
            )
            gen_ai_telemetry.set_response_attributes(
                self._llm_request_span,
                response_id=request_id or None,
                model=self._llm.model,
                finish_reasons=[finish_reason],
                time_to_first_chunk=ttft if ttft >= 0 else None,
            )
            if self._record_content:
                gen_ai_telemetry.set_content_attributes(
                    self._llm_request_span,
                    output_messages=gen_ai_telemetry.to_output_messages(
                        text=response_content,
                        function_calls=tool_calls,
                        finish_reason=finish_reason,
                    ),
                )
            if completion_start_time:
                self._llm_request_span.set_attribute(
                    trace_types.ATTR_LANGFUSE_COMPLETION_START_TIME, f'"{completion_start_time}"'
                )

        self._llm.emit("metrics_collected", metrics)

    @property
    def chat_ctx(self) -> ChatContext:
        return self._chat_ctx

    @property
    def tools(self) -> list[Tool]:
        return self._tools

    async def aclose(self) -> None:
        await aio.cancel_and_wait(self._task)
        await self._metrics_task
        if self._llm_request_span:
            self._llm_request_span.end()
            self._llm_request_span = None

        await self._tee_aiter.aclose()

    async def __anext__(self) -> ChatChunk:
        try:
            val = await self._event_aiter.__anext__()
        except StopAsyncIteration:
            if not self._task.cancelled() and (exc := self._task.exception()):
                raise exc  # noqa: B904

            raise StopAsyncIteration from None

        return val

    def __aiter__(self) -> AsyncIterator[ChatChunk]:
        return self

    async def __aenter__(self) -> LLMStream:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    def to_str_iterable(self) -> AsyncIterable[str]:
        """
        Convert the LLMStream to an async iterable of strings.
        This assumes the stream will not call any tools.
        """

        async def _iterable() -> AsyncIterable[str]:
            async with self:
                async for chunk in self:
                    if chunk.delta and chunk.delta.content:
                        yield chunk.delta.content

        return _iterable()

    async def collect(self) -> CollectedResponse:
        """Collect the entire stream into a single response.

        Example:
            ```python
            from livekit.agents import llm

            response = await my_llm.chat(chat_ctx=ctx, tools=tools).collect()

            for tc in response.tool_calls:
                result = await llm.execute_function_call(tc, tool_ctx)
                ctx.insert(result.fnc_call)
                ctx.insert(result.fnc_call_out)
            ```
        """
        text_parts: list[str] = []
        tool_calls: list[FunctionToolCall] = []
        usage: CompletionUsage | None = None
        extra: dict[str, Any] = {}

        async with self:
            async for chunk in self:
                if chunk.delta:
                    if chunk.delta.content:
                        text_parts.append(chunk.delta.content)
                    if chunk.delta.tool_calls:
                        tool_calls.extend(chunk.delta.tool_calls)
                    if chunk.delta.extra:
                        extra.update(chunk.delta.extra)
                if chunk.usage is not None:
                    usage = chunk.usage

        return CollectedResponse(
            text="".join(text_parts).strip(),
            tool_calls=tool_calls,
            usage=usage,
            extra=extra,
        )
