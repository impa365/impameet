from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any

from livekit.agents import llm
from livekit.agents.log import logger

_DEFAULT_INLINE_INSTRUCTIONS_TEMPLATE = "<instructions>\n{content}\n</instructions>"


def parse_tool_call_arguments(fnc_call: llm.FunctionCall) -> dict[str, Any]:
    """Parse a stored function call's arguments into a dict for JSON-object providers.

    ``FunctionCall.arguments`` is only canonicalized when the model's output was
    parsed at the time of the call; when it can't be recovered the raw string is kept
    verbatim, and history restored via ``ChatContext.from_dict`` or produced by a
    custom ``llm_node`` never went through that path at all. The Anthropic, Google,
    and AWS formatters send the arguments as a JSON object, so formatting such history
    would otherwise raise on an unrelated later turn -- and because the bad entry
    stays in the context, every subsequent turn raises again.

    :func:`~livekit.agents.llm.utils.parse_function_arguments` does the recovery
    (strict parse, then ``json_repair``, then chat-template token stripping, then
    unwrapping double-encoded arguments). It raises ``ValueError`` when it cannot
    reach a dict, which is the right contract for a live call the model can retry,
    but not for replaying history: fall back to an empty object rather than
    fabricating arguments the model never sent, since the historical call already
    produced its output.
    """
    # imported here rather than at module scope: ``llm.utils`` imports
    # ``chat_context``, which imports this package, so a top-level import is a cycle
    from ..utils import parse_function_arguments

    arguments = fnc_call.arguments
    if not arguments:
        return {}
    try:
        return parse_function_arguments(arguments)
    except ValueError:
        logger.warning(
            "could not parse stored tool call arguments as a JSON object, using empty arguments",
            extra={"call_id": fnc_call.call_id, "tool_name": fnc_call.name},
        )
        return {}


def convert_mid_conversation_instructions(
    chat_ctx: llm.ChatContext,
    *,
    role: llm.ChatRole = "user",
    template: str = _DEFAULT_INLINE_INSTRUCTIONS_TEMPLATE,
    merge_dynamic_instructions: bool = True,
) -> llm.ChatContext:
    """Convert mid-conversation system messages to the given role to preserve their position.

    A system/developer message is kept as the base preamble only when it
    is the first one and no conversation content (messages, tool calls)
    precedes it. Every other system/developer message is rewritten with
    the given role, wrapped in ``template``; ones without text content
    are dropped so they can't shadow the preamble. This covers both
    mid-conversation instructions and per-turn instructions appended by
    ``generate_reply`` — including on the very first turn, when the
    preamble is the only other item. Without this, providers like Gemini,
    Anthropic, and AWS fall back to ``inject_dummy_user_message``
    (a literal ``"."`` user turn the model frequently responds to with
    "you didn't say anything").

    The one exception is the per-call instructions message
    (:data:`~livekit.agents.llm.chat_context.DYNAMIC_INSTRUCTIONS_MESSAGE_ID`)
    directly after the preamble: it is merged into the preamble so the per-call
    context keeps system priority on providers that take one system text. Pass
    ``merge_dynamic_instructions=False`` when the preamble will not reach the model
    (Gemini ``cached_content``); the message is then rewritten like any other.
    """
    preamble_allowed = True
    preamble: llm.ChatMessage | None = None
    items: list[llm.ChatItem] = []

    for item in chat_ctx.items:
        if item.type == "message" and item.role in ("system", "developer"):
            if preamble_allowed:
                preamble_allowed = False
                preamble = item
                items.append(item)
            elif (
                merge_dynamic_instructions
                and preamble is not None
                and len(items) == 1
                and _is_dynamic(item)
            ):
                items[0] = _merge_content(preamble, item)
            elif text := item.raw_text_content:
                items.append(
                    llm.ChatMessage(
                        id=item.id,
                        role=role,
                        content=[template.format(content=text)],
                        created_at=item.created_at,
                    )
                )
            continue

        if item.type in ("message", "function_call", "function_call_output"):
            preamble_allowed = False
        items.append(item)

    return llm.ChatContext(items)


def merge_dynamic_instructions(chat_ctx: llm.ChatContext) -> llm.ChatContext:
    """Merge the per-call instructions message into the preamble right before it.

    Without prompt cache breakpoints the split buys nothing, and a backend that keeps
    one system prompt demotes the second system message to a user turn (the LiveKit
    gateway does this for Gemini and Gemma). Merged, the request reads exactly as one
    ``Instructions.render()`` system prompt.
    """
    items = chat_ctx.items
    for i, item in enumerate(items):
        if item.type == "message" and item.role in ("system", "developer"):
            nxt = items[i + 1] if i + 1 < len(items) else None
            if nxt is None or nxt.type != "message" or not _is_dynamic(nxt):
                return chat_ctx
            return llm.ChatContext([*items[:i], _merge_content(item, nxt), *items[i + 2 :]])
        if item.type in ("message", "function_call", "function_call_output"):
            return chat_ctx
    return chat_ctx


def _is_dynamic(item: llm.ChatMessage) -> bool:
    # attribute access, not a module-level import: chat_context imports this package
    return item.id == llm.chat_context.DYNAMIC_INSTRUCTIONS_MESSAGE_ID


def _merge_content(preamble: llm.ChatMessage, item: llm.ChatMessage) -> llm.ChatMessage:
    return preamble.model_copy(update={"content": [*preamble.content, *item.content]})


def group_tool_calls(chat_ctx: llm.ChatContext) -> list[_ChatItemGroup]:
    """Group chat items (messages, function calls, and function outputs)
    into coherent groups based on their item IDs and call IDs.

    Each group will contain:
    - Zero or one assistant message
    - Zero or more function/tool calls
    - The corresponding function/tool outputs matched by call_id

    User and system messages are placed in their own individual groups.

    Args:
        chat_ctx: The chat context containing all conversation items

    Returns:
        A list of _ChatItemGroup objects representing the grouped conversation
    """
    item_groups: dict[str, _ChatItemGroup] = OrderedDict()  # item_id to group of items
    tool_outputs: list[llm.FunctionCallOutput] = []
    for item in chat_ctx.items:
        if (item.type == "message" and item.role == "assistant") or item.type == "function_call":
            # only assistant messages and function calls can be grouped
            # For function calls, use group_id if available (for parallel function calls),
            # otherwise fall back to id-based grouping for backwards compatibility
            if item.type == "function_call" and item.group_id:
                group_id = item.group_id
            else:
                group_id = item.id.split("/")[0]
            if group_id not in item_groups:
                item_groups[group_id] = _ChatItemGroup().add(item)
            else:
                item_groups[group_id].add(item)
        elif item.type == "function_call_output":
            tool_outputs.append(item)
        else:
            item_groups[item.id] = _ChatItemGroup().add(item)

    # add tool outputs to their corresponding groups
    call_id_to_group: dict[str, _ChatItemGroup] = {
        tool_call.call_id: group for group in item_groups.values() for tool_call in group.tool_calls
    }
    for tool_output in tool_outputs:
        if tool_output.call_id not in call_id_to_group:
            logger.warning(
                "function output missing the corresponding function call, ignoring",
                extra={"call_id": tool_output.call_id, "tool_name": tool_output.name},
            )
            continue

        call_id_to_group[tool_output.call_id].add(tool_output)

    # validate that each group and remove invalid tool calls and tool outputs
    for group in item_groups.values():
        group.remove_invalid_tool_calls()

    return list(item_groups.values())


@dataclass
class _ChatItemGroup:
    message: llm.ChatMessage | None = None
    tool_calls: list[llm.FunctionCall] = field(default_factory=list)
    tool_outputs: list[llm.FunctionCallOutput] = field(default_factory=list)

    def add(self, item: llm.ChatItem) -> _ChatItemGroup:
        if item.type == "message":
            assert self.message is None, "only one message is allowed in a group"
            self.message = item
        elif item.type == "function_call":
            self.tool_calls.append(item)
        elif item.type == "function_call_output":
            self.tool_outputs.append(item)
        return self

    def remove_invalid_tool_calls(self) -> None:
        if len(self.tool_calls) == len(self.tool_outputs):
            return

        valid_call_ids = {call.call_id for call in self.tool_calls} & {
            output.call_id for output in self.tool_outputs
        }

        valid_tool_calls = []
        valid_tool_outputs = []

        for tool_call in self.tool_calls:
            if tool_call.call_id not in valid_call_ids:
                logger.warning(
                    "function call missing the corresponding function output, ignoring",
                    extra={"call_id": tool_call.call_id, "tool_name": tool_call.name},
                )
                continue
            valid_tool_calls.append(tool_call)

        for tool_output in self.tool_outputs:
            if tool_output.call_id not in valid_call_ids:
                logger.warning(
                    "function output missing the corresponding function call, ignoring",
                    extra={"call_id": tool_output.call_id, "tool_name": tool_output.name},
                )
                continue
            valid_tool_outputs.append(tool_output)

        self.tool_calls = valid_tool_calls
        self.tool_outputs = valid_tool_outputs

    def flatten(self) -> list[llm.ChatItem]:
        items: list[llm.ChatItem] = []
        if self.message:
            items.append(self.message)
        items.extend(self.tool_calls)
        items.extend(self.tool_outputs)
        return items
