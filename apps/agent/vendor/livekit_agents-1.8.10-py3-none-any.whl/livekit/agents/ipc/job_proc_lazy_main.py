from __future__ import annotations

from multiprocessing import current_process

if current_process().name == "job_proc":
    import signal

    # ignore signals in the jobs process (the parent process will handle them)
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)

    if hasattr(signal, "SIGUSR1"):
        from .proc_client import _dump_stack_traces

        signal.signal(signal.SIGUSR1, _dump_stack_traces)

import asyncio
import contextlib
import contextvars
import socket
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

from opentelemetry import context as otel_context, trace

from livekit import rtc
from livekit.protocol import agent

from ..job import JobContext, JobExecutorType, JobProcess, RunningJobInfo, _JobContextVar
from ..log import _add_global_log_fields, logger
from ..telemetry import loop_monitor, trace_types, tracer, utils as trace_utils
from ..telemetry.traces import _resource
from ..types import ATTRIBUTE_SIMULATOR
from ..utils import aio, http_context, log_exceptions, shortuuid
from .channel import Message
from .inference_executor import InferenceExecutor
from .proc_client import _dump_stack_traces_impl, _ProcClient
from .proto import (
    DumpStackTraceRequest,
    Exiting,
    InferenceRequest,
    InferenceResponse,
    InitializeRequest,
    JoinTiming,
    ShutdownRequest,
    ShutdownRequestAck,
    ShuttingDown,
    StartJobRequest,
)

if TYPE_CHECKING:
    from ..voice.remote_session import SessionHost

# Defensive timeout for AgentSession.aclose() during job shutdown. Hardcoded for now
# as a guardrail against close paths that hang indefinitely. If aclose() does not
# return in this window, the rest of the shutdown sequence (on_session_end,
# ShuttingDown ack, room.disconnect, shutdown callbacks) runs anyway so user-
# registered shutdown callbacks are not silently dropped.
_SESSION_ACLOSE_TIMEOUT = 60.0


@dataclass
class ProcStartArgs:
    initialize_process_fnc: Callable[[JobProcess], Any]
    job_entrypoint_fnc: Callable[[JobContext], Any]
    session_end_fnc: Callable[[JobContext], Awaitable[None]] | None
    session_end_timeout: float
    user_arguments: Any | None
    mp_cch: socket.socket
    log_cch: socket.socket
    logger_levels: dict[str, int]
    simulation_end_fnc: Callable[[Any], Any] | None = None


def proc_main(args: ProcStartArgs) -> None:
    import logging

    from .log_queue import LogQueueHandler
    from .proc_client import _ProcClient

    root_logger = logging.getLogger()
    for name, level in args.logger_levels.items():
        logging.getLogger(name).setLevel(level)

    log_cch = aio.duplex_unix._Duplex.open(args.log_cch)
    log_handler = LogQueueHandler(log_cch)
    _add_global_log_fields(log_handler)
    root_logger.addHandler(log_handler)

    job_proc = _JobProc(
        args.initialize_process_fnc,
        args.job_entrypoint_fnc,
        args.session_end_fnc,
        session_end_timeout=args.session_end_timeout,
        executor_type=JobExecutorType.PROCESS,
        user_arguments=args.user_arguments,
        simulation_end_fnc=args.simulation_end_fnc,
    )

    client = _ProcClient(args.mp_cch, args.log_cch, job_proc.initialize, job_proc.entrypoint)
    try:
        client.initialize()
    except Exception:
        log_handler.close()
        return  # initialization failed, exit (initialize will send an error to the worker)

    client.run()

    import sys
    import threading
    import traceback

    for t in threading.enumerate():
        if threading.main_thread() == t:
            continue

        if threading.current_thread() == t:
            continue

        if t == log_handler.thread:
            continue

        if t.daemon:
            continue

        from concurrent.futures.thread import _threads_queues

        if t in _threads_queues:
            continue

        t.join(timeout=0.25)

        frames = sys._current_frames()
        frame = frames.get(t.ident)  # type: ignore

        logger.warning(
            f"non-daemon thread `{t.name}` may prevent the process from exiting",
            extra={"thread_id": t.native_id, "thread_name": t.name},
        )

        if frame is not None:
            logger.warning("stack for `%s`:\n%s", t.name, "".join(traceback.format_stack(frame)))

    log_handler.close()


class _InfClient(InferenceExecutor):
    def __init__(self, proc_client: _ProcClient) -> None:
        self._client = proc_client
        self._active_requests: dict[str, asyncio.Future[InferenceResponse]] = {}

    async def do_inference(self, method: str, data: bytes) -> bytes | None:
        request_id = shortuuid("inference_job_")
        fut = asyncio.Future[InferenceResponse]()
        self._active_requests[request_id] = fut

        try:
            await self._client.send(
                InferenceRequest(request_id=request_id, method=method, data=data),
            )
        except Exception:
            if not fut.done():
                fut.cancel()
            self._active_requests.pop(request_id, None)
            raise

        inf_resp = await fut
        if inf_resp.error:
            raise RuntimeError(f"inference of {method} failed: {inf_resp.error}")

        return inf_resp.data

    def close(self) -> None:
        for fut in self._active_requests.values():
            if not fut.done():
                fut.cancel()
        self._active_requests.clear()

    def _on_inference_response(self, resp: InferenceResponse) -> None:
        fut = self._active_requests.pop(resp.request_id, None)
        if fut is None:
            logger.warning("received unexpected inference response", extra={"resp": resp})
            return

        with contextlib.suppress(asyncio.InvalidStateError):
            fut.set_result(resp)


@dataclass
class _ShutdownInfo:
    user_initiated: bool
    reason: str


class _JobProc:
    def __init__(
        self,
        initialize_process_fnc: Callable[[JobProcess], Any],
        job_entrypoint_fnc: Callable[[JobContext], Any],
        session_end_fnc: Callable[[JobContext], Awaitable[None]] | None,
        *,
        session_end_timeout: float,
        executor_type: JobExecutorType,
        user_arguments: Any | None = None,
        simulation_end_fnc: Callable[[Any], Any] | None = None,
    ) -> None:
        self._executor_type = executor_type
        self._user_arguments = user_arguments
        self._initialize_process_fnc = initialize_process_fnc
        self._job_entrypoint_fnc = job_entrypoint_fnc
        self._session_end_fnc = session_end_fnc
        self._simulation_end_fnc = simulation_end_fnc
        self._session_end_timeout = session_end_timeout
        self._job_task: asyncio.Task[None] | None = None
        self._join_timing_task: asyncio.Task[None] | None = None
        self._entrypoint_started_mono = 0.0

        # used to warn users if both connect and shutdown are not called inside the job_entry
        self._ctx_connect_called = False
        self._ctx_shutdown_called = False

    @property
    def has_running_job(self) -> bool:
        return self._job_task is not None

    def initialize(self, init_req: InitializeRequest, client: _ProcClient) -> None:
        self._client = client
        self._inf_client = _InfClient(client)
        self._job_proc = JobProcess(
            executor_type=self._executor_type,
            user_arguments=self._user_arguments,
            http_proxy=init_req.http_proxy or None,
        )
        # the framework's warm-up; a no-op under a forkserver, which imported it already
        from . import _preload  # noqa: F401

        # resource detection starts and joins threads; per process, so not in the forkserver
        _resource({})

        self._initialize_process_fnc(self._job_proc)

    @log_exceptions(logger=logger)
    async def entrypoint(self, cch: aio.ChanReceiver[Message]) -> None:
        self._exit_proc_flag = asyncio.Event()
        self._shutdown_fut: asyncio.Future[_ShutdownInfo] = asyncio.Future()
        self._entrypoint_span_context: otel_context.Context | None = None

        @log_exceptions(logger=logger)
        async def _read_ipc_task() -> None:
            async for msg in cch:
                if isinstance(msg, StartJobRequest):
                    if self.has_running_job:
                        logger.warning("trying to start a new job while one is already running")
                        continue

                    self._start_job(msg)
                if isinstance(msg, ShutdownRequest):
                    await self._client.send(ShutdownRequestAck())

                    if not self.has_running_job:
                        await self._client.send(ShuttingDown())
                        self._exit_proc_flag.set()
                        break  # exit immediately

                    with contextlib.suppress(asyncio.InvalidStateError):
                        self._shutdown_fut.set_result(
                            _ShutdownInfo(
                                reason=msg.reason or "parent process shutdown",
                                user_initiated=False,
                            )
                        )

                if isinstance(msg, InferenceResponse):
                    self._inf_client._on_inference_response(msg)

                if isinstance(msg, DumpStackTraceRequest):
                    _dump_stack_traces_impl()

            # unblock any pending do_inference() calls
            self._inf_client.close()

        read_task = asyncio.create_task(_read_ipc_task(), name="job_ipc_read")
        try:
            await self._exit_proc_flag.wait()
        finally:
            # ensure cleanup on cancellation (e.g. parent channel closes)
            if self._job_task is not None:
                await aio.cancel_and_wait(self._job_task)
            await aio.cancel_and_wait(read_task)

    def _start_job(self, msg: StartJobRequest) -> None:
        if msg.running_job.fake_job:
            from .mock_room import create_mock_room

            self._room = cast(rtc.Room, create_mock_room())
        else:
            self._room = rtc.Room()

        @self._room.on("disconnected")
        def _on_room_disconnected(*args: Any) -> None:
            with contextlib.suppress(asyncio.InvalidStateError):
                self._shutdown_fut.set_result(
                    _ShutdownInfo(user_initiated=False, reason="room disconnected")
                )

        def _on_ctx_connect() -> None:
            self._ctx_connect_called = True
            timing = _join_timing(
                self._job_ctx._info,
                self._entrypoint_started_mono,
                self._job_ctx._connect_called_mono,
                self._job_ctx._connected_mono,
            )
            if timing is not None:
                self._join_timing_task = asyncio.create_task(
                    self._client.send(JoinTiming(timing=timing))
                )

        def _on_ctx_shutdown(reason: str) -> None:
            self._ctx_shutdown_called = True

            with contextlib.suppress(asyncio.InvalidStateError):
                self._shutdown_fut.set_result(
                    _ShutdownInfo(user_initiated=True, reason=reason or "user requested")
                )

        self._room._info.name = msg.running_job.job.room.name

        self._job_ctx = JobContext(
            proc=self._job_proc,
            info=msg.running_job,
            room=self._room,
            on_connect=_on_ctx_connect,
            on_shutdown=_on_ctx_shutdown,
            inference_executor=self._inf_client,
        )
        # Reachable from SessionHost (via get_job_context) when a simulation finalizes.
        self._job_ctx._simulation_end_fnc = self._simulation_end_fnc

        def _exit_proc_cb(_: asyncio.Task[None]) -> None:
            self._exit_proc_flag.set()

        self._job_task = asyncio.create_task(self._run_job_task(), name="job_task")
        self._job_task.add_done_callback(_exit_proc_cb)

    @log_exceptions(logger=logger)
    async def _run_job_task(self) -> None:
        self._job_ctx._on_setup()
        self._job_ctx._start_log_buffering()
        # before the first span: without a provider the job's root would not record
        self._job_ctx._prepare_telemetry()

        job_ctx_token = _JobContextVar.set(self._job_ctx)
        http_context._new_session_ctx()

        self._entrypoint_started_mono = time.monotonic()
        # the job's root span, from the availability request to the end of shutdown; the
        # entrypoint returning is an event on it
        job_span = _start_job_span(self._job_ctx)
        self._entrypoint_span_context = trace.set_span_in_context(job_span)

        async def _traceable_entrypoint(job_ctx: JobContext) -> None:
            with tracer.use_span(
                job_span, end_on_exit=False, record_exception=False, set_status_on_exception=False
            ):
                # the loop monitor's heartbeat predates the job: give its reports this context
                if (monitor := loop_monitor.get_monitor(asyncio.get_running_loop())) is not None:
                    monitor.set_report_context(contextvars.copy_context())
                try:
                    await self._job_entrypoint_fnc(job_ctx)
                except asyncio.CancelledError:
                    job_span.add_event("entrypoint_cancelled")
                    raise
                except Exception as e:
                    trace_utils.record_exception(job_span, e)
                    raise
                job_span.add_event("entrypoint_returned")

        job_entry_task = asyncio.create_task(
            _traceable_entrypoint(self._job_ctx), name="job_user_entrypoint"
        )

        async def _warn_not_connected_task() -> None:
            if self._job_ctx.is_fake_job():
                return

            await asyncio.sleep(10)
            if not self._ctx_connect_called and not self._ctx_shutdown_called:
                logger.warning(
                    "The room connection was not established within 10 seconds after calling job_entry. "  # noqa: E501
                    "This might mean that job_ctx.connect() was never invoked, or that no AgentSession with an active RoomIO has been started."
                )

        warn_unconnected_task = asyncio.create_task(_warn_not_connected_task())
        job_entry_task.add_done_callback(lambda _: warn_unconnected_task.cancel())

        def _on_entry_done(t: asyncio.Task[Any]) -> None:
            if not t.cancelled() and t.exception():
                logger.error(
                    "unhandled exception while running the job task",
                    exc_info=t.exception(),
                )
                # if the process crashes before ctx.connect(), shutdown_fut will never resolve
                # we'll force it to trigger shutdown so _on_cleanup can flush crash logs
                with contextlib.suppress(asyncio.InvalidStateError):
                    self._shutdown_fut.set_result(
                        _ShutdownInfo(user_initiated=False, reason="job crashed")
                    )
            elif not self._ctx_connect_called and not self._ctx_shutdown_called:
                if self._job_ctx.is_fake_job():
                    return

                logger.warning(
                    "The job task completed without establishing a connection or performing a proper shutdown. "  # noqa: E501
                    "Ensure that job_ctx.connect()/job_ctx.shutdown() is called and the job is correctly finalized."  # noqa: E501
                )

        job_entry_task.add_done_callback(_on_entry_done)

        try:
            shutdown_info = await self._shutdown_fut
            with tracer.start_as_current_span(
                "job_shutdown",
                context=self._entrypoint_span_context,
                attributes={
                    trace_types.ATTR_SHUTDOWN_REASON: shutdown_info.reason,
                    trace_types.ATTR_SHUTDOWN_USER_INITIATED: shutdown_info.user_initiated,
                },
            ):
                await self._shutdown_job(job_entry_task, shutdown_info)
        finally:
            # whatever happened above (a cancel while waiting, a close that raised), the job
            # ends: root span, temp dir, per-job telemetry state
            job_span.end()

            if tasks := self._job_ctx._pending_tasks:
                await aio.cancel_and_wait(*tasks)

            await self._job_ctx._on_cleanup()
            await http_context._close_http_ctx()
            _JobContextVar.reset(job_ctx_token)

    async def _shutdown_job(
        self, job_entry_task: asyncio.Task[None], shutdown_info: _ShutdownInfo
    ) -> None:
        # wait for the entrypoint to finish, cancel if it takes too long
        if not job_entry_task.done():
            try:
                await asyncio.wait_for(asyncio.shield(job_entry_task), timeout=15)
            except asyncio.TimeoutError:
                logger.warning("entrypoint did not exit in time, cancelling")
                await aio.cancel_and_wait(job_entry_task)
            except Exception:
                # entrypoint raised; already logged via _on_entry_done.
                # swallow so shutdown callbacks still run.
                pass

        if session := self._job_ctx._primary_agent_session:
            try:
                await asyncio.wait_for(session.aclose(), timeout=_SESSION_ACLOSE_TIMEOUT)
            except asyncio.TimeoutError:
                logger.error(
                    "AgentSession.aclose() timed out after %.1fs; "
                    "proceeding with shutdown so registered callbacks still run.",
                    _SESSION_ACLOSE_TIMEOUT,
                )

        if self._session_end_fnc:
            with tracer.start_as_current_span(
                "on_session_end",
                attributes={trace_types.ATTR_CALLBACK_NAME: _callback_name(self._session_end_fnc)},
            ) as span:
                try:
                    await asyncio.wait_for(
                        self._session_end_fnc(self._job_ctx),
                        timeout=self._session_end_timeout,
                    )
                except asyncio.TimeoutError as e:
                    trace_utils.record_exception(span, e)
                    logger.error("on_session_end timed out after %ds", self._session_end_timeout)
                except Exception as e:
                    trace_utils.record_exception(span, e)
                    logger.exception("error while executing the on_session_end callback")

        with tracer.start_as_current_span("session_end_upload") as span:
            try:
                await self._job_ctx._on_session_end()
            except Exception as e:
                trace_utils.record_exception(span, e)
                logger.exception("error in job_ctx._on_session_end")

        # the worker reports the join timing once per job, so it must go out before the job exits
        if self._join_timing_task is not None:
            with contextlib.suppress(Exception):
                await self._join_timing_task

        if (session_host := self._job_ctx._session_host) is not None:
            if self._job_ctx.simulation_context() is not None:
                await self._wait_for_simulation_finalize(session_host)
            await session_host.aclose()

        await self._client.send(ShuttingDown())

        logger.debug(
            "shutting down job task",
            extra={"reason": shutdown_info.reason, "user_initiated": shutdown_info.user_initiated},
        )
        await self._client.send(Exiting(reason=shutdown_info.reason))
        with tracer.start_as_current_span("room_disconnect"):
            await self._room.disconnect()

        async def _traced_shutdown_callback(
            callback: Callable[[str], Awaitable[None]],
        ) -> None:
            if _is_framework_callback(callback):
                # framework callbacks (the session's own close) get no span of their own
                await callback(shutdown_info.reason)
                return
            # a hung callback here is why jobs hit the supervisor's shutdown deadline
            with tracer.start_as_current_span(
                "shutdown_callback",
                attributes={trace_types.ATTR_CALLBACK_NAME: _callback_name(callback)},
            ):
                await callback(shutdown_info.reason)

        try:
            shutdown_tasks = []
            for callback in self._job_ctx._shutdown_callbacks:
                shutdown_tasks.append(
                    asyncio.create_task(
                        _traced_shutdown_callback(callback), name="job_shutdown_callback"
                    )
                )

            await asyncio.gather(*shutdown_tasks)
        except Exception:
            logger.exception("error while shutting down the job")

    async def _wait_for_simulation_finalize(self, session_host: SessionHost) -> None:
        # the simulator asks for the on_simulation_end verdict only once it has judged
        # the run, which can be well after the agent ended the call; it can no longer
        # ask once it has left the room
        room = self._room
        simulator_left = asyncio.Event()

        def _check_simulator_left(*_: Any) -> None:
            if not room.isconnected() or not any(
                ATTRIBUTE_SIMULATOR in p.attributes for p in room.remote_participants.values()
            ):
                simulator_left.set()

        room.on("participant_disconnected", _check_simulator_left)
        room.on("disconnected", _check_simulator_left)
        _check_simulator_left()

        finalized = asyncio.create_task(session_host.wait_for_simulation_finalized())
        left = asyncio.create_task(simulator_left.wait())
        try:
            done, _ = await asyncio.wait(
                {finalized, left},
                timeout=self._session_end_timeout,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if not done:
                logger.warning("simulator did not finalize within %.1fs", self._session_end_timeout)
        finally:
            room.off("participant_disconnected", _check_simulator_left)
            room.off("disconnected", _check_simulator_left)
            await aio.cancel_and_wait(finalized, left)


def _is_framework_callback(fnc: Any) -> bool:
    """Registered by livekit-agents itself rather than by the user's entrypoint."""
    module = getattr(fnc, "__module__", None) or ""
    return module == "livekit.agents" or module.startswith("livekit.agents.")


def _callback_name(fnc: Any) -> str:
    return str(getattr(fnc, "__qualname__", None) or getattr(fnc, "__name__", None) or repr(fnc))


def _server_timestamp_seconds(value: int) -> float:
    """``JobState`` timestamps are int64; the server writes unix nanoseconds. Be tolerant
    of milliseconds/seconds should that ever change."""
    if value > 1e17:
        return value / 1e9
    if value > 1e11:
        return value / 1e3
    return float(value)


def _start_job_span(job_ctx: JobContext) -> trace.Span:
    """The job's root span, ``job_entrypoint``, back-dated to the availability request; ended
    by ``_run_job_task`` after the shutdown sequence."""
    job = job_ctx.job
    info = job_ctx._info
    entrypoint_started_at = time.time()
    start_time_ns = int(info.received_at * 1e9) if info.received_at else None
    span = tracer.start_span(
        "job_entrypoint",
        start_time=start_time_ns,
        attributes={
            trace_types.ATTR_JOB_ID: job.id,
            trace_types.ATTR_AGENT_NAME: job.agent_name,
            trace_types.ATTR_ROOM_NAME: job.room.name,
            trace_types.ATTR_ROOM_SID: job.room.sid,
            trace_types.ATTR_DISPATCH_ID: job.dispatch_id,
            trace_types.ATTR_WORKER_ID: info.worker_id,
            trace_types.ATTR_JOB_AGENT_ID: job.state.agent_id,
        },
    )
    _record_dispatch_timeline(span, info, entrypoint_started_at)
    return span


def _record_dispatch_timeline(
    span: trace.Span, info: RunningJobInfo, entrypoint_started_at: float
) -> None:
    """Stamp the dispatch stages on ``span``: one timestamped event per stage instant, and
    the seconds between adjacent stages as attributes (they sum to the dispatch latency).

    Timestamps travel from the worker through ``StartJobRequest``; a zero means the stage
    is unknown (simulation, console, resumed job) and is skipped rather than guessed."""
    stages = [
        ("job_received", info.received_at),
        ("job_accepted", info.accepted_at),
        ("job_assigned", info.assigned_at),
        ("process_assigned", info.launched_at),
        ("entrypoint_started", entrypoint_started_at),
    ]
    for event_name, ts in stages:
        if ts:
            span.add_event(event_name, timestamp=int(ts * 1e9))

    def _gap(attr: str, start: float, end: float) -> None:
        if start and end:
            span.set_attribute(attr, max(end - start, 0.0))

    _gap(trace_types.ATTR_JOB_ACCEPT_LATENCY, info.received_at, info.accepted_at)
    _gap(trace_types.ATTR_JOB_ASSIGNMENT_LATENCY, info.accepted_at, info.assigned_at)
    _gap(trace_types.ATTR_JOB_LAUNCH_LATENCY, info.assigned_at, info.launched_at)
    _gap(trace_types.ATTR_JOB_ENTRYPOINT_LATENCY, info.launched_at, entrypoint_started_at)
    _gap(trace_types.ATTR_JOB_DISPATCH_LATENCY, info.received_at, entrypoint_started_at)
    if (server_started := info.job.state.started_at) > 0:
        # the server's own start time, for lining up with server-side traces
        started = _server_timestamp_seconds(server_started)
        span.add_event("job_started_on_server", timestamp=int(started * 1e9))


def _join_timing(
    info: RunningJobInfo,
    entrypoint_started_mono: float,
    connect_called_mono: float,
    connected_mono: float,
) -> agent.JobJoinTiming | None:
    """The worker-side instants of the join, in microseconds of the host's monotonic clock.
    None when one is unknown (simulation, console, resumed job)."""
    stamps = [
        info.received_mono,
        info.accepted_mono,
        info.assigned_mono,
        info.launched_mono,
        entrypoint_started_mono,
        connect_called_mono,
        connected_mono,
    ]
    if not all(stamps):
        return None
    us = [round(s * 1e6) for s in stamps]
    return agent.JobJoinTiming(
        offer_received_us=us[0],
        accepted_us=us[1],
        assignment_received_us=us[2],
        launched_us=us[3],
        launch_warm=info.launched_warm,
        entrypoint_started_us=us[4],
        connect_called_us=us[5],
        connected_us=us[6],
    )


@dataclass
class ThreadStartArgs:
    initialize_process_fnc: Callable[[JobProcess], Any]
    job_entrypoint_fnc: Callable[[JobContext], Any]
    session_end_fnc: Callable[[JobContext], Awaitable[None]] | None
    session_end_timeout: float
    join_fnc: Callable[[], None]
    mp_cch: socket.socket
    user_arguments: Any | None
    simulation_end_fnc: Callable[[Any], Any] | None = None


def thread_main(
    args: ThreadStartArgs,
) -> None:
    """main function for the job process when using the ThreadedJobRunner"""
    try:
        from .proc_client import _ProcClient

        job_proc = _JobProc(
            args.initialize_process_fnc,
            args.job_entrypoint_fnc,
            args.session_end_fnc,
            session_end_timeout=args.session_end_timeout,
            executor_type=JobExecutorType.THREAD,
            user_arguments=args.user_arguments,
            simulation_end_fnc=args.simulation_end_fnc,
        )

        client = _ProcClient(args.mp_cch, None, job_proc.initialize, job_proc.entrypoint)
        client.initialize()
        client.run()
    finally:
        args.join_fnc()
