from __future__ import annotations

import asyncio
import contextlib
import contextvars
import heapq
import json
import time
from collections.abc import AsyncGenerator, AsyncIterable, Coroutine, Iterator
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from opentelemetry import context as otel_context, trace

from livekit import rtc
from livekit.agents.llm.realtime import MessageGeneration
from livekit.agents.metrics.base import Metadata

from .. import inference, llm, stt, tts, utils, vad
from ..llm.chat_context import Instructions
from ..llm.realtime_fallback_adapter import _FallbackRealtimeSession
from ..llm.tool_context import (
    StopResponse,
    ToolError,
    ToolFlag,
    get_fnc_tool_names,
)
from ..log import logger
from ..metrics import (
    EOUMetrics,
    LLMMetrics,
    RealtimeModelMetrics,
    STTMetrics,
    TTSMetrics,
    VADMetrics,
)
from ..telemetry import (
    gen_ai as gen_ai_telemetry,
    input_delta,
    otel_metrics,
    trace_types,
    tracer,
    utils as trace_utils,
)
from ..tokenize.basic import split_words
from ..types import NOT_GIVEN, FlushSentinel, NotGivenOr
from ..utils.misc import is_given
from ._utils import _set_participant_attributes
from .agent import (
    Agent,
    AgentTask,
    ModelSettings,
    _get_activity_task_info,
    _set_activity_task_info,
)
from .audio_recognition import (
    AudioRecognition,
    RecognitionHooks,
    _EndOfTurnInfo,
    _PreemptiveGenerationInfo,
    _PreflightStaleInfo,
    _STTPipeline,
)
from .endpointing import create_endpointing
from .events import (
    AgentFalseInterruptionEvent,
    AgentState,
    AgentStateChangedEvent,
    EotPredictionEvent,
    ErrorEvent,
    FunctionToolsExecutedEvent,
    MetricsCollectedEvent,
    SessionUsageUpdatedEvent,
    SpeechCreatedEvent,
    UserInputTranscribedEvent,
    UserTranscriptionTimeoutEvent,
    UserTurnExceededEvent,
    _AgentBackchannelOpportunityEvent,
)
from .generation import (
    ToolExecutionOutput,
    _AudioOutput,
    _ForwardOutput,
    _inject_running_tool_calls,
    _interrupted_tool_output,
    _release_running_tools,
    _strip_assistant_markup,
    _strip_running_tool_calls,
    _TextOutput,
    _time_to_first_sentence,
    _TTSGenerationData,
    forward_generation,
    mark_instructions_cache_boundary,
    perform_audio_forwarding,
    perform_llm_inference,
    perform_text_forwarding,
    perform_tool_executions,
    perform_tts_inference,
    remove_expressive_instructions,
    remove_instructions,
    update_expressive_instructions,
    update_instructions,
)
from .speech_handle import DEFAULT_INPUT_DETAILS, InputDetails, InterruptionSource, SpeechHandle
from .tool_executor import (
    _reply_tool_choice,
    _resolve_async_tool_options,
    _RunningTasks,
    _ToolExecutor,
)
from .turn import (
    EndpointingOptions,
    PreemptiveGenerationOptions,
    TurnDetectionMode,
    _resolve_endpointing,
    _StreamingTurnDetector,
    _StreamingTurnDetectorStream,
)

if TYPE_CHECKING:
    from ..llm import mcp
    from .agent_session import AgentSession, ExpressiveOptions


_AgentActivityContextVar = contextvars.ContextVar["AgentActivity"]("agents_activity")
_SpeechHandleContextVar = contextvars.ContextVar["SpeechHandle"]("agents_speech_handle")
_IdleHoldContextVar = contextvars.ContextVar[bool]("agents_idle_hold", default=False)


async def _aligned_transcript_or_text(
    timed_texts: AsyncIterable[str], text: AsyncIterable[str]
) -> AsyncGenerator[str, None]:
    """Forward the TTS-aligned transcript, falling back to the spoken text.

    ``aligned_transcript`` says the TTS was asked for word timings, not that this
    model/language pair returns any. When none arrive the aligned stream is simply
    empty, and forwarding it alone would leave the turn with no transcript.
    """
    aligned = False
    async for timed_text in timed_texts:
        aligned = True
        yield timed_text

    if not aligned:
        logger.warning(
            "no aligned transcript was returned from tts, "
            "forwarding the generated text without word timings"
        )
        async for chunk in text:
            yield chunk


def _transcripts_equivalent(first: str, second: str | None) -> bool:
    if first == second:
        return True
    if second is None:
        return False

    first_words = [
        word.casefold()
        for word, _, _ in split_words(first, ignore_punctuation=True, split_character=True)
    ]
    second_words = [
        word.casefold()
        for word, _, _ in split_words(second, ignore_punctuation=True, split_character=True)
    ]
    return bool(first_words) and first_words == second_words


class ActivityClosedError(Exception):
    """Raised by ``wait_for_idle`` when the target activity/session has closed."""


@dataclass
class _OnEnterData:
    session: AgentSession
    agent: Agent


_OnEnterContextVar = contextvars.ContextVar["_OnEnterData | None"]("agents_activity_on_enter")


@dataclass
class _ReusableResources:
    stt_pipeline: _STTPipeline | None = None
    rt_session: llm.RealtimeSession | None = None
    turn_detector_stream: _StreamingTurnDetectorStream | None = None

    async def cleanup(self) -> None:
        tasks = []
        if self.stt_pipeline is not None:
            tasks.append(self.stt_pipeline.aclose())
            self.stt_pipeline = None
        if self.rt_session is not None:
            tasks.append(self.rt_session.aclose())
            self.rt_session = None
        if self.turn_detector_stream is not None:
            tasks.append(self.turn_detector_stream.aclose())
            self.turn_detector_stream = None

        if tasks:
            outputs = await asyncio.gather(*tasks, return_exceptions=True)
            for output in outputs:
                if isinstance(output, Exception):
                    logger.error("error cleaning up reusable resources", exc_info=output)


@dataclass
class _PreemptiveGeneration:
    speech_handle: SpeechHandle
    user_message: llm.ChatMessage
    info: _PreemptiveGenerationInfo
    chat_ctx: llm.ChatContext
    tools: list[llm.Tool | llm.Toolset]
    tool_choice: llm.ToolChoice | None
    created_at: float


@dataclass
class _PausedSpeechInfo:
    handle: SpeechHandle
    agent_state: AgentState
    timeout: float


def _end_user_turn_span(info: _EndOfTurnInfo) -> None:
    """End the ``user_turn`` span the activity adopted from recognition (see ``_EndOfTurnInfo``).

    Module-level: tests drive the reply tasks with stand-in activities."""
    if info.user_turn_span_adopted and info.user_turn_span is not None:
        if info.user_turn_span.is_recording():
            info.user_turn_span.end()
        info.user_turn_span_adopted = False


def _record_user_turn_stages(span: trace.Span, user_metrics: llm.MetricsReport) -> None:
    """The stages between the user stopping and the reply starting, next to lk.e2e_latency on
    the reply's agent_turn: a per-turn breakdown readable off one span."""
    attrs: dict[str, float] = {}
    if (v := user_metrics.get("end_of_turn_delay")) is not None:
        attrs[trace_types.ATTR_END_OF_TURN_DELAY] = v
    if (v := user_metrics.get("transcription_delay")) is not None:
        attrs[trace_types.ATTR_TRANSCRIPTION_DELAY] = v
    if (v := user_metrics.get("on_user_turn_completed_delay")) is not None:
        attrs[trace_types.ATTR_ON_USER_TURN_COMPLETED_DELAY] = v
    if attrs:
        span.set_attributes(attrs)


def _record_interruption(speech_handle: SpeechHandle) -> None:
    """Name what interrupted the speech on its agent_turn span.

    Module-level: tests drive the reply tasks with stand-in activities."""
    if not speech_handle.interrupted or speech_handle._agent_turn_context is None:
        return
    span = trace.get_current_span(context=speech_handle._agent_turn_context)
    if not span.is_recording():
        return
    span.set_attribute(
        trace_types.ATTR_INTERRUPTION_SOURCE, speech_handle._interrupt_source or "programmatic"
    )


@contextlib.contextmanager
def _agent_turn(
    speech_handle: SpeechHandle,
    *,
    root_context: otel_context.Context | None,
    agent_label: str,
) -> Iterator[trace.Span]:
    """The speech's ``agent_turn`` span, made current for one generation.

    One speech handle is one agent turn, however many LLM steps it takes: the follow-up
    generation after a tool call runs in a new task but continues the open span instead of
    opening a second turn. Each generation is a ``generation`` event on the span, whose
    ``lk.generation_id`` names the latest one and ``lk.generation_count`` how many there were.
    The span ends with the speech (``SpeechHandle._mark_done``), not with the step.

    Module-level for the same reason as ``_record_queue_wait``."""
    span = speech_handle._agent_turn_span
    if span is None:
        span = tracer.start_span(
            "agent_turn",
            context=root_context,
            attributes={trace_types.ATTR_SPEECH_ID: speech_handle.id},
        )
        # an agent turn is the convention's `invoke_agent`: the framework running the agent
        # in-process, with the inference and tool spans nested underneath
        gen_ai_telemetry.set_agent_attributes(
            span,
            operation=trace_types.GenAIOperationName.INVOKE_AGENT,
            agent_name=agent_label,
        )
        speech_handle._agent_turn_span = span
        speech_handle._agent_turn_context = trace.set_span_in_context(span)
        speech_handle._agent_turn_started_at = time.perf_counter()
        speech_handle._agent_turn_agent_name = agent_label

    generation_attrs: dict[str, Any] = {
        trace_types.ATTR_AGENT_TURN_ID: speech_handle._generation_id
    }
    if parent_id := speech_handle._parent_generation_id:
        generation_attrs[trace_types.ATTR_AGENT_PARENT_TURN_ID] = parent_id
    span.add_event("generation", generation_attrs)
    span.set_attributes(
        {
            trace_types.ATTR_AGENT_TURN_ID: speech_handle._generation_id,
            trace_types.ATTR_GENERATION_COUNT: speech_handle._num_steps,
        }
    )
    with tracer.use_span(span, end_on_exit=False):
        yield span


def _continue_discarded_turn(discarded: SpeechHandle | None, successor: SpeechHandle) -> None:
    """A preemptive generation discarded for ``successor`` (a newer attempt, or the real reply
    after the transcript changed) hands its open ``agent_turn`` over, so one turn shows the
    wasted generation and the one that answered. Module-level like ``_record_queue_wait``."""
    if discarded is None or discarded is successor:
        return
    if (carry := discarded._take_agent_turn()) is not None:
        successor._continue_agent_turn(carry, discarded=discarded)


def _record_queue_wait(speech_handle: SpeechHandle) -> None:
    """Stamp how long the speech sat in the queue on its agent_turn span.

    Module-level: tests drive the reply tasks with stand-in activities."""
    if (
        queue_wait := speech_handle._queue_wait()
    ) is None or speech_handle._agent_turn_context is None:
        return  # no agent_turn span yet: never fall back to whatever span is current
    span = trace.get_current_span(context=speech_handle._agent_turn_context)
    if span.is_recording():
        span.set_attribute(trace_types.ATTR_SPEECH_QUEUE_WAIT, queue_wait)


# NOTE: AgentActivity isn't exposed to the public API
class AgentActivity(RecognitionHooks):
    def __init__(self, agent: Agent, sess: AgentSession) -> None:
        self._agent, self._session = agent, sess
        self._rt_session: llm.RealtimeSession | None = None
        self._realtime_spans: utils.BoundedDict[str, trace.Span] | None = None
        self._realtime_user_input_answered_at: float = 0.0
        self._audio_recognition: AudioRecognition | None = None
        self._lock = asyncio.Lock()
        # Serialize remote-context snapshots with their pushes, including provider acknowledgements.
        self._rt_chat_ctx_lock = asyncio.Lock()
        # one awaited inline AgentTask may pause this activity at a time
        self._inline_task_lock = asyncio.Lock()
        self._tool_choice: llm.ToolChoice | None = None
        # the realtime session holds an ask's tool_choice instead of _tool_choice until restored
        self._rt_tool_choice_overridden = False

        self._started = False
        self._closed = False
        self._scheduling_paused = True
        # set while scheduling runs, and once the activity has closed
        self._scheduling_resumed = asyncio.Event()
        self._new_turns_blocked = False

        self._current_speech: SpeechHandle | None = None
        self._speech_q: list[tuple[int, float, SpeechHandle]] = []
        self._user_silence_event: asyncio.Event = asyncio.Event()
        self._user_silence_event.set()

        # for false interruption handling
        self._paused_speech: _PausedSpeechInfo | None = None
        self._false_interruption_timer: asyncio.TimerHandle | None = None
        # the timeout elapsed while a turn decision was still open; the resume waits on it
        self._false_interruption_pending: bool = False
        self._cancel_speech_pause_task: asyncio.Task[None] | None = None

        self._stt_eos_received: bool = False

        # fired when a speech_task finishes or when a new speech_handle is scheduled
        # this is used to wake up the main task when the scheduling state changes
        self._q_updated = asyncio.Event()

        self._scheduling_atask: asyncio.Task[None] | None = None
        self._user_turn_completed_atask: asyncio.Task[None] | None = None
        self._speech_tasks: list[asyncio.Task[Any]] = []

        self._preemptive_generation: _PreemptiveGeneration | None = None
        self._preemptive_generation_count: int = 0
        # LLM input recorded for the last committed generation (RecordingOptions.input_delta)
        self._input_delta = input_delta.InputDeltaTracker()
        self._authorization_allowed = asyncio.Event()
        self._authorization_allowed.set()

        self._drain_blocked_tasks: set[asyncio.Task[Any]] = set()
        self._mcp_tools: list[mcp.MCPToolset] = []

        # activity-scoped executor: cancels cancellable tools / awaits the rest on drain,
        # and delivers replies to this activity's agent
        if is_given(self._agent._async_tool_options):
            activity_options = _resolve_async_tool_options(self._agent._async_tool_options)
        else:
            activity_options = self._session._async_tool_options
        self._tool_executor = _ToolExecutor(
            owning_activity=self, async_tool_options=activity_options
        )

        self._user_turn_exceeded_atask: asyncio.Task[None] | None = None
        self._user_turn_exceeded_locked: bool = False

        self._on_enter_task: asyncio.Task | None = None
        self._on_exit_task: asyncio.Task | None = None

        # session-scoped truth read by every server-side turn-detection check below
        self._rt_turn_detection_enabled = self._resolve_rt_turn_detection_enabled()
        # the model speaks over the caller, so the caller's turn never gates its own. only while
        # the model owns turn-taking: once the client drives turns, the framework owns the floor
        self._rt_overlapping_speech_enabled = (
            isinstance(self.llm, llm.RealtimeModel)
            and self._rt_turn_detection_enabled
            and self.llm.capabilities.supports_overlapping_speech
        )
        if (
            isinstance(self.llm, llm.RealtimeModel)
            and not self._rt_turn_detection_enabled
            and self.llm.capabilities.turn_detection
        ):
            logger.info(
                "client-side turn-taking is configured, disabling realtime server-side "
                "turn detection."
            )

        if (
            isinstance(self.llm, llm.RealtimeModel)
            and self._session.options.recording_options["audio"]
            and self._session._redaction_enabled
            and not self._session._warned_realtime_audio_redaction
        ):
            logger.warning(
                "RealtimeModel user turns lack complete speech timestamps, so audio redaction "
                "may be inaccurate; disable audio recording to prevent redaction leak."
            )
            self._session._warned_realtime_audio_redaction = True

        # a duplex model has no text modality, and the adapter resolves each reply from the audio
        # the model produces; without audio a text simulation would only time out on turn one
        if self._text_only and isinstance(self.llm, llm.DuplexRealtimeAdapter):
            raise RuntimeError(
                "a DuplexModel speaks only through audio, so it cannot run under a text "
                "simulation; run `lk agent simulate audio` instead"
            )

        if self._rt_turn_detection_enabled and not self.allow_interruptions:
            raise ValueError(
                "the RealtimeModel uses a server-side turn detection, "
                "allow_interruptions cannot be False, disable turn_detection in "
                "the RealtimeModel and use VAD on the AgentSession instead"
            )

        # validate turn detection mode and turn detector
        turn_detection = (
            self._agent.turn_detection
            if is_given(self._agent.turn_detection)
            else self._session.turn_detection
        )
        self._turn_detection = self._validate_turn_detection(turn_detection)

        self._interruption_detector: inference.AdaptiveInterruptionDetector | None = (
            self._resolve_interruption_detection()
        )
        self._interruption_detection_enabled: bool = self._interruption_detector is not None
        self._interruption_detected: bool = False

        # this allows taking over audio interruption temporarily until interruption is detected
        # by default it is true unless turn_detection is manual or realtime_llm
        self._interruption_by_audio_activity_enabled: bool = self._turn_detection not in (
            "manual",
            "realtime_llm",
        )
        self._default_interruption_by_audio_activity_enabled = (
            self._interruption_by_audio_activity_enabled
        )

        # speeches that audio playout finished but not done because of tool calls
        self._background_speeches: set[SpeechHandle] = set()

        # placeholder used to hold a RunResult open while waiting for a realtime
        # model to auto-generate a tool reply (auto_tool_reply_generation=True).
        self._pending_auto_tool_reply_fut: asyncio.Future[None] | None = None

    def _resolve_rt_turn_detection_enabled(self) -> bool:
        """Whether a realtime model's server-side turn detection is on for this session.

        Off when the model can hand turn-taking to the client and the user configured
        client-side turn-taking; otherwise the model's own setting stands.
        """
        if not isinstance(self.llm, llm.RealtimeModel):
            return False

        # a model that without turn_detection
        # or can't hand turn-taking to the client keeps its own setting
        if (
            not (caps := self.llm.capabilities).turn_detection
            or not caps.can_disable_turn_detection
        ):
            return caps.turn_detection

        # resolve client-side turn detection (agent overrides session)
        if is_given(self._agent.turn_detection):
            client_td: TurnDetectionMode | None = self._agent.turn_detection
            client_td_explicit = True
        elif self._session._turn_detection_explicit:
            client_td = self._session.turn_detection
            client_td_explicit = True
        else:
            client_td = None
            client_td_explicit = False

        if client_td_explicit and client_td == "realtime_llm":
            return True  # user wants the model to keep doing turn-taking
        if client_td_explicit and client_td == "manual":
            return False  # client commits turns manually, no VAD needed

        # disable server-side turn detection if the user has a client-side turn detector or interruption detection
        if self.vad is not None and (
            (
                client_td_explicit
                and (isinstance(client_td, _StreamingTurnDetector) or client_td == "vad")
            )
            or is_given(self._agent.interruption_detection)
            or is_given(self._session.interruption_detection)
        ):
            return False
        return True

    def _validate_turn_detection(
        self, turn_detection: TurnDetectionMode | None
    ) -> TurnDetectionMode | None:
        # text simulations commit user turns as text, there is no audio to detect turns in
        if self._text_only and turn_detection not in ("manual", "realtime_llm"):
            return None

        if turn_detection is not None and not isinstance(turn_detection, str):
            if isinstance(turn_detection, _StreamingTurnDetector):
                if self.vad is None:
                    logger.warning(
                        "TurnDetector requires a VAD model. Pass vad=inference.VAD() to AgentSession/Agent"
                        " or turn_detection=None to disable the default TurnDetector"
                    )
                    return None

                if self._rt_turn_detection_enabled:
                    # only warn when the user asked for a TurnDetector, the eager default is
                    # silently superseded by the server-side turn detection
                    if (
                        is_given(self._agent.turn_detection)
                        or self._session._turn_detection_explicit
                    ):
                        logger.warning(
                            "turn_detection is a TurnDetector, but the LLM is a RealtimeModel "
                            "with server-side turn detection enabled, "
                            "ignoring the turn_detection setting"
                        )
                    return None

            return turn_detection

        mode = turn_detection if isinstance(turn_detection, str) else None
        vad_model = self.vad
        stt_model = self.stt
        llm_model = self.llm

        if mode == "vad" and not vad_model:
            logger.warning(
                "turn_detection is set to 'vad', but no VAD model is provided. "
                "Pass a VAD instance, e.g. Agent(vad=silero.VAD.load())"
            )
            mode = None

        if mode == "stt" and not stt_model:
            logger.warning(
                "turn_detection is set to 'stt', but no STT model is provided. "
                "Pass an STT instance, e.g. Agent(stt=deepgram.STT())"
            )
            mode = None

        if isinstance(llm_model, llm.RealtimeModel):
            if mode == "realtime_llm" and not self._rt_turn_detection_enabled:
                logger.warning(
                    "turn_detection is set to 'realtime_llm', but the LLM is not a RealtimeModel "
                    "or the server-side turn detection is not supported/enabled, "
                    "ignoring the turn_detection setting"
                )
                mode = None

            if mode == "stt":
                logger.warning(
                    "turn_detection is set to 'stt', but the LLM is a RealtimeModel, "
                    "ignoring the turn_detection setting"
                )
                mode = None

            elif mode and mode != "realtime_llm" and self._rt_turn_detection_enabled:
                logger.warning(
                    f"turn_detection is set to '{mode}', but the LLM "
                    "is a RealtimeModel and server-side turn detection enabled, "
                    "ignoring the turn_detection setting"
                )
                mode = None

            # fallback to VAD if server side turn detection is disabled and user supplied VAD is available
            if (
                not self._rt_turn_detection_enabled
                and vad_model is not None
                and not self.using_default_vad
                and mode is None
            ):
                mode = "vad"

        elif mode == "realtime_llm":
            logger.warning(
                "turn_detection is set to 'realtime_llm', but the LLM is not a RealtimeModel"
            )
            mode = None

        if (
            not vad_model
            and stt_model
            and not stt_model.capabilities.streaming
            and isinstance(llm_model, llm.LLM)
            and self.allow_interruptions
            and mode is None
        ):
            logger.warning(
                "VAD is not set. Enabling VAD is recommended when using LLM and non-streaming STT "
                "for more responsive interruption handling."
            )

        return mode

    @property
    def scheduling_paused(self) -> bool:
        return self._scheduling_paused

    @property
    def session(self) -> AgentSession:
        return self._session

    @property
    def agent(self) -> Agent:
        return self._agent

    @property
    def interruption_enabled(self) -> bool:
        return self._interruption_detection_enabled

    @property
    def interruption_by_audio_activity_enabled(self) -> bool:
        return self._interruption_by_audio_activity_enabled

    @interruption_by_audio_activity_enabled.setter
    def interruption_by_audio_activity_enabled(self, enabled: bool) -> None:
        if self._audio_recognition:
            self._audio_recognition._cancel_backchannel_boundary()

        self._interruption_by_audio_activity_enabled = (
            enabled and self._default_interruption_by_audio_activity_enabled
        )

    @property
    def mcp_servers(self) -> list[mcp.MCPServer] | None:
        return (
            self._agent.mcp_servers
            if is_given(self._agent.mcp_servers)
            else self._session.mcp_servers
        )

    @property
    def allow_interruptions(self) -> bool:
        return (
            self._agent.allow_interruptions
            if is_given(self._agent.allow_interruptions)
            else self._session.options.interruption["enabled"]
        )

    @property
    def endpointing_opts(self) -> EndpointingOptions:
        overrides: EndpointingOptions = {
            **self.session._opts.endpointing_overrides,
            **(self._agent._turn_handling.get("endpointing") or EndpointingOptions()),  # type: ignore[typeddict-item]
        }
        return _resolve_endpointing(overrides, turn_detection=self._turn_detection)

    @property
    def preemptive_generation_opts(self) -> PreemptiveGenerationOptions:
        # session is always fully resolved; agent-level keys override it
        agent_preemptive = self._agent._turn_handling.get("preemptive_generation", {})
        session_preemptive = self._session.options.preemptive_generation
        return PreemptiveGenerationOptions(**{**session_preemptive, **agent_preemptive})

    @property
    def min_endpointing_delay(self) -> float:
        # this resolves to the fixed value from either agent or session instead of the dynamic one
        return self.endpointing_opts["min_delay"]

    @property
    def max_endpointing_delay(self) -> float:
        # this resolves to the fixed value from either agent or session instead of the dynamic one
        return self.endpointing_opts["max_delay"]

    @property
    def realtime_llm_session(self) -> llm.RealtimeSession | None:
        return self._rt_session

    @property
    def _last_user_speaking_time(self) -> float | None:
        """Last speech time from recognition or the pending committed user turn."""
        if (recognition := self._audio_recognition) is not None:
            if (last_speaking_time := recognition.last_speaking_time) is not None:
                return last_speaking_time
            # New speech must not fall back to the previous committed turn.
            if recognition._speech_start_time is not None:
                return None

        if metrics := self._session._unanswered_user_metrics:
            return metrics.get("stopped_speaking_at")
        return None

    @property
    def current_speech(self) -> SpeechHandle | None:
        return self._current_speech

    @property
    def tools(
        self,
    ) -> list[llm.Tool | llm.Toolset]:
        from .tool_executor import cancel_task, get_running_tasks, has_cancellable_tool

        tools = self._session.tools + self._agent.tools + self._mcp_tools
        # auto-expose cancel_task / get_running_tasks when any tool opts in via
        # ToolFlag.CANCELLABLE. always-on (not per-turn) so the LLM-visible
        # schema stays stable across turns and the prompt cache stays warm
        if has_cancellable_tool(tools):
            tools = [*tools, cancel_task, get_running_tasks]
        return tools

    @property
    def min_consecutive_speech_delay(self) -> float:
        return (
            self._agent.min_consecutive_speech_delay
            if is_given(self._agent.min_consecutive_speech_delay)
            else self._session.options.min_consecutive_speech_delay
        )

    @property
    def use_tts_aligned_transcript(self) -> bool:
        use_aligned_transcript = (
            self._agent.use_tts_aligned_transcript
            if is_given(self._agent.use_tts_aligned_transcript)
            else self._session.options.use_tts_aligned_transcript
        )

        return use_aligned_transcript is True

    async def update_instructions(self, instructions: str) -> None:
        self._agent._instructions = instructions

        # Record the configuration change
        config_update = llm.AgentConfigUpdate(
            instructions=instructions,
        )
        self._agent._chat_ctx.insert(config_update)
        self._session._chat_ctx.insert(config_update)

        if self._rt_session is not None:
            await self._rt_session.update_instructions(instructions)
        else:
            update_instructions(
                self._agent._chat_ctx, instructions=instructions, add_if_missing=True
            )

    async def update_tools(self, tools: list[llm.Tool | llm.Toolset]) -> None:
        # Compute tool diff before updating
        old_tool_names = set(get_fnc_tool_names(self._agent._tools))
        new_tool_names = set(get_fnc_tool_names(tools))
        tools_added = list(new_tool_names - old_tool_names) or None
        tools_removed = list(old_tool_names - new_tool_names) or None

        tools = list({tool.id: tool for tool in tools}.values())
        self._agent._tools = tools

        # Record the configuration change (skip if no visible diff)
        if tools_added or tools_removed:
            config_update = llm.AgentConfigUpdate(
                tools_added=tools_added,
                tools_removed=tools_removed,
            )
            config_update._tools = llm.ToolContext(tools).flatten()
            self._agent._chat_ctx.insert(config_update)
            self._session._chat_ctx.insert(config_update)

        if self._rt_session is not None:
            await self._rt_session.update_tools(llm.ToolContext(self.tools).flatten())

        if isinstance(self.llm, llm.LLM):
            # for realtime LLM, we assume the server will remove unvalid tool messages
            await self.update_chat_ctx(self._agent._chat_ctx.copy(tools=tools))

    async def update_chat_ctx(
        self, chat_ctx: llm.ChatContext, *, exclude_invalid_function_calls: bool = True
    ) -> None:
        chat_ctx = chat_ctx.copy(tools=self.tools if exclude_invalid_function_calls else NOT_GIVEN)
        self._agent._chat_ctx = chat_ctx

        if self._rt_session is not None:
            remove_instructions(chat_ctx)
            async with self._rt_chat_ctx_lock:
                await self._rt_session.update_chat_ctx(chat_ctx)
        else:
            update_instructions(
                chat_ctx, instructions=self._agent.instructions, add_if_missing=True
            )

    def update_options(
        self,
        *,
        tool_choice: NotGivenOr[llm.ToolChoice | None] = NOT_GIVEN,
        endpointing_opts: NotGivenOr[EndpointingOptions] = NOT_GIVEN,
        turn_detection: NotGivenOr[TurnDetectionMode | None] = NOT_GIVEN,
        # deprecated
        min_endpointing_delay: NotGivenOr[float] = NOT_GIVEN,
        max_endpointing_delay: NotGivenOr[float] = NOT_GIVEN,
    ) -> None:
        if is_given(min_endpointing_delay) or is_given(max_endpointing_delay):
            logger.warning(
                "min_endpointing_delay and max_endpointing_delay are deprecated, use endpointing instead"
            )
            endpointing_opts = EndpointingOptions(
                mode=self.endpointing_opts["mode"],
                min_delay=min_endpointing_delay
                if is_given(min_endpointing_delay)
                else self.endpointing_opts["min_delay"],
                max_delay=max_endpointing_delay
                if is_given(max_endpointing_delay)
                else self.endpointing_opts["max_delay"],
                alpha=self.endpointing_opts["alpha"],
            )

        if utils.is_given(tool_choice):
            self._tool_choice = tool_choice

        if self._rt_session is not None:
            self._rt_session.update_options(tool_choice=self._tool_choice)

        if utils.is_given(turn_detection):
            # a realtime model's server-side turn detection is resolved once at session start;
            # runtime re-sync isn't supported yet, so warn when an explicit change would flip it.
            if (
                isinstance(self.llm, llm.RealtimeModel)
                and self.llm.capabilities.can_disable_turn_detection
                and turn_detection is not None
                and self._resolve_rt_turn_detection_enabled() != self._rt_turn_detection_enabled
            ):
                logger.warning(
                    "changing turn_detection at runtime does not update a realtime model's "
                    "server-side turn detection (resolved at session start); it stays %s "
                    "for this session.",
                    "enabled" if self._rt_turn_detection_enabled else "disabled",
                )

            turn_detection = self._validate_turn_detection(turn_detection)

            if self._turn_detection == "manual" or turn_detection == "manual":
                self._cancel_false_interruption_timer()

            self._turn_detection = turn_detection
            self._default_interruption_by_audio_activity_enabled = self._turn_detection not in (
                "manual",
                "realtime_llm",
            )

        if self._audio_recognition:
            self._audio_recognition._update_options(
                endpointing=create_endpointing(endpointing_opts)
                if is_given(endpointing_opts)
                else NOT_GIVEN,
                turn_detection=turn_detection,
            )

    def _update_models(
        self,
        *,
        new_stt: NotGivenOr[stt.STT | None] = NOT_GIVEN,
        new_vad: NotGivenOr[vad.VAD | None] = NOT_GIVEN,
        new_llm: NotGivenOr[llm.LLM | llm.RealtimeModel | None] = NOT_GIVEN,
        new_tts: NotGivenOr[tts.TTS | None] = NOT_GIVEN,
    ) -> None:
        # a RealtimeModel owns a live session; reject before mutating to stay all-or-nothing
        if is_given(new_llm) and (
            isinstance(new_llm, llm.RealtimeModel) or isinstance(self.llm, llm.RealtimeModel)
        ):
            raise RuntimeError(
                "cannot swap to or from a RealtimeModel while the agent is running, "
                "use AgentSession.update_agent() instead"
            )
        # a new vad must satisfy the streaming turn detector's min_silence requirement
        if is_given(new_vad) and self._audio_recognition is not None:
            self._audio_recognition._check_vad_silence_requirement(vad=new_vad)

        if is_given(new_stt):
            old_stt = self.stt
            if isinstance(old_stt, stt.STT):
                old_stt.off("metrics_collected", self._on_metrics_collected)
                old_stt.off("error", self._on_error)
                self._session.off("conversation_item_added", old_stt._push_conversation_item)

            self._agent._stt = new_stt
            resolved_stt = self.stt
            if self._audio_recognition is not None:
                self._audio_recognition._update_stt(
                    self._agent.stt_node if resolved_stt else None,
                    model=resolved_stt.model if isinstance(resolved_stt, stt.STT) else None,
                    provider=resolved_stt.provider if isinstance(resolved_stt, stt.STT) else None,
                    aligned_transcript=bool(resolved_stt.capabilities.aligned_transcript)
                    if isinstance(resolved_stt, stt.STT)
                    else False,
                    reset_context=True,
                )
            self._session._keyterm_detector.swap_stt(resolved_stt)

            if isinstance(resolved_stt, stt.STT):
                resolved_stt.prewarm()
                resolved_stt.on("metrics_collected", self._on_metrics_collected)
                resolved_stt.on("error", self._on_error)
                forward_chat_ctx = self._session._opts.stt_context_options["forward_chat_context"]
                if resolved_stt.capabilities.chat_context and forward_chat_ctx:
                    self._session.on(
                        "conversation_item_added", resolved_stt._push_conversation_item
                    )

        if is_given(new_vad):
            old_vad = self.vad
            if isinstance(old_vad, vad.VAD):
                old_vad.off("metrics_collected", self._on_metrics_collected)

            self._agent._vad = new_vad
            if self._audio_recognition is not None:
                self._audio_recognition._update_vad(self.vad)
            if isinstance(self.vad, vad.VAD):
                self.vad.on("metrics_collected", self._on_metrics_collected)

        if is_given(new_llm):
            old_llm = self.llm
            if isinstance(old_llm, llm.LLM):
                old_llm.off("metrics_collected", self._on_metrics_collected)
                old_llm.off("error", self._on_error)

            self._agent._llm = new_llm  # llm_node reads activity.llm per generation
            if isinstance(self.llm, llm.LLM):
                self.llm.prewarm()
                self.llm.on("metrics_collected", self._on_metrics_collected)
                self.llm.on("error", self._on_error)

        if is_given(new_tts):
            old_tts = self.tts
            if isinstance(old_tts, tts.TTS):
                old_tts.off("metrics_collected", self._on_metrics_collected)
                old_tts.off("error", self._on_error)

            self._agent._tts = new_tts  # tts_node reads activity.tts per synthesis
            if isinstance(self.tts, tts.TTS):
                self.tts.prewarm()
                self.tts.on("metrics_collected", self._on_metrics_collected)
                self.tts.on("error", self._on_error)

    def _create_speech_task(
        self,
        coro: Coroutine[Any, Any, Any],
        *,
        speech_handle: SpeechHandle | None = None,
        name: str | None = None,
    ) -> asyncio.Task[Any]:
        """
        This method must only be used for tasks that "could" create a new SpeechHandle.
        When draining, every task created with this method will be awaited.
        """
        # https://github.com/python/cpython/pull/31837 alternative impl
        tk = _AgentActivityContextVar.set(self)
        tk1 = None
        if speech_handle is not None:
            tk1 = _SpeechHandleContextVar.set(speech_handle)

        # Capture the current OpenTelemetry context to ensure proper span nesting
        current_context = otel_context.get_current()

        # Create a wrapper coroutine that runs in the captured context
        async def _context_aware_coro() -> Any:
            # Attach the captured context before running the original coroutine
            token = otel_context.attach(current_context)
            try:
                return await coro
            finally:
                otel_context.detach(token)

        task = asyncio.create_task(_context_aware_coro(), name=name)
        self._speech_tasks.append(task)
        task.add_done_callback(lambda _: self._speech_tasks.remove(task))

        _set_activity_task_info(task, speech_handle=speech_handle)

        if speech_handle is not None:
            # mark a speech_handle as done, if every "linked" tasks are done
            speech_handle._tasks.append(task)

            def _mark_done_if_needed(_: asyncio.Task) -> None:
                if all(task.done() for task in speech_handle._tasks):
                    speech_handle._mark_done()

            task.add_done_callback(_mark_done_if_needed)

        task.add_done_callback(lambda _: self._wake_up_scheduling_task())
        _AgentActivityContextVar.reset(tk)

        if tk1:
            _SpeechHandleContextVar.reset(tk1)

        return task

    async def start(
        self,
        *,
        reuse_resources: _ReusableResources | None = None,
        trace_context: otel_context.Context | None = None,
    ) -> None:
        # `start` must only be called by AgentSession

        async with self._lock:
            if self._started:
                return

            start_span = tracer.start_span(
                "start_agent_activity",
                context=trace_context,
                attributes={trace_types.ATTR_AGENT_LABEL: self.agent.label},
            )
            gen_ai_telemetry.set_agent_attributes(
                start_span,
                operation=trace_types.GenAIOperationName.CREATE_AGENT,
                agent_name=self.agent.label,
                model=getattr(self.llm, "model", None),
                provider=getattr(self.llm, "provider", None),
            )
            try:
                self._agent._activity = self

                with tracer.use_span(start_span, end_on_exit=False):
                    if isinstance(self.llm, llm.LLM):
                        self.llm.prewarm()

                    if isinstance(self.stt, stt.STT):
                        self.stt.prewarm()

                    if isinstance(self.tts, tts.TTS):
                        self.tts.prewarm()

                # one-shot — not re-run on resume, so toolsets and MCP connections
                # survive pause/resume
                # detached: MCP servers connect here and their tasks live on; a current
                # span would become the parent of whatever those tasks emit later
                with tracer.detached_span(
                    "setup_toolsets", context=trace.set_span_in_context(start_span)
                ):
                    await self._setup_toolsets()

                # don't use start_span for _start_session, avoid nested user/assistant turns
                await self._start_session(reuse_resources=reuse_resources)
                self._started = True

                @tracer.start_as_current_span(
                    "on_enter",
                    context=trace.set_span_in_context(start_span),
                    attributes={trace_types.ATTR_AGENT_LABEL: self._agent.label},
                )
                @utils.log_exceptions(logger=logger)
                async def _traceable_on_enter() -> None:
                    data = _OnEnterData(session=self._session, agent=self._agent)
                    # the turn this agent was entered on; a turn the user commits while on_enter
                    # runs is not its to decline
                    entered_on = self._session._unanswered_user_metrics
                    try:
                        tk = _OnEnterContextVar.set(data)
                        await self._agent.on_enter()
                    finally:
                        _OnEnterContextVar.reset(tk)
                        # an on_enter that returns without speaking has declined the turn;
                        # speeches it created already took their copy
                        if self._session._unanswered_user_metrics is entered_on:
                            self._session._unanswered_user_metrics = None

                self._on_enter_task = task = self._create_speech_task(
                    _traceable_on_enter(), name="AgentTask_on_enter"
                )
                _set_activity_task_info(task, inline_task=True)
            finally:
                start_span.end()

    async def _detach_reusable_resources(self, new_activity: AgentActivity) -> _ReusableResources:
        """Detach reusable resources for handoff to *new_activity*."""
        resources = _ReusableResources()

        try:
            # stt pipeline; only reuse with the default stt_node, a custom override may
            # access the old self.session/activity inside the yield loop after detach
            if (
                self._audio_recognition
                and self.stt is not None
                and type(self.agent).stt_node is Agent.stt_node
                and type(new_activity.agent).stt_node is Agent.stt_node
                and self.stt is new_activity.stt
            ):
                resources.stt_pipeline = await self._audio_recognition._detach_stt()

            # reuse the stream during a handoff whenever we can
            if (
                self._audio_recognition
                and isinstance(self._turn_detection, _StreamingTurnDetector)
                and self._turn_detection is new_activity._turn_detection
            ):
                resources.turn_detector_stream = self._audio_recognition._detach_turn_detector()

            # rt session
            if (
                self._rt_session is not None
                and isinstance(self.llm, llm.RealtimeModel)
                and self.llm is new_activity.llm
            ):
                # context update is supported or chat context is equivalent
                reusable = self.llm.capabilities.mutable_chat_context or (
                    self._rt_session.chat_ctx.copy(
                        exclude_instructions=True, exclude_handoff=True, exclude_config_update=True
                    ).is_equivalent(
                        new_activity.agent.chat_ctx.copy(
                            exclude_instructions=True,
                            exclude_handoff=True,
                            exclude_config_update=True,
                        )
                    )
                )
                # instructions update is supported or instructions are the same
                reusable = reusable and (
                    self.llm.capabilities.mutable_instructions
                    or self.agent.instructions == new_activity.agent.instructions
                )
                # tools update is supported or tools are the same
                reusable = reusable and (
                    self.llm.capabilities.mutable_tools
                    or llm.ToolContext(self.tools) == llm.ToolContext(new_activity.tools)
                )
                # only reuse if the new activity resolves server-side turn detection the same way
                reusable = reusable and (
                    self._rt_turn_detection_enabled == new_activity._rt_turn_detection_enabled
                )

                if reusable:
                    # detach: remove event listeners but don't close the session
                    self._rt_session.off("generation_created", self._on_generation_created)
                    self._rt_session.off("input_speech_started", self._on_input_speech_started)
                    self._rt_session.off("input_speech_stopped", self._on_input_speech_stopped)
                    self._rt_session.off(
                        "input_audio_transcription_completed",
                        self._on_input_audio_transcription_completed,
                    )
                    self._rt_session.off("metrics_collected", self._on_metrics_collected)
                    self._rt_session.off("remote_item_added", self._on_remote_item_added)
                    self._rt_session.off("error", self._on_error)
                    if isinstance(self._rt_session, _FallbackRealtimeSession):
                        self._rt_session._agent_session = None
                    resources.rt_session = self._rt_session
                    self._rt_session = None  # prevent _close_session from closing it

        except Exception:
            # avoid leaking resources
            await resources.cleanup()
            raise

        return resources

    async def _setup_toolsets(self) -> None:
        """Build MCP toolsets, scope each AsyncToolset, and call ``setup()`` on all."""
        from ..llm.async_toolset import AsyncToolset

        assert self._lock.locked(), "_setup_toolsets must run under the activity lock."

        if self.mcp_servers:
            from ..llm.mcp import MCPToolset

            self._mcp_tools = [
                MCPToolset(id=utils.shortuuid("mcp_toolset_"), mcp_server=server)
                for server in self.mcp_servers
            ]

        session_toolsets = [t for t in self._session.tools if isinstance(t, llm.Toolset)]
        agent_toolsets = [t for t in self._agent.tools if isinstance(t, llm.Toolset)]
        mcp_toolsets: list[llm.Toolset] = list(self._mcp_tools)

        all_toolsets = session_toolsets + agent_toolsets + mcp_toolsets
        if not all_toolsets:
            return

        # session.tools → session-scoped (survives handoff); agent.tools → activity-scoped
        for ts in llm.ToolContext(session_toolsets).toolsets:
            if isinstance(ts, AsyncToolset):
                ts._attach_activity(activity=None, session=self._session)
        for ts in llm.ToolContext(agent_toolsets).toolsets:
            if isinstance(ts, AsyncToolset):
                ts._attach_activity(activity=self, session=self._session)

        @utils.log_exceptions(logger=logger)
        async def _do_setup(toolset: llm.Toolset) -> None:
            await toolset.setup()

        await asyncio.gather(
            *(_do_setup(ts) for ts in all_toolsets),
            return_exceptions=True,
        )

    async def _start_session(self, *, reuse_resources: _ReusableResources | None = None) -> None:
        assert self._lock.locked(), "_start_session should only be used when locked."

        # session-long tasks must not inherit the on_enter marker of whoever started this activity
        tk = _OnEnterContextVar.set(None)
        try:
            await self._start_session_impl(reuse_resources=reuse_resources)
        finally:
            _OnEnterContextVar.reset(tk)

    async def _start_session_impl(
        self, *, reuse_resources: _ReusableResources | None = None
    ) -> None:
        """Hook up the models and start the scheduling and audio-recognition tasks."""
        if isinstance(self.llm, llm.LLM):
            self.llm.on("metrics_collected", self._on_metrics_collected)
            self.llm.on("error", self._on_error)

        if isinstance(self.stt, stt.STT):
            self.stt.on("metrics_collected", self._on_metrics_collected)
            self.stt.on("error", self._on_error)

        if isinstance(self.tts, tts.TTS):
            self.tts.on("metrics_collected", self._on_metrics_collected)
            self.tts.on("error", self._on_error)

        if isinstance(self.vad, vad.VAD):
            self.vad.on("metrics_collected", self._on_metrics_collected)

        if isinstance(self._interruption_detector, inference.AdaptiveInterruptionDetector):
            self._interruption_detector.on("metrics_collected", self._on_metrics_collected)
            self._interruption_detector.on("error", self._on_error)

        if isinstance(self._turn_detection, inference.TurnDetector):
            self._turn_detection.on("metrics_collected", self._on_metrics_collected)

        # keyterm detection runs its own LLM, surface its usage
        self._session._keyterm_detector.on("metrics_collected", self._on_metrics_collected)

        if isinstance(self.llm, llm.RealtimeModel):
            rt_reused = reuse_resources is not None and reuse_resources.rt_session is not None
            if rt_reused:
                assert reuse_resources and reuse_resources.rt_session is not None
                logger.debug("reusing realtime session from previous activity")
                self._rt_session = reuse_resources.rt_session
                reuse_resources.rt_session = None  # ownership transferred

                # clear any stale audio/generation state
                self._rt_session.interrupt()
                self._rt_session.clear_audio()
            else:
                # disable only when we resolved it off AND the model can (guards a model whose
                # turn detection is explicitly pinned off from a spurious disable)
                turn_detection_disabled = (
                    not self._rt_turn_detection_enabled
                    and self.llm.capabilities.can_disable_turn_detection
                )
                self._rt_session = self.llm.session(turn_detection_disabled=turn_detection_disabled)
                logger.debug("created new realtime session for activity, id=%s", self._rt_session)

            self._rt_session.on("generation_created", self._on_generation_created)
            self._rt_session.on("input_speech_started", self._on_input_speech_started)
            self._rt_session.on("input_speech_stopped", self._on_input_speech_stopped)
            self._rt_session.on(
                "input_audio_transcription_completed",
                self._on_input_audio_transcription_completed,
            )
            self._rt_session.on("metrics_collected", self._on_metrics_collected)
            self._rt_session.on("remote_item_added", self._on_remote_item_added)
            self._rt_session.on("error", self._on_error)

            # the fallback adapter's session needs the AgentSession to drive interrupt/generate_reply on swap
            if isinstance(self._rt_session, _FallbackRealtimeSession):
                self._rt_session._agent_session = self._session

            remove_instructions(self._agent._chat_ctx)

            capabilities = self.llm.capabilities
            reset_instructions = reset_chat_ctx = reset_tools = True
            if rt_reused:
                # skip the update if the session is reused and no mid-session update is supported
                # this means the content is the same as the previous session
                reset_instructions = capabilities.mutable_instructions
                reset_chat_ctx = capabilities.mutable_chat_context
                reset_tools = capabilities.mutable_tools

            await self._rt_session._update_session(
                instructions=self._render_realtime_instructions(self._agent.instructions)
                if reset_instructions
                else NOT_GIVEN,
                chat_ctx=self._agent.chat_ctx if reset_chat_ctx else NOT_GIVEN,
                tools=llm.ToolContext(self.tools).flatten() if reset_tools else NOT_GIVEN,
            )

            self._realtime_spans = utils.BoundedDict[str, trace.Span](maxsize=100)
            if not capabilities.audio_output and not self.tts and self._session.output.audio:
                logger.error(
                    "audio output is enabled but RealtimeModel has no audio modality "
                    "and no TTS is set. Either enable audio modality in the RealtimeModel "
                    "or set a TTS model."
                )

        elif isinstance(self.llm, llm.LLM):
            try:
                update_instructions(
                    self._agent._chat_ctx,
                    instructions=self._agent.instructions,
                    add_if_missing=True,
                )
            except ValueError:
                logger.exception("failed to update the instructions")

        # Record initial agent configuration (skip if empty)
        initial_tools = get_fnc_tool_names(self.tools) or None
        instr = self._agent.instructions
        # collapse modality variants for the record; audio-first matches the
        # update_instructions default for voice sessions
        initial_instructions = (
            instr.render(modality="audio") if isinstance(instr, Instructions) else instr
        )
        if initial_instructions or initial_tools:
            initial_config = llm.AgentConfigUpdate(
                instructions=initial_instructions,
                tools_added=initial_tools,
            )
            initial_config._tools = llm.ToolContext(self.tools).flatten()
            self._agent._chat_ctx.insert(initial_config)
            self._session._chat_ctx.insert(initial_config)

        await self._resume_scheduling_task()
        # skip default vad when llm does not need it
        wired_vad = self.vad
        if wired_vad is not None and self.using_default_vad and self._rt_turn_detection_enabled:
            wired_vad = None
        self._audio_recognition = AudioRecognition(
            self._session,
            hooks=self,
            stt=self._agent.stt_node if self.stt else None,
            vad=wired_vad,
            interruption_detection=self._interruption_detector,
            endpointing=create_endpointing(self.endpointing_opts),
            turn_detection=self._turn_detection,
            stt_model=self.stt.model if self.stt else None,
            stt_provider=self.stt.provider if self.stt else None,
            stt_aligned_transcript=bool(self.stt.capabilities.aligned_transcript)
            if self.stt
            else False,
        )
        stt_pipeline = reuse_resources.stt_pipeline if reuse_resources else None
        turn_detector_stream = reuse_resources.turn_detector_stream if reuse_resources else None
        if stt_pipeline is not None:
            logger.debug("reusing STT pipeline from previous activity")
        if turn_detector_stream is not None:
            logger.debug("reusing turn detector stream from previous activity")
        self._audio_recognition._start(
            stt_pipeline=stt_pipeline,
            turn_detector_stream=turn_detector_stream,
        )
        if reuse_resources:
            # ownership transferred to the new AudioRecognition
            reuse_resources.stt_pipeline = None
            reuse_resources.turn_detector_stream = None

        if isinstance(self.stt, stt.STT):
            # bind the session's keyterm detector to this activity's STT (detection uses its
            # own LLM, configured via stt_context_options, not the agent's)
            self._session._keyterm_detector.start(self._session, stt=self.stt)

            # forward conversation turns to STTs that consume context natively; gated by the STT's
            # capability and the session's forward_chat_context toggle. stateless, activity-scoped.
            forward_chat_ctx = self._session._opts.stt_context_options["forward_chat_context"]
            if self.stt.capabilities.chat_context and forward_chat_ctx:
                self._session.on("conversation_item_added", self.stt._push_conversation_item)

    @tracer.start_as_current_span("drain_agent_activity")
    async def drain(
        self, *, new_activity: AgentActivity | None = None
    ) -> _ReusableResources | None:
        # `drain` must only be called by AgentSession
        # AgentSession makes sure there is always one agent available to the users.
        current_span = trace.get_current_span()
        current_span.set_attribute(trace_types.ATTR_AGENT_LABEL, self._agent.label)

        @tracer.start_as_current_span(
            "on_exit", attributes={trace_types.ATTR_AGENT_LABEL: self._agent.label}
        )
        @utils.log_exceptions(logger=logger)
        async def _traceable_on_exit() -> None:
            await self._agent.on_exit()

        async with self._lock:
            if self._on_exit_task is None:
                self._on_exit_task = task = self._create_speech_task(
                    _traceable_on_exit(), name="AgentTask_on_exit"
                )
                _set_activity_task_info(task, inline_task=True)

            self._cancel_preemptive_generation()

            try:
                await self._on_exit_task
            except Exception:
                pass  # already logged by @log_exceptions

            await self._pause_scheduling_task()

            # detach after speech tasks are done but before _close_session
            if new_activity is not None:
                try:
                    return await self._detach_reusable_resources(new_activity)
                except BaseException:
                    logger.exception("failed to detach reusable resources")

            return None

    async def _pause_scheduling_task(
        self, *, blocked_tasks: list[asyncio.Task] | None = None
    ) -> None:
        assert self._lock.locked(), "_finalize_main_task should only be used when locked."

        if self._scheduling_paused:
            return

        await self._session._keyterm_detector.aclose()

        self._scheduling_paused = True
        self._scheduling_resumed.clear()
        # a parked preemptive generation is never scheduled, so the wait below would never
        # end. drop it here rather than in the callers: the flag above is what stops a new
        # one from being created, and it is only true from this point on.
        self._cancel_preemptive_generation()
        if blocked_tasks:
            self._add_drain_blocked_tasks(blocked_tasks)
        self._wake_up_scheduling_task()

        if self._scheduling_atask is not None:
            # When pausing/draining, we ensure that all speech_tasks complete fully.
            # This means that even if the SpeechHandle themselves have finished,
            # we still wait for the entire execution (e.g function_tools)
            await asyncio.shield(self._scheduling_atask)

    @contextlib.asynccontextmanager
    async def _inline_task_slot(
        self,
        *,
        speech_handle: SpeechHandle | None,
        blocked_tasks: list[asyncio.Task[Any]],
    ) -> AsyncGenerator[None, None]:
        """Grants the floor to one awaited inline AgentTask at a time.

        Pausing an activity is a single slot: concurrent handoffs would leave every switch
        but the last overwritten, and those tasks awaiting a result nothing can produce. The
        inline tasks of a turn's parallel tool calls queue here and take the slot in turn.

        The queue is per activity, which is the thing a handoff contends for. A nested task
        pauses the activity of the task it is nested in, so it takes that activity's slot
        and never waits on the one its parent is holding.

        Each step below is ordered against the queue, and inverting any of them hangs the
        session in its own way, so they belong together rather than at the call site.
        """
        # before the queue: the tasks behind it share this speech, and a hold released
        # between them lets one task's user turns interrupt it out from under the rest
        if speech_handle is not None:
            if speech_handle.interrupted:
                raise RuntimeError("the speech that awaited the inline task is interrupted")

            speech_handle._hold_interruptions()

        try:
            # before the queue: a queued task absent from the drain set makes session close
            # wait on the slot it is still queued for
            self._add_drain_blocked_tasks(blocked_tasks)

            async with self._inline_task_lock:
                if self._closed or self._session._closing:
                    # reported to the model as a tool failure, the way a tool awaiting an
                    # inline task through a session close has always been
                    raise ToolError("the activity that awaited the inline task is closing")

                if self._new_turns_blocked:
                    raise ToolError(
                        "An agent transition is in progress, so this tool call cannot continue. "
                        "Wait until the transition is complete before retrying, if the tool is "
                        "available to the new agent."
                    )

                # past the queue: a run watching a task still waiting its turn waits for
                # the user input the task ahead of it needs
                if (run_state := self._session._global_run_state) and not run_state.done():
                    for task in blocked_tasks:
                        run_state._watch_handle(task)

                yield
        finally:
            if speech_handle is not None:
                speech_handle._release_interruptions()

    def _add_drain_blocked_tasks(self, tasks: list[asyncio.Task[Any]]) -> None:
        # tasks blocked on an agent handoff are excluded from the drain wait,
        # otherwise drain would wait for them while the handoff waits for drain's lock
        self._drain_blocked_tasks.update(tasks)
        self._wake_up_scheduling_task()

    async def _resume_scheduling_task(self) -> None:
        assert self._lock.locked(), "_finalize_main_task should only be used when locked."

        if not self._scheduling_paused:
            return

        self._scheduling_paused = False
        self._new_turns_blocked = False
        self._drain_blocked_tasks.clear()
        self._scheduling_atask = asyncio.create_task(
            self._scheduling_task(), name="_scheduling_task"
        )
        self._scheduling_resumed.set()

    async def resume(
        self,
        *,
        reuse_resources: _ReusableResources | None = None,
        trace_context: otel_context.Context | None = None,
    ) -> None:
        # `resume` must only be called by AgentSession

        async with self._lock:
            # not made current: _start_session spawns the tasks that live for the session
            span = tracer.start_span(
                "resume_agent_activity",
                context=trace_context,
                attributes={trace_types.ATTR_AGENT_LABEL: self.agent.label},
            )
            try:
                await self._start_session(reuse_resources=reuse_resources)
            finally:
                span.end()

    def _wake_up_scheduling_task(self) -> None:
        self._q_updated.set()

    async def pause(
        self,
        *,
        blocked_tasks: list[asyncio.Task],
        new_activity: AgentActivity | None = None,
    ) -> _ReusableResources | None:
        # `pause` must only be called by AgentSession

        # When draining, the tasks that have done the "premption" must be ignored.
        # They will most likely block until the Agent transition is done. So we must not
        # wait for them to avoid deadlocks.

        # When resuming, the AgentSession.update_agent must use the same AgentActivity instance!
        async with self._lock:
            if self._closed:
                # already closed by the session close
                return None

            span = tracer.start_span(
                "pause_agent_activity",
                attributes={trace_types.ATTR_AGENT_LABEL: self._agent.label},
            )

            resources: _ReusableResources | None = None
            try:
                await self._pause_scheduling_task(blocked_tasks=blocked_tasks)

                # detach after speech tasks are done but before _close_session
                if new_activity is not None:
                    resources = await self._detach_reusable_resources(new_activity)

                await self._close_session()
            except BaseException:
                if resources is not None:
                    await resources.cleanup()
                raise
            finally:
                span.end()

            return resources

    async def _close_session(self) -> None:
        assert self._lock.locked(), "_close_session should only be used when locked."

        if isinstance(self.llm, llm.LLM):
            self.llm.off("metrics_collected", self._on_metrics_collected)
            self.llm.off("error", self._on_error)

        if isinstance(self.llm, llm.RealtimeModel) and self._rt_session is not None:
            self._rt_session.off("generation_created", self._on_generation_created)
            self._rt_session.off("input_speech_started", self._on_input_speech_started)
            self._rt_session.off("input_speech_stopped", self._on_input_speech_stopped)
            self._rt_session.off(
                "input_audio_transcription_completed",
                self._on_input_audio_transcription_completed,
            )
            self._rt_session.off("remote_item_added", self._on_remote_item_added)
            self._rt_session.off("error", self._on_error)
            if isinstance(self._rt_session, _FallbackRealtimeSession):
                self._rt_session._agent_session = None

        if isinstance(self.stt, stt.STT):
            self.stt.off("metrics_collected", self._on_metrics_collected)
            self.stt.off("error", self._on_error)
            self._session.off("conversation_item_added", self.stt._push_conversation_item)

        if isinstance(self.tts, tts.TTS):
            self.tts.off("metrics_collected", self._on_metrics_collected)
            self.tts.off("error", self._on_error)

        if isinstance(self.vad, vad.VAD):
            self.vad.off("metrics_collected", self._on_metrics_collected)

        if isinstance(self._interruption_detector, inference.AdaptiveInterruptionDetector):
            self._interruption_detector.off("metrics_collected", self._on_metrics_collected)
            self._interruption_detector.off("error", self._on_error)

        if isinstance(self._turn_detection, inference.TurnDetector):
            self._turn_detection.off("metrics_collected", self._on_metrics_collected)

        self._session._keyterm_detector.off("metrics_collected", self._on_metrics_collected)

        if self._rt_session is not None:
            await self._rt_session.aclose()
            # after aclose, so a model that reports its final usage while closing is still counted
            self._rt_session.off("metrics_collected", self._on_metrics_collected)

        if self._realtime_spans is not None:
            self._realtime_spans.clear()

        if self._audio_recognition is not None:
            await self._audio_recognition._aclose()

        await self._cancel_speech_pause(
            old_task=self._cancel_speech_pause_task,
            interrupt=False,  # don't interrupt the paused speech, it's managed by _pause_scheduling_task
        )
        self._cancel_speech_pause_task = None

    async def aclose(self) -> None:
        # `aclose` must only be called by AgentSession

        async with self._lock:
            if self._closed:
                return

            self._closed = True
            self._scheduling_resumed.set()
            self._cancel_preemptive_generation()
            await self._session._keyterm_detector.aclose()

            # on_exit_task should be awaited in `drain`
            self._on_exit_task = None

            # cancel cancellable tools and await the rest before teardown
            await self._tool_executor.drain()

            await self._close_session()
            await asyncio.gather(*self._interrupt_background_speeches(force=False))

            if self._scheduling_atask is not None:
                await utils.aio.cancel_and_wait(self._scheduling_atask)

            # session-scoped toolsets are closed by the session; this only closes
            # the agent's own toolsets + MCP — all of which outlive pause
            toolsets = self._mcp_tools + [
                tool for tool in self._agent.tools if isinstance(tool, llm.Toolset)
            ]
            if toolsets:
                await asyncio.gather(
                    *(toolset.aclose() for toolset in toolsets), return_exceptions=True
                )

            # final sweep: anything non-cancellable that survived drain dies here
            await self._tool_executor.aclose()

            self._agent._activity = None

    def push_audio(self, frame: rtc.AudioFrame) -> None:
        if not self._started:
            return

        aec_warmup_active: bool = (
            self._session.agent_state == "speaking"
            and self._session._aec_warmup_remaining > 0
            and self._session._aec_warmup_timer is not None
        )

        uninterruptible_speech_active: bool = (
            self._current_speech is not None
            and not self._current_speech.done()
            and not self._current_speech.interrupted
            and not self._current_speech.allow_interruptions
            and self._session.options.interruption["discard_audio_if_uninterruptible"]
        )

        should_discard: bool = aec_warmup_active or uninterruptible_speech_active

        # When discarding, substitute silence on the paths that would otherwise
        # see contaminated/echoed audio (STT, realtime model) so the downstream
        # stream stays continuous. VAD, AMD and the interruption detector keep
        # receiving the real frame so they can still react to the user.
        stt_frame: rtc.AudioFrame | None = None
        if should_discard:
            stt_frame = utils.audio.silence_frame_like(frame)

        if self._rt_session is not None:
            self._rt_session.push_audio(stt_frame if stt_frame is not None else frame)

        if self._audio_recognition is not None:
            self._audio_recognition._push_audio(frame, stt_frame=stt_frame)

    def push_video(self, frame: rtc.VideoFrame) -> None:
        if not self._started:
            return

        if self._rt_session is not None:
            self._rt_session.push_video(frame)

    def say(
        self,
        text: str | AsyncIterable[str],
        *,
        audio: NotGivenOr[AsyncIterable[rtc.AudioFrame]] = NOT_GIVEN,
        allow_interruptions: NotGivenOr[bool] = NOT_GIVEN,
        add_to_chat_ctx: bool = True,
    ) -> SpeechHandle:
        if (
            not is_given(audio)
            and not self.tts
            and not (isinstance(self.llm, llm.RealtimeModel) and self.llm.capabilities.supports_say)
            and self._session.output.audio
            and self._session.output.audio_enabled
        ):
            raise RuntimeError(
                "trying to generate speech from text without a TTS model or a RealtimeSession that supports say(); "
                "add a TTS model to AgentSession to enable say()"
            )

        if self._rt_turn_detection_enabled and allow_interruptions is False:
            logger.warning(
                "the RealtimeModel uses a server-side turn detection, allow_interruptions cannot be False when using VoiceAgent.say(), "  # noqa: E501
                "disable turn_detection in the RealtimeModel and use VAD on the AgentTask/VoiceAgent instead"  # noqa: E501
            )
            allow_interruptions = NOT_GIVEN

        handle = SpeechHandle.create(
            allow_interruptions=allow_interruptions
            if is_given(allow_interruptions)
            else self.allow_interruptions
        )
        self._session.emit(
            "speech_created",
            SpeechCreatedEvent(speech_handle=handle, user_initiated=True, source="say"),
        )
        user_metrics = self._take_on_enter_user_metrics()

        if (
            self._rt_session is not None
            and not is_given(audio)
            and not self.tts
            and isinstance(self.llm, llm.RealtimeModel)
            and self.llm.capabilities.supports_say
        ):
            if not add_to_chat_ctx:
                logger.warning(
                    "add_to_chat_ctx=False is not supported when say() uses a RealtimeModel; "
                    "the message will still be added to the chat context"
                )
            self._create_speech_task(
                self._realtime_reply_task(
                    speech_handle=handle,
                    text=text,
                    model_settings=ModelSettings(),
                ),
                speech_handle=handle,
                name="AgentActivity.realtime_say",
            )
        else:
            task = self._create_speech_task(
                self._tts_task(
                    speech_handle=handle,
                    text=text,
                    audio=audio or None,
                    add_to_chat_ctx=add_to_chat_ctx,
                    model_settings=ModelSettings(),
                    _previous_user_metrics=user_metrics,
                ),
                speech_handle=handle,
                name="AgentActivity.tts_say",
            )
            task.add_done_callback(self._on_pipeline_reply_done)
        self._schedule_speech(handle, SpeechHandle.SPEECH_PRIORITY_NORMAL)
        return handle

    def _generate_reply(
        self,
        *,
        user_message: NotGivenOr[llm.ChatMessage | None] = NOT_GIVEN,
        chat_ctx: NotGivenOr[llm.ChatContext | None] = NOT_GIVEN,
        instructions: NotGivenOr[str | Instructions] = NOT_GIVEN,
        tool_choice: NotGivenOr[llm.ToolChoice] = NOT_GIVEN,
        tools: NotGivenOr[list[str]] = NOT_GIVEN,
        allow_interruptions: NotGivenOr[bool] = NOT_GIVEN,
        schedule_speech: bool = True,
        input_details: InputDetails = DEFAULT_INPUT_DETAILS,
    ) -> SpeechHandle:
        if self._rt_turn_detection_enabled and allow_interruptions is False:
            logger.warning(
                "the RealtimeModel uses a server-side turn detection, allow_interruptions cannot be False when using VoiceAgent.generate_reply(), "  # noqa: E501
                "disable turn_detection in the RealtimeModel and use VAD on the AgentTask/VoiceAgent instead"  # noqa: E501
            )
            allow_interruptions = NOT_GIVEN

        if self.llm is None:
            raise RuntimeError("trying to generate reply without an LLM model")

        task = asyncio.current_task()
        if not is_given(tool_choice) and task is not None:
            if task_info := _get_activity_task_info(task):
                if task_info.function_call is not None:
                    # when generate_reply is called inside a function_tool, set tool_choice to None by default  # noqa: E501
                    tool_choice = "none"

        all_tools = self.tools.copy()

        # resolve tool names to Tool objects if tools param is given
        resolved_tools: NotGivenOr[list[llm.Tool | llm.Toolset]] = NOT_GIVEN
        if is_given(tools):
            tool_ctx = llm.ToolContext(all_tools)
            toolset_dict = {t.id: t for t in tool_ctx.toolsets}
            tool_dict = {t.id: t for t in tool_ctx.flatten()}
            resolved_tools = list[llm.Tool | llm.Toolset]()
            for name in set(tools):
                tool = toolset_dict.get(name) or tool_dict.get(name)
                if tool is None:
                    raise ValueError(
                        f"tool '{name}' not found in agent's registered tools. "
                        f"Available tools: {list(tool_ctx.function_tools.keys())}"
                    )
                resolved_tools.append(tool)

        handle = SpeechHandle.create(
            allow_interruptions=allow_interruptions
            if is_given(allow_interruptions)
            else self.allow_interruptions,
            input_details=input_details,
        )
        self._session.emit(
            "speech_created",
            SpeechCreatedEvent(speech_handle=handle, user_initiated=True, source="generate_reply"),
        )
        user_metrics = self._take_on_enter_user_metrics()

        if isinstance(self.llm, llm.RealtimeModel):
            self._create_speech_task(
                self._realtime_reply_task(
                    speech_handle=handle,
                    # TODO(theomonnom): support llm.ChatMessage for the realtime model
                    user_input=user_message.raw_text_content if user_message else None,
                    instructions=self._render_realtime_instructions(instructions)
                    if instructions
                    else None,
                    tools=resolved_tools if is_given(resolved_tools) else None,
                    model_settings=ModelSettings(tool_choice=tool_choice),
                ),
                speech_handle=handle,
                name="AgentActivity.realtime_reply",
            )

        elif isinstance(self.llm, llm.LLM):
            task = self._create_speech_task(
                self._pipeline_reply_task(
                    speech_handle=handle,
                    chat_ctx=chat_ctx or self._agent._chat_ctx,
                    tools=resolved_tools if is_given(resolved_tools) else all_tools,
                    new_message=user_message if is_given(user_message) else None,
                    instructions=instructions or None,
                    model_settings=ModelSettings(
                        tool_choice=tool_choice
                        if utils.is_given(tool_choice) or self._tool_choice is None
                        else self._tool_choice
                    ),
                    _previous_user_metrics=user_metrics,
                ),
                speech_handle=handle,
                name="AgentActivity.pipeline_reply",
            )
            task.add_done_callback(self._on_pipeline_reply_done)

        if schedule_speech:
            self._schedule_speech(handle, SpeechHandle.SPEECH_PRIORITY_NORMAL)

        return handle

    def _cancel_preemptive_generation(self) -> None:
        if self._preemptive_generation is not None:
            self._preemptive_generation.speech_handle._cancel()
            self._preemptive_generation = None

    def _pause_authorization(self) -> None:
        self._authorization_allowed.clear()

    def _resume_authorization(self) -> None:
        self._authorization_allowed.set()

    def _interrupt_background_speeches(
        self, force: bool = False, source: InterruptionSource = "programmatic"
    ) -> list[SpeechHandle]:
        interrupted_speeches: list[SpeechHandle] = []
        for speech in self._background_speeches:
            if force or speech.allow_interruptions:
                interrupted_speeches.append(speech.interrupt(force=force, source=source))

        return interrupted_speeches

    def interrupt(
        self, *, force: bool = False, source: InterruptionSource = "programmatic"
    ) -> asyncio.Future[None]:
        """Interrupt the current speech generation and any queued speeches.

        A queued speech that disallows interruptions keeps playing, along with the ones
        behind it, unless ``force`` is set. ``source`` names the cause on the speeches'
        ``agent_turn`` spans.

        Returns:
            An asyncio.Future that completes when the interruption is fully processed
            and chat context has been updated

        Raises:
            RuntimeError: If the speech currently playing disallows interruptions and
                ``force`` is False.
        """
        self._cancel_preemptive_generation()

        future = asyncio.Future[None]()

        interrupted_speeches = self._interrupt_background_speeches(force=force, source=source)

        if self._current_speech is not None:
            self._current_speech.interrupt(force=force, source=source)
            interrupted_speeches.append(self._current_speech)

        if self._rt_session is not None:
            self._rt_session.interrupt()

        # _speech_q is a heap, so its list order is not the order it pops in
        for _, _, speech in sorted(self._speech_q, key=lambda item: (item[0], item[1])):
            try:
                speech.interrupt(force=force, source=source)
            except RuntimeError:
                # the speeches behind this one are going to play, so stopping
                # here keeps the conversation contiguous
                logger.warning(
                    "a queued speech does not allow interruptions and will play after the "
                    "interruption, use interrupt(force=True) to interrupt it as well",
                    extra={"speech_id": speech.id},
                )
                break

            interrupted_speeches.append(speech)

        if not interrupted_speeches:
            future.set_result(None)
        else:

            def on_playout_done(_: SpeechHandle) -> None:
                if not future.done() and all(speech.done() for speech in interrupted_speeches):
                    future.set_result(None)

            for speech in interrupted_speeches:
                speech.add_done_callback(on_playout_done)

        return future

    def clear_user_turn(self) -> None:
        if self._audio_recognition:
            self._audio_recognition._clear_user_turn()

        if self._rt_session is not None:
            self._rt_session.clear_audio()
            self._realtime_user_input_answered_at = time.time()
            self._session._unanswered_user_metrics = None

    def commit_user_turn(
        self, *, transcript_timeout: float, stt_flush_duration: float, skip_reply: bool = False
    ) -> asyncio.Future[str]:
        if self._rt_session is not None:
            # commit audio buffer and conditionally trigger response generation
            self._rt_session.commit_audio()
            if skip_reply:
                self._realtime_user_input_answered_at = time.time()
                self._session._unanswered_user_metrics = None
            else:
                self._session.generate_reply(input_modality="audio")
            # `skip_reply` prevents duplicate reply from _on_user_turn_completed
            # but keeps flushing STT transcript into the chat context
            skip_reply = True

        assert self._audio_recognition is not None
        return self._audio_recognition._commit_user_turn(
            audio_detached=not self._session.input.audio_enabled,
            transcript_timeout=transcript_timeout,
            stt_flush_duration=stt_flush_duration,
            skip_reply=skip_reply,
        )

    def _schedule_speech(self, speech: SpeechHandle, priority: int, force: bool = False) -> None:
        # when force=True, we still allow to schedule a new speech even if
        # `pause_speech_scheduling` is waiting for the schedule_task to drain.
        # This allows for tool responses to be generated before the AgentActivity is finalized.

        if self._scheduling_paused and not force:
            speech.interrupt(force=True)
            raise RuntimeError(
                "cannot schedule new speech, the speech scheduling is draining/pausing, the speech will be cancelled"
            )

        if self._scheduling_atask and self._scheduling_atask.done():
            logger.warning(
                "attempting to schedule a new SpeechHandle, but the scheduling_task is not running, the speech will be cancelled"
            )
            speech.interrupt(force=True)
            return

        while True:
            try:
                # negate the priority to make it a max heap
                heapq.heappush(self._speech_q, (-priority, time.perf_counter_ns(), speech))
                break
            except TypeError:
                # handle TypeError when identical timestamps cause speech comparison failure
                # with perf_counter_ns(), collisions should be rare
                pass

        speech._mark_scheduled()
        self._wake_up_scheduling_task()

    @utils.log_exceptions(logger=logger)
    async def _scheduling_task(self) -> None:
        last_playout_ts = 0.0
        while True:
            await self._q_updated.wait()
            self._q_updated.clear()

            while self._speech_q:
                _, _, speech = heapq.heappop(self._speech_q)
                if speech.done():
                    # skip done speech (interrupted when it's in the queue)
                    self._current_speech = None
                    continue
                self._current_speech = speech
                if self.min_consecutive_speech_delay > 0.0:
                    delay = self.min_consecutive_speech_delay - (time.time() - last_playout_ts)
                    if delay > 0:
                        await asyncio.sleep(delay)
                    # check again if speech is done after sleep delay
                    if speech.done():
                        # skip done speech (interrupted during delay)
                        self._current_speech = None
                        continue
                speech._authorize_generation()
                await speech._wait_for_generation()

                if self._paused_speech and self._paused_speech.handle is self._current_speech:
                    # clear paused speech after generation done
                    self._paused_speech = None
                    self._cancel_false_interruption_timer()
                    if (audio_output := self._session.output.audio) and audio_output.can_pause:
                        audio_output.resume()
                self._current_speech = None
                last_playout_ts = time.time()

            # if we're draining/pasuing and there are no more speech tasks, we can exit.
            # only speech tasks can bypass draining to create a tool response (see `_schedule_speech`)  # noqa: E501

            blocked_handles: list[SpeechHandle] = []
            for task in self._drain_blocked_tasks:
                info = _get_activity_task_info(task)
                if not info:
                    logger.error("blocked task without activity info; skipping.")
                    continue

                if not info.speech_handle:
                    continue  # on_enter/on_exit

                blocked_handles.append(info.speech_handle)

            to_wait: list[asyncio.Task] = []
            for task in self._speech_tasks:
                if task in self._drain_blocked_tasks:
                    continue

                info = _get_activity_task_info(task)
                if info and info.speech_handle in blocked_handles:
                    continue

                to_wait.append(task)

            if self._scheduling_paused and len(to_wait) == 0:
                break

    async def wait_for_idle(
        self, *, wait_for_agent: bool = True, wait_for_user: bool = True
    ) -> None:
        """Wait until this activity has no in-flight agent or user work.

        Raises ``ActivityClosedError`` if the activity has terminally closed.
        """
        agent_active = True
        user_active = True

        async def _wait_for_eou() -> None:
            # eou is part of the user turn and may spawn a new speech handle,
            # so an in-flight eou keeps both the user and the agent active.
            nonlocal user_active
            if (
                self._audio_recognition
                and (eou_task := self._audio_recognition._end_of_turn_task)
                and not eou_task.done()
            ):
                user_active = True
                await asyncio.shield(eou_task)

            if (user_turn_task := self._user_turn_completed_atask) and not user_turn_task.done():
                user_active = True
                await asyncio.shield(user_turn_task)

        while (wait_for_agent and agent_active) or (wait_for_user and user_active):
            if self._closed or self._session._closing:
                raise ActivityClosedError(f"activity {self.agent.label} is closing")

            if wait_for_agent:
                await _wait_for_eou()

                if self._current_speech is None and not self._speech_q:
                    agent_active = False
                else:
                    agent_active = True
                    if (speech := self._current_speech) and speech._generations:
                        await speech._wait_for_generation()
                    elif speech:
                        # held by min_consecutive_speech_delay; wait instead of spinning
                        authorized = asyncio.ensure_future(speech._wait_for_authorization())
                        try:
                            await asyncio.wait(
                                [authorized, speech._done_fut], return_when=asyncio.FIRST_COMPLETED
                            )
                        finally:
                            authorized.cancel()
                    await asyncio.sleep(0)

            if wait_for_user:
                if self._audio_recognition and self._audio_recognition._speaking:
                    user_active = True
                    await self._audio_recognition._wait_for_user_silence()
                else:
                    user_active = False

                await _wait_for_eou()

            if self._session._user_turn_claims > 0:
                # `AgentSession.claim_user_turn` is holding idle open
                await self._session._user_turn_released.wait()
                agent_active = wait_for_agent
                user_active = wait_for_user

            if self._session._idle_holds > 0 and not _IdleHoldContextVar.get():
                # another caller holds `_wait_for_idle_and_hold` — block until release
                await self._session._idle_released.wait()
                agent_active = wait_for_agent
                user_active = wait_for_user

        if self._closed or self._session._closing:
            raise ActivityClosedError(f"activity {self.agent.label} is closing")

    # -- Realtime Session events --

    def _on_metrics_collected(
        self,
        ev: STTMetrics | TTSMetrics | VADMetrics | LLMMetrics | RealtimeModelMetrics,
    ) -> None:
        if (speech_handle := _SpeechHandleContextVar.get(None)) and (
            isinstance(ev, LLMMetrics) or isinstance(ev, TTSMetrics)
        ):
            ev.speech_id = speech_handle.id
        if (
            isinstance(ev, RealtimeModelMetrics)
            and self._realtime_spans is not None
            and (realtime_span := self._realtime_spans.pop(ev.request_id, None))
        ):
            trace_utils.record_realtime_metrics(realtime_span, ev)
        self._session._usage_collector.collect(ev)
        otel_metrics.collect_usage(ev)
        self._session.emit("metrics_collected", MetricsCollectedEvent(metrics=ev))
        self._session.emit(
            "session_usage_updated",
            SessionUsageUpdatedEvent(usage=self._session.usage),
        )

    def _on_remote_item_added(self, ev: llm.RemoteItemAddedEvent) -> None:
        # add the remote item to the local chat context as a placeholder
        local_chat_ctx = self._agent._chat_ctx
        if local_chat_ctx.get_by_id(ev.item.id) is not None:
            return

        # only add placeholders for server-initiated items (responses, function calls),
        # which always append at the end of the conversation. client-initiated items
        # (from update_chat_ctx) already exist in _agent._chat_ctx and go local→remote,
        # so they don't need placeholders.
        last_item_id = local_chat_ctx.items[-1].id if local_chat_ctx.items else None
        if ev.previous_item_id is None or ev.previous_item_id == last_item_id:
            local_chat_ctx.items.append(ev.item.model_copy())

    def _on_error(
        self,
        error: llm.LLMError
        | stt.STTError
        | tts.TTSError
        | llm.RealtimeModelError
        | inference.InterruptionDetectionError,
    ) -> None:
        if isinstance(error, llm.LLMError):
            error_event = ErrorEvent(error=error, source=self.llm)
            self._session.emit("error", error_event)
        elif isinstance(error, llm.RealtimeModelError):
            error_event = ErrorEvent(error=error, source=self.llm)
            self._session.emit("error", error_event)
        elif isinstance(error, stt.STTError):
            error_event = ErrorEvent(error=error, source=self.stt)
            self._session.emit("error", error_event)
        elif isinstance(error, tts.TTSError):
            error_event = ErrorEvent(error=error, source=self.tts)
            self._session.emit("error", error_event)
        elif isinstance(error, inference.InterruptionDetectionError):
            if not error.recoverable:
                self._fallback_to_vad_interruption(error)
            return

        self._session._on_error(error)

    def _on_end_of_agent_speech(self, *, ended_at: float) -> None:
        if self._audio_recognition is not None:
            self._audio_recognition._on_end_of_agent_speech(ended_at=ended_at)

        self._interruption_detected = False

    def _on_input_speech_started(self, _: llm.InputSpeechStartedEvent) -> None:
        if self.vad is None or self.using_default_vad:
            self._session._update_user_state("speaking")
            if self._audio_recognition:
                self._audio_recognition._on_start_of_speech(
                    started_at=time.time(),
                    user_speaking_span=self._session._user_speaking_span,
                )

        if self._rt_overlapping_speech_enabled:
            # the caller talking is not an interruption here; the model ends its own turn
            return

        try:
            # the server's own speech detection: a barge-in, like the VAD path
            self.interrupt(source="audio_activity")
        except RuntimeError:
            # only out of sync when the server cancelled its own response, with client-side turn
            # taking an uninterruptible speech is expected
            if self._rt_turn_detection_enabled:
                logger.exception(
                    "RealtimeAPI input_speech_started, but current speech is not interruptable, this should never happen!"  # noqa: E501
                )

    def _on_input_speech_stopped(self, ev: llm.InputSpeechStoppedEvent) -> None:
        if self.vad is None or self.using_default_vad:
            if self._audio_recognition:
                self._audio_recognition._on_end_of_speech(
                    ended_at=time.time(),
                    user_speaking_span=self._session._user_speaking_span,
                )

            self._session._update_user_state("listening")

        if ev.user_transcription_enabled:
            self._session._user_input_transcribed(
                UserInputTranscribedEvent(transcript="", is_final=False)
            )

    def _on_input_audio_transcription_completed(self, ev: llm.InputTranscriptionCompleted) -> None:
        self._session._user_input_transcribed(
            UserInputTranscribedEvent(
                transcript=ev.transcript,
                is_final=ev.is_final,
                item_id=ev.item_id,
            )
        )

        if ev.is_final:
            if self.stt is None and ev.transcript and (amd := self._session._amd) is not None:
                amd._on_transcript(ev.transcript)

            msg = llm.ChatMessage(
                role="user",
                content=[ev.transcript],
                id=ev.item_id,
                # an unscored transcript is still transcribed speech, not typed text
                transcript_confidence=ev.confidence if ev.confidence is not None else 1.0,
            )
            if ev.turn_started_at is not None:
                # a provider may withhold the final transcript until its reply has finished
                # generating, which would otherwise stamp the turn after the reply it prompted
                msg.created_at = ev.turn_started_at
                msg.metrics = {"started_speaking_at": ev.turn_started_at}
            self._agent._chat_ctx._upsert_item(msg)
            self._session._conversation_item_added(msg)

    def _on_generation_created(self, ev: llm.GenerationCreatedEvent) -> None:
        if ev.user_initiated:
            # user_initiated generations are directly handled inside _realtime_reply_task
            return

        if self._scheduling_paused or self._new_turns_blocked:
            # TODO(theomonnom): should we "forward" this new turn to the next agent?
            logger.warning("skipping new realtime generation, the speech scheduling is not running")
            return

        handle = SpeechHandle.create(
            allow_interruptions=self.allow_interruptions,
            input_details=InputDetails(modality="audio"),
        )
        self._session.emit(
            "speech_created",
            SpeechCreatedEvent(speech_handle=handle, user_initiated=False, source="generate_reply"),
        )

        self._create_speech_task(
            self._realtime_generation_task(
                speech_handle=handle,
                generation_ev=ev,
                model_settings=ModelSettings(),
            ),
            speech_handle=handle,
            name="AgentActivity.realtime_generation",
        )

        if (fut := self._pending_auto_tool_reply_fut) and not fut.done():
            if (run_state := self._session._global_run_state) is not None and not run_state.done():
                run_state._watch_handle(handle)
            self._pending_auto_tool_reply_fut = None
            fut.set_result(None)

        self._schedule_speech(handle, SpeechHandle.SPEECH_PRIORITY_NORMAL)

    def _interrupt_by_audio_activity(self) -> None:
        """Interrupt the current speech or generation from detected audio activity."""
        if not self._interruption_by_audio_activity_enabled:
            return

        if self._session._aec_warmup_remaining > 0 and self._session._aec_warmup_timer is not None:
            # disable interruption from audio activity while aec warmup is active
            return

        if self._rt_turn_detection_enabled:
            # ignore if realtime model has turn detection enabled
            self._interruption_detected = False
            return

        interruption_options = self._session.options.interruption
        if (
            self.stt is not None
            and interruption_options["min_words"] > 0
            and self._audio_recognition is not None
        ):
            text = self._audio_recognition._current_transcript

            # TODO(long): better word splitting for multi-language
            if len(split_words(text, split_character=True)) < interruption_options["min_words"]:
                return

        if self._rt_session is not None:
            self._rt_session.start_user_activity()

        if (
            self._current_speech is not None
            and not self._current_speech.interrupted
            and self._current_speech.allow_interruptions
        ):
            # reset the false interruption timer
            self._cancel_false_interruption_timer()

            # only interrupt if not already interrupting
            if (
                self._audio_recognition
                and not self._audio_recognition._endpointing.overlapping
                and self._session.agent_state == "speaking"
            ):
                self._audio_recognition._on_start_of_speech(
                    started_at=time.time(),
                )

            if self._pause_enabled():
                timeout = interruption_options["false_interruption_timeout"]
                assert timeout is not None
                audio_output = self._session.output.audio
                assert audio_output is not None

                # EOS arms false-interruption resume. A final transcript or a
                # replying turn commit interrupts the paused handle.
                self._update_paused_speech(self._current_speech, timeout)
                audio_output.pause()
                self._session._update_agent_state("listening")
                self._on_end_of_agent_speech(ended_at=time.time())
                if self.interruption_enabled:
                    self.interruption_by_audio_activity_enabled = True
            else:
                if self._rt_session is not None:
                    self._rt_session.interrupt()

                self._current_speech.interrupt(source="audio_activity")
        elif self._current_speech is None or not self._current_speech.interrupted:
            self._interruption_detected = False

    # region recognition hooks

    def on_start_of_speech(
        self,
        ev: vad.VADEvent | None,
        speech_start_time: float,
    ) -> None:
        self._session._update_user_state("speaking", last_speaking_time=speech_start_time)
        if self._audio_recognition:
            self._audio_recognition._on_start_of_speech(
                started_at=speech_start_time,
                speech_duration=ev.speech_duration if ev else 0.0,
                user_speaking_span=self._session._user_speaking_span,
                skip_adaptive_interruption=self._interruption_detected,
            )
        self._user_silence_event.clear()
        self._stt_eos_received = False

        # cancel the timer when user starts speaking but leave the paused state unchanged
        self._cancel_false_interruption_timer()

        if (
            self._session.agent_state != "speaking"
            and self._pause_enabled()
            and (current_speech := self._current_speech) is not None
            and not current_speech.interrupted
            and current_speech.allow_interruptions
            and (self._paused_speech is None or self._paused_speech.handle is not current_speech)
        ):
            # EOS arms false-interruption resume. A final transcript or a
            # replying turn commit interrupts the paused handle.
            audio_output = self._session.output.audio
            assert audio_output is not None

            self._update_paused_speech(current_speech, timeout=0)
            audio_output.pause()

    def on_end_of_speech(self, ev: vad.VADEvent | None) -> None:
        speech_end_time = time.time()
        if ev:
            speech_end_time = speech_end_time - ev.silence_duration - ev.inference_duration
        else:
            self._stt_eos_received = True

        if self._audio_recognition:
            self._audio_recognition._on_end_of_speech(
                ended_at=speech_end_time,
                user_speaking_span=self._session._user_speaking_span,
                interruption=self._interruption_detected
                if self._interruption_detection_enabled
                else NOT_GIVEN,
            )

        self._session._update_user_state(
            "listening",
            last_speaking_time=speech_end_time,
        )
        self._user_silence_event.set()

        if self._paused_speech:
            self._start_false_interruption_timer(self._paused_speech.timeout)

    def on_transcription_timeout(self, *, speech_duration: float, turn_start: float) -> None:
        self._session.emit(
            "user_transcription_timeout",
            UserTranscriptionTimeoutEvent(
                speech_duration=speech_duration,
                vad_speech_started_at=turn_start,
            ),
        )

    def on_vad_inference_done(self, ev: vad.VADEvent) -> None:
        if self._turn_detection in ("manual", "realtime_llm"):
            # ignore vad inference done event if turn_detection is manual or realtime_llm
            return

        active_speech = ev.speech_duration >= self._session.options.interruption["min_duration"]
        if active_speech and (
            self._turn_detection != "stt"
            or not self._stt_eos_received
            or ev.raw_accumulated_silence == 0
        ):
            # STT may send EOS before VAD EOS, we only interrupt if:
            # 1. turn detection is not STT; or
            # 2. STT EOS hasn't been received yet; or
            # 3. VAD speech is still ongoing
            self._interrupt_by_audio_activity()

        if (
            ev.speaking
            # allow some silence between utterances during active speech
            and ev.raw_accumulated_silence <= self.min_endpointing_delay / 2
        ):
            self._user_silence_event.clear()
        else:
            self._user_silence_event.set()

    def on_backchannel_confirmed(self) -> None:
        # clear the buffered backchannel audio so it can't prefix the next committed turn
        if (
            self._interruption_detection_enabled
            and self._rt_session is not None
            and self._turn_detection not in ("manual", "realtime_llm")
        ):
            self._rt_session.clear_audio()

    def on_overlap_speech(self, ev: inference.OverlappingSpeechEvent) -> None:
        if ev.is_interruption:
            self._interruption_detected = True

        self._session.emit("overlapping_speech", ev)
        if self._audio_recognition is not None:
            # Release held transcripts before re-enabling VAD interruption.
            self._audio_recognition._on_overlap_speech_event(ev)

        if not ev.is_interruption:
            return

        self.interruption_by_audio_activity_enabled = True
        self._interrupt_by_audio_activity()

    def on_interim_transcript(self, ev: stt.SpeechEvent, *, speaking: bool | None) -> None:
        if isinstance(self.llm, llm.RealtimeModel) and self.llm.capabilities.user_transcription:
            # skip stt transcription if user_transcription is enabled on the realtime model
            return

        self._session._user_input_transcribed(
            UserInputTranscribedEvent(
                language=ev.alternatives[0].language,
                transcript=ev.alternatives[0].text,
                is_final=False,
                speaker_id=ev.alternatives[0].speaker_id,
            ),
        )

        if (
            self.vad is None
            and ev.alternatives[0].text
            and self._turn_detection
            not in (
                "manual",
                "realtime_llm",
            )
        ):
            self._interrupt_by_audio_activity()

            if (
                speaking is False
                and self._paused_speech
                and (timeout := self._session.options.interruption["false_interruption_timeout"])
                is not None
            ):
                # schedule a resume timer if interrupted after end_of_speech
                self._start_false_interruption_timer(timeout)

    def on_final_transcript(self, ev: stt.SpeechEvent, *, speaking: bool | None = None) -> None:
        if isinstance(self.llm, llm.RealtimeModel) and self.llm.capabilities.user_transcription:
            # skip stt transcription if user_transcription is enabled on the realtime model
            return

        self._session._user_input_transcribed(
            UserInputTranscribedEvent(
                language=ev.alternatives[0].language,
                transcript=ev.alternatives[0].text,
                is_final=True,
                speaker_id=ev.alternatives[0].speaker_id,
            ),
        )
        # agent speech might not be interrupted if VAD failed and a final transcript is received
        # we call _interrupt_by_audio_activity (idempotent) to pause the speech, if possible
        # which will also be immediately interrupted

        if self._audio_recognition and self._turn_detection not in (
            "manual",
            "realtime_llm",
        ):
            self._interrupt_by_audio_activity()

            if (
                speaking is False
                and self._paused_speech
                and (timeout := self._session.options.interruption["false_interruption_timeout"])
                is not None
            ):
                # schedule a resume timer if interrupted after end_of_speech
                self._start_false_interruption_timer(timeout)

        self._cancel_speech_pause_task = asyncio.create_task(
            self._cancel_speech_pause(old_task=self._cancel_speech_pause_task)
        )

    def on_preemptive_generation(self, info: _PreemptiveGenerationInfo) -> None:
        preemptive_opts = self.preemptive_generation_opts
        if (
            not preemptive_opts["enabled"]
            or self._scheduling_paused
            or self._new_turns_blocked
            or (self._current_speech is not None and not self._current_speech.interrupted)
            or not isinstance(self.llm, llm.LLM)
        ):
            return

        # a newer attempt supersedes the current one; if one is created below it continues the
        # discarded attempt's agent_turn (the cancelled speech only ends once the loop runs)
        discarded = (
            self._preemptive_generation.speech_handle
            if self._preemptive_generation is not None
            else None
        )
        self._cancel_preemptive_generation()

        if (
            info.started_speaking_at is not None
            and time.time() - info.started_speaking_at > preemptive_opts["max_speech_duration"]
        ):
            return

        if self._preemptive_generation_count >= preemptive_opts["max_retries"]:
            return

        self._preemptive_generation_count += 1

        user_message = llm.ChatMessage(
            role="user",
            content=[info.new_transcript],
            transcript_confidence=info.transcript_confidence,
        )

        chat_ctx = self._agent.chat_ctx.copy()
        speech_handle = self._generate_reply(
            # we need to send in the original user_message because metrics are injected later on
            user_message=user_message,
            chat_ctx=chat_ctx,
            schedule_speech=False,
            input_details=InputDetails(modality="audio"),
        )
        _continue_discarded_turn(discarded, speech_handle)

        self._preemptive_generation = _PreemptiveGeneration(
            speech_handle=speech_handle,
            user_message=user_message,
            info=info,
            chat_ctx=chat_ctx.copy(),
            tools=self.tools.copy(),
            tool_choice=self._tool_choice,
            created_at=time.time(),
        )

    def on_preflight_stale(self, info: _PreflightStaleInfo) -> None:
        """Cancel the preemptive generation once the transcript has moved past the preflight.

        Called for each non-empty interim transcript that arrives while a preflight is pending.
        A reply whose transcript is no longer equivalent cannot be adopted at the end of turn,
        so it is stopped now instead of at the next preflight or final transcript.

        Args:
            info: Carries the current turn transcript, including the interim text.
        """
        if (preemptive := self._preemptive_generation) is not None and not _transcripts_equivalent(
            preemptive.info.new_transcript, info.new_transcript
        ):
            self._cancel_preemptive_generation()

    def on_eot_prediction(self, ev: EotPredictionEvent) -> None:
        if (host := self._session._session_host) is not None:
            host._on_eot_prediction(ev)

    def on_agent_backchannel_opportunity(self, ev: _AgentBackchannelOpportunityEvent) -> None:
        # TODO: consume the backchannel opportunity internally (e.g. trigger a
        # backchannel phrase). Kept internal for now — not surfaced as a public event.
        pass

    def on_end_of_turn(self, info: _EndOfTurnInfo) -> bool:
        # IMPORTANT: This method is sync to avoid it being cancelled by the AudioRecognition
        # We explicitly create a new task here

        # TODO: @chenghao-mou replace this direct call with the public `eot_prediction`
        # event once feat/AGT-2520-multimodal-EOU lands.
        if (amd := self._session._amd) is not None and amd._on_end_of_turn(info):
            # cancel post-verdict preemptive and new generations
            self._cancel_preemptive_generation()
            info.skip_reply = True

        if self._scheduling_paused or self._new_turns_blocked:
            self._cancel_preemptive_generation()
            logger.warning(
                "skipping user input, speech scheduling is paused",
                extra={"lk.pii.user_input": info.new_transcript},
            )

            if self._session._closing:
                # add user input to chat context
                user_message = llm.ChatMessage(
                    role="user",
                    content=[info.new_transcript],
                    transcript_confidence=info.transcript_confidence,
                )
                user_message.metrics = self._init_metrics_from_end_of_turn(info)
                self._agent._chat_ctx.items.append(user_message)
                self._session._conversation_item_added(user_message)

            # TODO(theomonnom): should we "forward" this new turn to the next agent/activity?
            return True

        # avoid interruption if the new_transcript is too short
        if (
            self.stt is not None
            and self._turn_detection != "manual"
            and self._current_speech is not None
            and self._current_speech.allow_interruptions
            and not self._current_speech.interrupted
            and self._session.options.interruption["min_words"] > 0
            and len(split_words(info.new_transcript, split_character=True))
            < self._session.options.interruption["min_words"]
        ):
            self._cancel_preemptive_generation()
            return False

        # avoid interruption if backchannel is detected with realtime model. an unjudged overlap
        # commits: interrupting the agent is recoverable, discarding a real user turn is not
        if (
            self.stt is None
            and self._turn_detection != "manual"
            and isinstance(self.llm, llm.RealtimeModel)
            and not self._rt_turn_detection_enabled
            and self._interruption_detection_enabled
            and info.backchannel_over_agent
        ):
            logger.debug("skipping user input, realtime backchannel detected")
            self._cancel_preemptive_generation()
            # no transcript to gatekeep for realtime barge-in — drop the backchannel turn
            # and clear the buffered audio so it can't leak into the next committed turn
            if self._rt_session is not None:
                self._rt_session.clear_audio()
            return False

        # a replying turn interrupts the paused speech, so cancel the resume that would race it —
        # but the reply task returns before that in these two cases, so leave the resume armed
        if not info.skip_reply and not self._rt_turn_detection_enabled:
            self._cancel_false_interruption_timer()

        if (
            isinstance(self.llm, llm.RealtimeModel)
            and (last_speaking_time := self._last_user_speaking_time) is not None
            and last_speaking_time > self._realtime_user_input_answered_at
        ):
            # AudioRecognition clears its turn timestamps after this hook returns.
            self._session._unanswered_user_metrics = {"stopped_speaking_at": last_speaking_time}

        old_task = self._user_turn_completed_atask
        # the user turn ends after on_user_turn_completed (see _end_user_turn_span)
        info.user_turn_span_adopted = info.user_turn_span is not None
        self._user_turn_completed_atask = self._create_speech_task(
            self._user_turn_completed_task(old_task, info),
            name="AgentActivity._user_turn_completed_task",
        )
        return True

    @utils.log_exceptions(logger=logger)
    async def _user_turn_completed_task(
        self, old_task: asyncio.Task[None] | None, info: _EndOfTurnInfo
    ) -> None:
        try:
            await self._user_turn_completed_impl(old_task, info)
        finally:
            _end_user_turn_span(info)

    async def _user_turn_completed_impl(
        self, old_task: asyncio.Task[None] | None, info: _EndOfTurnInfo
    ) -> None:
        if old_task is not None:
            # We never cancel user code as this is very confusing.
            # So we wait for the old execution of on_user_turn_completed to finish.
            # In practice this is OK because most speeches will be interrupted if a new turn
            # is detected. So the previous execution should complete quickly.
            await asyncio.wait({old_task})
            if not old_task.cancelled():
                old_task.result()

        self._preemptive_generation_count = 0

        # When the audio recognition detects the end of a user turn:
        #  - check if realtime model server-side turn detection is enabled
        #  - check if there is no current generation happening
        #  - cancel the current generation if it allows interruptions (otherwise skip the reply
        #  but keep the user message)
        #  - generate a reply to the user input

        # interrupt all background speeches and wait for them to finish to update the chat context
        await asyncio.gather(*self._interrupt_background_speeches(force=False))

        user_message = llm.ChatMessage(
            role="user",
            content=[info.new_transcript],
            transcript_confidence=info.transcript_confidence,
        )

        metrics_report: llm.MetricsReport = self._init_metrics_from_end_of_turn(info)

        if user_message is not None:
            user_message.metrics = metrics_report

        if isinstance(self.llm, llm.RealtimeModel):
            if self._rt_turn_detection_enabled:
                return

            if self._rt_session is not None:
                if info.skip_reply:
                    if info.new_transcript != "":
                        # only add user message to chat context if reply should be skipped
                        self._agent._chat_ctx.items.append(user_message)
                        self._session._conversation_item_added(user_message)
                    return
                self._rt_session.commit_audio()

        if info.skip_reply:
            if info.new_transcript != "":
                self._agent._chat_ctx.items.append(user_message)
                self._session._conversation_item_added(user_message)
            return

        if (current_speech := self._current_speech) is not None:
            if not current_speech.allow_interruptions:
                logger.warning(
                    "skipping reply to user input, current speech generation cannot be interrupted",
                    extra={"lk.pii.user_input": info.new_transcript},
                )
                # only the reply is skipped: if the user audio was kept, keep the message too
                # (realtime models add their own transcript, the STT copy would duplicate it)
                if (
                    info.new_transcript != ""
                    and not self._session.options.interruption["discard_audio_if_uninterruptible"]
                    and not isinstance(self.llm, llm.RealtimeModel)
                ):
                    self._agent._chat_ctx.items.append(user_message)
                    self._session._conversation_item_added(user_message)
                return
            await self._cancel_speech_pause(self._cancel_speech_pause_task)

            await current_speech.interrupt(source="user_turn")

            if self._rt_session is not None:
                self._rt_session.interrupt()

        if self._scheduling_paused or self._new_turns_blocked:
            logger.warning(
                "skipping on_user_turn_completed, speech scheduling is paused",
                extra={"lk.pii.user_input": info.new_transcript},
            )
            if self._session._closing:
                self._agent._chat_ctx.items.append(user_message)
                self._session._conversation_item_added(user_message)
            return

        # create a temporary mutable chat context to pass to on_user_turn_completed
        # the user can edit it for the current generation, but changes will not be kept inside the
        # Agent.chat_ctx
        temp_mutable_chat_ctx = self._agent.chat_ctx.copy()
        start_time = time.perf_counter()
        # user code that gates the reply; without a span a slow hook is an unexplained gap
        with tracer.start_as_current_span(
            "on_user_turn_completed",
            context=(
                trace.set_span_in_context(info.user_turn_span)
                if info.user_turn_span_adopted and info.user_turn_span is not None
                else self._session._root_span_context
            ),
            attributes={trace_types.ATTR_AGENT_LABEL: self._agent.label},
        ) as hook_span:
            try:
                await self._agent.on_user_turn_completed(
                    temp_mutable_chat_ctx, new_message=user_message
                )
            except StopResponse:
                hook_span.add_event("stop_response")
                return  # ignore this turn
            except Exception as e:
                # the message may quote the transcript: honour the session's redaction too
                trace_utils.record_exception(
                    hook_span,
                    e,
                    redacted=self._session._redaction_enabled or trace_utils.redaction_enabled(),
                )
                logger.exception("error occurred during on_user_turn_completed")
                return

        on_user_turn_completed_delay = time.perf_counter() - start_time
        metrics_report["on_user_turn_completed_delay"] = on_user_turn_completed_delay

        if isinstance(self.llm, llm.RealtimeModel):
            # ignore stt transcription for realtime model
            user_message = None  # type: ignore
        elif self.llm is None:
            return  # skip response if no llm is set

        if self._scheduling_paused or self._new_turns_blocked:
            logger.warning(
                "skipping reply to user input, speech scheduling is paused",
                extra={"lk.pii.user_input": info.new_transcript},
            )
            if user_message and self._session._closing:
                self._agent._chat_ctx.items.append(user_message)
                self._session._conversation_item_added(user_message)
            return

        speech_handle: SpeechHandle | None = None
        discarded_preemptive: SpeechHandle | None = None
        if preemptive := self._preemptive_generation:
            # make sure the on_user_turn_completed didn't change some request parameters
            # otherwise invalidate the preemptive generation
            if (
                _transcripts_equivalent(
                    preemptive.info.new_transcript, user_message.raw_text_content
                )
                and preemptive.chat_ctx.is_equivalent(temp_mutable_chat_ctx)
                and preemptive.tools == self.tools
                and preemptive.tool_choice == self._tool_choice
            ):
                speech_handle = preemptive.speech_handle

                # The pipeline task retains the ChatMessage created for preemptive generation.
                # Reconcile it with the finalized message before scheduling so conversation
                # history keeps the final transcript and on_user_turn_completed edits.
                preemptive.user_message.content = user_message.content.copy()
                preemptive.user_message.transcript_confidence = user_message.transcript_confidence
                preemptive.user_message.metrics = metrics_report
                self._schedule_speech(speech_handle, priority=SpeechHandle.SPEECH_PRIORITY_NORMAL)
                logger.debug(
                    "using preemptive generation",
                    extra={"preemptive_lead_time": time.time() - preemptive.created_at},
                )
            else:
                logger.warning(
                    "preemptive generation invalidated after `on_user_turn_completed` because "
                    "the transcript, chat context, tools, or tool choice changed",
                )
                discarded_preemptive = preemptive.speech_handle
                preemptive.speech_handle._cancel()

            self._preemptive_generation = None

        if speech_handle is None:
            # Ensure the new message is passed to generate_reply
            # This preserves the original message_id, making it easier for users to track responses
            speech_handle = self._generate_reply(
                user_message=user_message,
                chat_ctx=temp_mutable_chat_ctx,
                input_details=InputDetails(modality="audio"),
            )
            # the invalidated preemptive attempt answered this same turn: one agent_turn
            _continue_discarded_turn(discarded_preemptive, speech_handle)

        if self._user_turn_completed_atask != asyncio.current_task():
            # If a new user turn has already started, interrupt this one since it's now outdated
            # (We still create the SpeechHandle and the generate_reply coroutine, otherwise we may
            # lose data like the beginning of a user speech).
            # await the interrupt to make sure user message is added to the chat context before the new task starts
            await speech_handle.interrupt(source="user_turn")

        metadata: Metadata | None = None
        if isinstance(self._turn_detection, str):
            metadata = Metadata(model_name="unknown", model_provider=self._turn_detection)
        elif self._turn_detection is not None:
            metadata = Metadata(
                model_name=self._turn_detection.model, model_provider=self._turn_detection.provider
            )

        eou_metrics = EOUMetrics(
            timestamp=time.time(),
            end_of_utterance_delay=info.metrics.end_of_turn_delay or 0.0,
            transcription_delay=info.metrics.transcription_delay or 0.0,
            on_user_turn_completed_delay=on_user_turn_completed_delay,
            speech_id=speech_handle.id,
            metadata=metadata,
        )
        self._session.emit("metrics_collected", MetricsCollectedEvent(metrics=eou_metrics))

    def on_user_turn_exceeded(self, ev: UserTurnExceededEvent) -> None:
        if self._scheduling_paused or self._new_turns_blocked:
            logger.warning(
                "skipping user turn exceeded, speech scheduling is paused",
                extra={
                    "num_words": ev.accumulated_word_count,
                    "duration": ev.duration,
                },
            )
            return

        if self._user_turn_exceeded_locked:
            return  # user callback is executing, drop

        # cancel previous wait phase (if still waiting for EOU result)
        if self._user_turn_exceeded_atask is not None:
            self._user_turn_exceeded_atask.cancel()

        self._user_turn_exceeded_atask = self._create_speech_task(
            self._user_turn_exceeded_task(ev),
            name="AgentActivity._user_turn_exceeded_task",
        )

    @utils.log_exceptions(logger=logger)
    async def _user_turn_exceeded_task(self, ev: UserTurnExceededEvent) -> None:
        agent_speaking_fut = asyncio.Future[None]()

        def _on_agent_state_changed(state_ev: AgentStateChangedEvent) -> None:
            if state_ev.new_state == "speaking" and not agent_speaking_fut.done():
                agent_speaking_fut.set_result(None)

        if self._session.agent_state == "speaking":
            agent_speaking_fut.set_result(None)
        else:
            self._session.on("agent_state_changed", _on_agent_state_changed)

        # wait for the EOU-triggered agent response (cancellable by the new user turn exceeded event)
        wait_inactive = asyncio.ensure_future(
            self.wait_for_idle(wait_for_agent=True, wait_for_user=False)
        )
        try:
            done, _ = await asyncio.wait(
                (agent_speaking_fut, wait_inactive), return_when=asyncio.FIRST_COMPLETED
            )
            if agent_speaking_fut in done:
                # agent started speaking, skip the user turn exceeded event
                return
        finally:
            self._session.off("agent_state_changed", _on_agent_state_changed)
            if not wait_inactive.done():
                wait_inactive.cancel()

        # re-check after the wait phase: if a handoff started in the meantime,
        # don't fire the callback on this now-stale activity.
        if self._scheduling_paused or self._new_turns_blocked:
            return

        # custom callback, locked - don't cancel user's callback
        logger.debug(
            "user turn limit exceeded",
            extra={"num_words": ev.accumulated_word_count, "duration": ev.duration},
        )
        self._user_turn_exceeded_locked = True
        try:
            await self._agent.on_user_turn_exceeded(ev)
        except Exception:
            logger.exception("error in on_user_turn_exceeded callback")
        finally:
            self._user_turn_exceeded_locked = False
            self._user_turn_exceeded_atask = None

    # AudioRecognition is calling this method to retrieve the chat context before running the TurnDetector model  # noqa: E501
    def retrieve_chat_ctx(self) -> llm.ChatContext:
        return self._agent.chat_ctx

    # endregion

    def _render_realtime_instructions(self, instructions: str | Instructions) -> str:
        """Resolve instructions to a plain string for the realtime session.

        Realtime instructions are session-level (there is no per-turn modality
        resolution like the pipeline path), so modality-specific ``Instructions``
        resolve to the realtime model's output modality.
        """
        if isinstance(instructions, Instructions):
            assert isinstance(self.llm, llm.RealtimeModel)
            modality: Literal["audio", "text"] = (
                "audio" if self.llm.capabilities.audio_output else "text"
            )
            return instructions.render(modality=modality)
        return instructions

    def _resolve_expressive_options(self) -> ExpressiveOptions | None:
        """Resolve the effective expressive setting. Returns None if disabled.

        The agent's ``expressive`` overrides the session's when set, matching how the
        agent's ``llm``/``tts`` override the session models.

        Expressive mode requires two things of the TTS:

        - a markup dialect (``llm_instructions()`` is not ``None``). Without one no
          markers can appear, and xml-aware chunking would re-introduce the stray-``<``
          streaming stall for nothing.
        - something to *lower* those markers, or the TTS speaks them aloud. Guaranteed
          only where the framework owns the input path: the gateway TTS's own stream, and
          the ``tts.StreamAdapter`` wrapping every non-streaming TTS. A natively
          streaming plugin owns its own input task — several declare a dialect today
          without lowering anything. A ``StreamAdapter`` handed in directly is streaming
          only at its surface; inside it is that same lowering path, so it is exempt.
        """
        from .agent_session import DEFAULT_EXPRESSIVE_OPTIONS, resolve_expressive_options

        if (
            self.tts is None
            or self.tts.markup.llm_instructions() is None
            or (
                self.tts.capabilities.streaming
                and not isinstance(self.tts, (inference.TTS, tts.StreamAdapter))
            )
        ):
            return None

        expr = (
            self._agent.expressive
            if is_given(self._agent.expressive)
            else self._session._expressive
        )
        if not expr and not isinstance(expr, dict):
            return None
        # speech_steering renders per-provider delivery guidelines on top of the
        # provider-agnostic default; explicit templates override
        provider_key = self.tts.markup._provider_key() if self.tts else ""
        return resolve_expressive_options(
            expr if isinstance(expr, dict) else {},
            provider_key=provider_key,
            default=DEFAULT_EXPRESSIVE_OPTIONS,
        )

    def _inject_expressive_instructions(
        self,
        chat_ctx: llm.ChatContext,
        options: ExpressiveOptions,
        speech_handle: SpeechHandle,
    ) -> None:
        """Inject the TTS markup guide into the chat context."""

        def _to_instructions(v: Instructions | str) -> Instructions:
            return v if isinstance(v, Instructions) else Instructions(v)

        turn_modality = speech_handle.input_details.modality if speech_handle else None

        tts_instructions = (
            self.tts.markup.llm_instructions(speech_steering=options.get("speech_steering"))
            if self.tts
            else None
        )
        if tts_instructions:
            tts_template = _to_instructions(options["tts_instructions_template"])
            text = tts_template.render(
                modality=turn_modality,
                data={
                    "tts": {
                        "markup": {
                            "llm_instructions": tts_instructions,
                        },
                    },
                },
            )
            if text.strip():
                # keyed message: re-injection replaces last turn's guide instead of
                # stacking copies, and an expressive-off turn removes it again
                update_expressive_instructions(chat_ctx, text=text)

    @property
    def _no_pending_speech(self) -> bool:
        return not self._speech_q and (not self._current_speech or self._current_speech.done())

    def _on_pipeline_reply_done(self, _: asyncio.Task[None]) -> None:
        if self._no_pending_speech:
            # a speech awaiting its tool executions keeps the agent busy: stay in
            # "thinking" so the user-away timer isn't armed mid-tool (#6904)
            self._session._update_agent_state(
                "thinking" if self._background_speeches else "listening"
            )
            self._on_end_of_agent_speech(ended_at=time.time())
            if self.interruption_enabled:
                self.interruption_by_audio_activity_enabled = True

    @utils.log_exceptions(logger=logger)
    async def _tts_task(
        self,
        speech_handle: SpeechHandle,
        text: str | AsyncIterable[str],
        audio: AsyncIterable[rtc.AudioFrame] | None,
        add_to_chat_ctx: bool,
        model_settings: ModelSettings,
        _previous_user_metrics: llm.MetricsReport | None = None,
    ) -> None:
        with _agent_turn(
            speech_handle,
            root_context=self._session._root_span_context,
            agent_label=self._agent.label,
        ):
            await self._tts_task_impl(
                speech_handle=speech_handle,
                text=text,
                audio=audio,
                add_to_chat_ctx=add_to_chat_ctx,
                model_settings=model_settings,
                _previous_user_metrics=_previous_user_metrics,
            )

    async def _tts_task_impl(
        self,
        speech_handle: SpeechHandle,
        text: str | AsyncIterable[str],
        audio: AsyncIterable[rtc.AudioFrame] | None,
        add_to_chat_ctx: bool,
        model_settings: ModelSettings,
        _previous_user_metrics: llm.MetricsReport | None = None,
    ) -> None:
        current_span = trace.get_current_span(context=speech_handle._agent_turn_context)
        current_span.set_attribute(trace_types.ATTR_SPEECH_ID, speech_handle.id)

        tr_output = (
            self._session.output.transcription
            if self._session.output.transcription_enabled
            else None
        )
        audio_output = self._session.output.audio if self._session.output.audio_enabled else None

        # See discussion in https://github.com/livekit/agents/issues/4432
        authorization_tasks: list[asyncio.Future[Any]] = [
            asyncio.ensure_future(speech_handle._wait_for_authorization()),
            asyncio.ensure_future(self._authorization_allowed.wait()),
        ]
        if speech_handle.allow_interruptions:
            authorization_tasks.append(asyncio.ensure_future(self._user_silence_event.wait()))
        await speech_handle.wait_if_not_interrupted(authorization_tasks)
        speech_handle._clear_authorization()
        _record_queue_wait(speech_handle)

        if speech_handle.interrupted:
            current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, True)
            _record_interruption(speech_handle)
            await utils.aio.cancel_and_wait(*authorization_tasks)
            return

        text_source: AsyncIterable[str] | None = None
        audio_source: AsyncIterable[str] | None = None

        tee: utils.aio.itertools.Tee[str] | None = None
        if isinstance(text, AsyncIterable):
            tee = utils.aio.itertools.tee(text, 2)
            text_source, audio_source = tee
        elif isinstance(text, str):

            async def _read_text() -> AsyncIterable[str]:
                yield text

            text_source = _read_text()
            audio_source = _read_text()

        tts_task: asyncio.Task[Any] | None = None
        forward_audio_task: asyncio.Task[Any] | None = None
        forward_text_task: asyncio.Task[Any] | None = None
        started_speaking_at: float | None = None
        stopped_speaking_at: float | None = None
        started_forwarding_at: float | None = None

        def _on_first_frame(fut: asyncio.Future[float] | asyncio.Future[None]) -> None:
            """
            Callback to update the agent state when the first frame is captured:
            1. _AudioOutput.first_frame_fut (float)
            2. _TextOutput.first_text_fut (None)
            """
            nonlocal started_speaking_at, started_forwarding_at
            try:
                started_speaking_at = fut.result() or time.time()
                started_forwarding_at = (
                    audio_out.started_forwarding_at
                    if audio_out and audio_out.started_forwarding_at is not None
                    else started_speaking_at
                )
            except BaseException:
                return

            self._session._update_agent_state(
                "speaking",
                start_time=started_speaking_at,
                otel_context=speech_handle._agent_turn_context,
            )
            if self._audio_recognition:
                self._audio_recognition._on_start_of_agent_speech(started_at=started_speaking_at)
            if self.interruption_enabled:
                self._disable_vad_interruption_soon()

        audio_out: _AudioOutput | None = None
        tts_gen_data: _TTSGenerationData | None = None
        if audio_output is not None:
            if audio is None:
                # generate audio using TTS
                tts_task, tts_gen_data = perform_tts_inference(
                    node=self._agent.tts_node,
                    input=audio_source,
                    model_settings=model_settings,
                    text_transforms=self._session.options.tts_text_transforms,
                    model=self.tts.model if self.tts else None,
                    provider=self.tts.provider if self.tts else None,
                )
                if (
                    self.use_tts_aligned_transcript
                    and (tts := self.tts)
                    and (tts.capabilities.aligned_transcript or not tts.capabilities.streaming)
                    and (timed_texts := await tts_gen_data.timed_texts_fut)
                ):
                    text_source = _aligned_transcript_or_text(timed_texts, text_source)

                forward_audio_task, audio_out = perform_audio_forwarding(
                    audio_output=audio_output,
                    tts_output=tts_gen_data.audio_ch,
                    reconcile_playout_pause=lambda: self._reconcile_playout_pause(speech_handle),
                    tts_data=tts_gen_data,
                )
            else:
                # use the provided audio
                forward_audio_task, audio_out = perform_audio_forwarding(
                    audio_output=audio_output,
                    tts_output=audio,
                    reconcile_playout_pause=lambda: self._reconcile_playout_pause(speech_handle),
                )

            audio_out.first_frame_fut.add_done_callback(_on_first_frame)

        # text output
        tr_node = self._agent.transcription_node(text_source, model_settings)
        tr_node_result = await tr_node if asyncio.iscoroutine(tr_node) else tr_node
        text_out: _TextOutput | None = None
        if tr_node_result is not None:
            forward_text_task, text_out = perform_text_forwarding(
                text_output=tr_output,
                source=tr_node_result,
            )
            if audio_output is None:
                # update the agent state based on text if no audio output
                text_out.first_text_fut.add_done_callback(_on_first_frame)

        all_tasks: list[asyncio.Future[Any]] = [
            t for t in (tts_task, forward_audio_task, forward_text_task) if t is not None
        ]
        await speech_handle.wait_if_not_interrupted(all_tasks)

        # check for errors in generation/forwarding tasks (e.g. missing audio file)
        for task in (tts_task, forward_audio_task, forward_text_task):
            if task is not None and task.done() and not task.cancelled():
                if exc := task.exception():
                    raise exc

        if audio_output is not None:
            await speech_handle.wait_if_not_interrupted(
                [asyncio.ensure_future(audio_output.wait_for_playout())]
            )

        stopped_speaking_at = time.time()
        current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, speech_handle.interrupted)
        _record_interruption(speech_handle)
        if speech_handle.interrupted:
            await utils.aio.cancel_and_wait(*all_tasks)

            if audio_output is not None:
                audio_output.clear_buffer()
                await audio_output.wait_for_playout()

        if tee is not None:
            await tee.aclose()

        # use synchronized transcript when available after interruption
        forwarded_text = text_out.text if text_out else ""
        if speech_handle.interrupted and audio_output is not None:
            playback_ev = await audio_output.wait_for_playout()

            played_own_frame = (
                audio_out is not None
                and audio_output.captured_playout_segments > audio_out.captured_segments_before
            )
            if played_own_frame:
                # wait_for_playout returns the previous segment's event when this speech
                # never reached the output
                current_span.set_attribute(
                    trace_types.ATTR_PLAYOUT_POSITION, playback_ev.playback_position
                )
            if (
                audio_out is not None
                and played_own_frame
                and (
                    (audio_out.first_frame_fut.done() and not audio_out.first_frame_fut.cancelled())
                    or playback_ev.playback_position > 0
                )
            ):
                if playback_ev.synchronized_transcript is not None:
                    forwarded_text = playback_ev.synchronized_transcript
            else:
                forwarded_text = ""
        current_span.set_attribute(trace_types.ATTR_RESPONSE_TEXT, forwarded_text)

        assistant_metrics: llm.MetricsReport = {}

        if tts_gen_data and tts_gen_data.ttfb is not None:
            assistant_metrics["tts_node_ttfb"] = tts_gen_data.ttfb

        if stopped_speaking_at and started_speaking_at:
            assistant_metrics["started_speaking_at"] = started_speaking_at
            assistant_metrics["stopped_speaking_at"] = stopped_speaking_at

            if started_forwarding_at is not None:
                assistant_metrics["playback_latency"] = started_speaking_at - started_forwarding_at

            # the audio answers the user turn, stored message or not
            if _previous_user_metrics and "stopped_speaking_at" in _previous_user_metrics:
                e2e_latency = started_speaking_at - _previous_user_metrics["stopped_speaking_at"]
                assistant_metrics["e2e_latency"] = e2e_latency
                current_span.set_attribute(trace_types.ATTR_E2E_LATENCY, e2e_latency)
                _record_user_turn_stages(current_span, _previous_user_metrics)

        spoken_msg: llm.ChatMessage | None = None
        if forwarded_text and add_to_chat_ctx:
            spoken_msg = self._agent._chat_ctx.add_message(
                role="assistant",
                content=forwarded_text,
                interrupted=speech_handle.interrupted,
                created_at=started_speaking_at if started_speaking_at is not None else time.time(),
                metrics=assistant_metrics,
            )
            speech_handle._item_added([spoken_msg])
            self._session._conversation_item_added(spoken_msg)

        if self._session.agent_state == "speaking":
            self._session._update_agent_state(
                "thinking" if self._background_speeches else "listening"
            )
            self._on_end_of_agent_speech(ended_at=time.time())
            if self.interruption_enabled:
                self.interruption_by_audio_activity_enabled = True

        if audio_out is not None and not audio_out.first_frame_fut.done():
            audio_out.first_frame_fut.cancel()

        if (
            spoken_msg is not None
            and self._rt_session is not None
            and isinstance(self.llm, llm.RealtimeModel)
            and self.llm.capabilities.mutable_chat_context
        ):
            # playout is over, so the next speech can start while the update is acknowledged
            speech_handle._mark_generation_done()
            # send the spoken text, placed by when it started, so the model's history keeps
            # the order it was said in even if the user spoke during playback
            rt_chat_ctx = self._rt_session.chat_ctx.copy()
            rt_chat_ctx.insert(spoken_msg)
            try:
                await self._rt_session.update_chat_ctx(rt_chat_ctx)
            except llm.RealtimeError as e:
                logger.warning(
                    "failed to add the spoken message to the realtime chat context",
                    extra={"error": str(e)},
                )

    def _on_enter_ignored_tools(self, tool_ctx: llm.ToolContext) -> list[llm.Tool]:
        """Tools flagged IGNORE_ON_ENTER, when this reply runs inside on_enter."""
        on_enter_data = _OnEnterContextVar.get(None)
        if (
            on_enter_data is None
            or on_enter_data.agent != self._agent
            or on_enter_data.session != self._session
        ):
            return []
        return [
            tool
            for tool in tool_ctx.flatten()
            if isinstance(tool, llm.RawFunctionTool | llm.FunctionTool)
            and tool.info.flags & ToolFlag.IGNORE_ON_ENTER
        ]

    def _take_on_enter_user_metrics(self) -> llm.MetricsReport | None:
        """Claim the unanswered user turn for a speech created inside on_enter."""
        on_enter_data = _OnEnterContextVar.get(None)
        if (
            on_enter_data is None
            or on_enter_data.agent != self._agent
            or on_enter_data.session != self._session
        ):
            return None
        metrics = self._session._unanswered_user_metrics
        self._session._unanswered_user_metrics = None
        return metrics

    @utils.log_exceptions(logger=logger)
    async def _pipeline_reply_task(
        self,
        *,
        speech_handle: SpeechHandle,
        chat_ctx: llm.ChatContext,
        tools: list[llm.Tool | llm.Toolset],
        model_settings: ModelSettings,
        new_message: llm.ChatMessage | None = None,
        instructions: str | Instructions | None = None,
        _previous_user_metrics: llm.MetricsReport | None = None,
    ) -> None:
        with _agent_turn(
            speech_handle,
            root_context=self._session._root_span_context,
            agent_label=self._agent.label,
        ):
            await self._pipeline_reply_task_impl(
                speech_handle=speech_handle,
                chat_ctx=chat_ctx,
                tools=tools,
                model_settings=model_settings,
                new_message=new_message,
                instructions=instructions,
                _previous_user_metrics=_previous_user_metrics,
            )

    async def _pipeline_reply_task_impl(
        self,
        *,
        speech_handle: SpeechHandle,
        chat_ctx: llm.ChatContext,
        tools: list[llm.Tool | llm.Toolset],
        model_settings: ModelSettings,
        new_message: llm.ChatMessage | None = None,
        instructions: str | Instructions | None = None,
        _previous_user_metrics: llm.MetricsReport | None = None,
    ) -> None:
        from .agent import ModelSettings

        current_span = trace.get_current_span(context=speech_handle._agent_turn_context)
        current_span.set_attribute(trace_types.ATTR_SPEECH_ID, speech_handle.id)
        if instructions is not None:
            turn_modality = speech_handle.input_details.modality
            instr_trace = (
                instructions.render(modality=turn_modality)
                if isinstance(instructions, Instructions)
                else instructions
            )
            current_span.set_attribute(trace_types.ATTR_INSTRUCTIONS, instr_trace)
        if new_message:
            current_span.set_attribute(
                trace_types.ATTR_USER_INPUT, new_message.raw_text_content or ""
            )

        if (room_io := self._session._room_io) and room_io.room.isconnected():
            _set_participant_attributes(current_span, room_io.room.local_participant)

        audio_output = self._session.output.audio if self._session.output.audio_enabled else None
        text_output = (
            self._session.output.transcription
            if self._session.output.transcription_enabled
            else None
        )
        chat_ctx = chat_ctx.copy()
        tool_ctx = llm.ToolContext(tools)
        tool_ctx._exclude(self._on_enter_ignored_tools(tool_ctx))

        if new_message is not None:
            chat_ctx.insert(new_message)

        # resolve modality-specific instructions for this turn
        turn_modality = speech_handle.input_details.modality
        if instructions is not None:
            instr_text = (
                instructions.render(modality=turn_modality)
                if isinstance(instructions, Instructions)
                else instructions
            )
            chat_ctx.add_message(role="system", content=[instr_text])
        elif isinstance(self._agent.instructions, Instructions):
            update_instructions(
                chat_ctx,
                instructions=self._agent.instructions,
                modality=turn_modality,
                add_if_missing=False,
            )

        # the instructions are the prefix every call shares; a breakpoint there lets the
        # provider cache them even when a per-turn or expressive system message follows
        mark_instructions_cache_boundary(chat_ctx)

        # inject expressive instructions (TTS markup guide + speaker context)
        _expr_opts = self._resolve_expressive_options()
        if _expr_opts is not None:
            self._inject_expressive_instructions(chat_ctx, _expr_opts, speech_handle)
        else:
            # expressive is off for this turn (toggled off via update_options, an agent
            # override, or a handoff to a TTS without a markup dialect): remove the
            # injected markup guide and scrub markup left in past assistant turns so
            # the LLM isn't instructed or few-shotted into emitting tags nothing
            # downstream converts or strips — an unsupported tag would reach the TTS
            # as literal text and be spoken.
            remove_expressive_instructions(chat_ctx)
            _strip_assistant_markup(chat_ctx)
            if chat_ctx is not self._agent._chat_ctx:
                # user turns run on a copy of the agent's history; clean the stored
                # history too so stale markup doesn't survive into future snapshots
                remove_expressive_instructions(self._agent._chat_ctx)
                _strip_assistant_markup(self._agent._chat_ctx)

        # TODO(theomonnom): since pause is closing STT/LLM/TTS, we have issues for SpeechHandle still in queue  # noqa: E501
        # I should implement a retry mechanism?

        # a tool still running from a previous turn isn't in this turn's ctx, so the model
        # re-issues it and duplicates side effects. inject an in-progress placeholder so it
        # leaves the call alone. mutating chat_ctx directly (not a copy) keeps a custom
        # llm_node's edits; the placeholder is stripped again before chat_ctx is forwarded.
        _inject_running_tool_calls(
            chat_ctx,
            [task.ctx.function_call for task in _RunningTasks.get(self._session, {}).values()],
        )

        tasks: list[asyncio.Task[Any]] = []
        # the spans of this generation record their input against the last committed one
        delta_scope = (
            self._input_delta.begin()
            if self._session.options.recording_options.get("input_delta")
            else None
        )
        input_token = input_delta.set_scope(delta_scope)
        try:
            llm_task, llm_gen_data = perform_llm_inference(
                node=self._agent.llm_node,
                chat_ctx=chat_ctx,
                tool_ctx=tool_ctx,
                model_settings=model_settings,
                model=self.llm.model if self.llm else None,
                provider=self.llm.provider if self.llm else None,
            )
        finally:
            input_delta.reset_scope(input_token)
        tasks.append(llm_task)

        def _on_llm_task_done(task: asyncio.Task[bool]) -> None:
            # Surface a genuine LLM failure (not interruption/cancellation) so it
            # propagates through SpeechHandle.exception() and RunResult (i.e.
            # session.run()); this also retrieves the task exception (no "never
            # retrieved" warning).
            if task.cancelled():
                return
            if (exc := task.exception()) is not None:
                speech_handle._error = exc

        llm_task.add_done_callback(_on_llm_task_done)

        # split the LLM text on FlushSentinel into segments, each spoken independently;
        # without a FlushSentinel there is a single (continuous) segment
        @dataclass
        class _SpeechSegment:
            text: utils.aio.Chan[str]  # spoken text for this segment
            tts: _TTSGenerationData | None = None  # audio + timed transcript, when enabled

        segment_ch = utils.aio.Chan[_SpeechSegment]()

        @utils.log_exceptions(logger=logger)
        async def _produce_segments() -> None:
            await llm_gen_data.started_fut  # keep the tts span under the llm span
            current: _SpeechSegment | None = None
            tts_text: utils.aio.Chan[str] | None = None
            prev_tts_task: asyncio.Task[bool] | None = None

            def _on_tts_done(task: asyncio.Task[bool]) -> None:
                # nothing generated past a failed TTS can be spoken, so stop the LLM there
                if not task.cancelled() and task.exception() is not None:
                    llm_task.cancel()

            async def _start_segment() -> _SpeechSegment:
                # start this segment's tts; one inference at a time (await the previous),
                # but the next starts during the previous segment's playout, not after
                nonlocal tts_text, prev_tts_task
                tts_data: _TTSGenerationData | None = None
                tts_text = None
                if audio_output is not None:
                    if prev_tts_task is not None:
                        await prev_tts_task
                    tts_text = utils.aio.Chan[str]()
                    prev_tts_task, tts_data = perform_tts_inference(
                        node=self._agent.tts_node,
                        input=tts_text,
                        model_settings=model_settings,
                        text_transforms=self._session.options.tts_text_transforms,
                        model=self.tts.model if self.tts else None,
                        provider=self.tts.provider if self.tts else None,
                    )
                    tasks.append(prev_tts_task)
                    prev_tts_task.add_done_callback(_on_tts_done)
                seg = _SpeechSegment(text=utils.aio.Chan[str](), tts=tts_data)
                segment_ch.send_nowait(seg)
                return seg

            def _end_segment() -> None:
                nonlocal current, tts_text
                if current is not None:
                    current.text.close()
                if tts_text is not None:
                    tts_text.close()  # let this segment's TTS inference finish
                current, tts_text = None, None

            try:
                async for chunk in llm_gen_data.text_ch:
                    if isinstance(chunk, FlushSentinel):
                        _end_segment()
                        continue
                    text = chunk
                    if not text:
                        continue
                    if current is None:
                        current = await _start_segment()
                    current.text.send_nowait(text)
                    if tts_text is not None:
                        tts_text.send_nowait(text)
            finally:
                _end_segment()
                segment_ch.close()

        # start synthesis preemptively (before the speech is scheduled) when enabled;
        # otherwise it starts right after scheduling below
        preemptive_opts = self.preemptive_generation_opts
        synthesize_task: asyncio.Task[None] | None = None
        if (
            audio_output is not None
            and preemptive_opts["enabled"]
            and preemptive_opts["preemptive_tts"]
        ):
            synthesize_task = asyncio.create_task(
                _produce_segments(), name="AgentActivity.pipeline_reply.produce_segments"
            )
            tasks.append(synthesize_task)

        wait_for_scheduled = asyncio.ensure_future(speech_handle._wait_for_scheduled())
        await speech_handle.wait_if_not_interrupted([wait_for_scheduled])

        # a scheduled generation is the one the conversation continues from (a discarded
        # preemptive generation never gets here)
        if delta_scope is not None and speech_handle.scheduled:
            delta_scope.commit()

        # add new message to chat context if the speech is scheduled

        user_metrics: llm.MetricsReport | None = _previous_user_metrics
        if new_message is not None and speech_handle.scheduled:
            self._agent._chat_ctx.insert(new_message)
            self._session._conversation_item_added(new_message)
            user_metrics = new_message.metrics
            self._session._unanswered_user_metrics = user_metrics

        if speech_handle.interrupted:
            current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, True)
            _record_interruption(speech_handle)
            await utils.aio.cancel_and_wait(*tasks, wait_for_scheduled)
            return

        # start synthesis now if it wasn't started preemptively
        if synthesize_task is None:
            synthesize_task = asyncio.create_task(
                _produce_segments(), name="AgentActivity.pipeline_reply.produce_segments"
            )
            tasks.append(synthesize_task)

        self._session._update_agent_state("thinking")

        authorization_tasks: list[asyncio.Future[Any]] = [
            asyncio.ensure_future(speech_handle._wait_for_authorization()),
            asyncio.ensure_future(self._authorization_allowed.wait()),
        ]
        if speech_handle.allow_interruptions:
            authorization_tasks.append(asyncio.ensure_future(self._user_silence_event.wait()))
        await speech_handle.wait_if_not_interrupted(authorization_tasks)
        speech_handle._clear_authorization()
        _record_queue_wait(speech_handle)

        if speech_handle.interrupted:
            current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, True)
            _record_interruption(speech_handle)
            await utils.aio.cancel_and_wait(*tasks, *authorization_tasks)
            return

        reply_started_at = time.time()

        # In expressive mode the LLM emits markup the TTS interprets as audio directives.
        # The raw text (markup intact) flows into chat history and the tts_node; the
        # transcript sinks strip it from the room transcript downstream and surface the
        # leading expression as the lk.expression attribute (see TranscriptMarkupStripper).
        started_speaking_at: float | None = None
        stopped_speaking_at: float | None = None
        started_forwarding_at: float | None = None
        first_tts_gen_data: _TTSGenerationData | None = None  # first segment's tts, for metrics

        def _on_first_frame(
            fut: asyncio.Future[float] | asyncio.Future[None],
            audio_out: _AudioOutput | None = None,
        ) -> None:
            """
            Callback to update the agent state when the first frame is captured:
            1. _AudioOutput.first_frame_fut (float)
            2. _TextOutput.first_text_fut (None)
            """
            nonlocal started_speaking_at, started_forwarding_at
            # only the first segment's first frame should trigger state transitions
            if started_speaking_at is not None:
                return
            try:
                started_speaking_at = fut.result() or time.time()
                started_forwarding_at = (
                    audio_out.started_forwarding_at
                    if audio_out and audio_out.started_forwarding_at is not None
                    else started_speaking_at
                )
            except BaseException:
                return

            # purely used for realtime console rendering (metrics are shown
            # as soon as the agent starts speaking, before playout finishes)
            early_metrics: llm.MetricsReport = {}
            if llm_gen_data.ttft is not None:
                early_metrics["llm_node_ttft"] = llm_gen_data.ttft
            if first_tts_gen_data and first_tts_gen_data.ttfb is not None:
                early_metrics["tts_node_ttfb"] = first_tts_gen_data.ttfb
            early_metrics["playback_latency"] = started_speaking_at - started_forwarding_at
            if user_metrics and "stopped_speaking_at" in user_metrics:
                early_metrics["e2e_latency"] = (
                    started_speaking_at - user_metrics["stopped_speaking_at"]
                )
            self._session._early_assistant_metrics = early_metrics

            self._session._update_agent_state(
                "speaking",
                start_time=started_speaking_at,
                otel_context=speech_handle._agent_turn_context,
            )

            if self._audio_recognition:
                self._audio_recognition._on_start_of_agent_speech(started_at=started_speaking_at)
            if self.interruption_enabled:
                self._disable_vad_interruption_soon()

        started_calls: list[llm.FunctionCall] = []

        # messages in RunResult are ordered by the `created_at` field
        def _tool_execution_started_cb(fnc_call: llm.FunctionCall) -> None:
            # function call is created during LLM generation, might be before the speech is authorized
            # reset the `created_at` to the start time of the tool execution
            fnc_call.created_at = time.time()
            started_calls.append(fnc_call)
            speech_handle._item_added([fnc_call])

        def _tool_execution_completed_cb(out: ToolExecutionOutput) -> None:
            speech_handle._item_added([out.fnc_call_out])

        # start to execute tools (only after play())
        exe_task, tool_output = perform_tool_executions(
            session=self._session,
            speech_handle=speech_handle,
            tool_ctx=tool_ctx,
            tool_choice=model_settings.tool_choice,
            function_stream=llm_gen_data.function_ch,
            tool_execution_started_cb=_tool_execution_started_cb,
            tool_execution_completed_cb=_tool_execution_completed_cb,
        )

        # use the TTS-aligned timing for the transcript instead of the raw text, when
        # the TTS supports it (resolved per segment below)
        use_aligned_transcript = bool(
            audio_output is not None
            and self.use_tts_aligned_transcript
            and (tts := self.tts)
            and (tts.capabilities.aligned_transcript or not tts.capabilities.streaming)
        )

        # forward each segment serially: its audio must finish playing before the next
        # one starts (matches the realtime per-message behavior)
        segment_outputs: list[_ForwardOutput] = []
        read_transcript_from_tts = False

        async def _next_segment() -> _SpeechSegment | None:
            # wake promptly on interruption so a slow LLM (no segment produced yet)
            # doesn't delay teardown
            recv = asyncio.ensure_future(segment_ch.recv())
            await speech_handle.wait_if_not_interrupted([recv])
            if speech_handle.interrupted:
                await utils.aio.cancel_and_wait(recv)
                return None
            try:
                return recv.result()
            except utils.aio.ChanClosed:
                return None

        while (segment := await _next_segment()) is not None:
            if first_tts_gen_data is None:
                first_tts_gen_data = segment.tts

            transcript: AsyncIterable[str] = segment.text
            if (
                segment.tts is not None
                and use_aligned_transcript
                and (timed_texts := await segment.tts.timed_texts_fut)
            ):
                # the channel exists as soon as the node streams, before any timed
                # word has arrived, so a TTS that advertises alignment it doesn't
                # deliver would leave the segment with no transcript at all
                transcript = _aligned_transcript_or_text(timed_texts, segment.text)
                read_transcript_from_tts = True

            tr_node = self._agent.transcription_node(transcript, model_settings)
            text_source = await tr_node if asyncio.iscoroutine(tr_node) else tr_node
            audio_source = segment.tts.audio_ch if segment.tts else None

            out = await forward_generation(
                speech_handle=speech_handle,
                audio_output=audio_output,
                text_output=text_output,
                audio_source=audio_source,
                text_source=text_source,
                on_first_frame=_on_first_frame,
                reconcile_playout_pause=lambda: self._reconcile_playout_pause(speech_handle),
                tts_data=segment.tts,
            )
            segment_outputs.append(out)
            if speech_handle.interrupted:
                break

        stopped_speaking_at = time.time()
        assistant_metrics: llm.MetricsReport = {}

        if self.llm:
            assistant_metrics["llm_metadata"] = self.llm.metrics_metadata
        if self.tts:
            assistant_metrics["tts_metadata"] = self.tts.metrics_metadata

        if llm_gen_data.ttft is not None:
            assistant_metrics["llm_node_ttft"] = llm_gen_data.ttft

        if llm_gen_data.tps is not None:
            assistant_metrics["llm_node_tps"] = llm_gen_data.tps

        if (ttfs := _time_to_first_sentence(llm_gen_data, first_tts_gen_data)) is not None:
            assistant_metrics["llm_node_ttfs"] = ttfs

        if first_tts_gen_data and first_tts_gen_data.ttfb is not None:
            assistant_metrics["tts_node_ttfb"] = first_tts_gen_data.ttfb

        if stopped_speaking_at and started_speaking_at:
            assistant_metrics["started_speaking_at"] = started_speaking_at
            assistant_metrics["stopped_speaking_at"] = stopped_speaking_at

            if started_forwarding_at is not None:
                assistant_metrics["playback_latency"] = started_speaking_at - started_forwarding_at

            if user_metrics and "stopped_speaking_at" in user_metrics:
                e2e_latency = started_speaking_at - user_metrics["stopped_speaking_at"]
                assistant_metrics["e2e_latency"] = e2e_latency
                current_span.set_attribute(trace_types.ATTR_E2E_LATENCY, e2e_latency)
                _record_user_turn_stages(current_span, user_metrics)

            if self._session._unanswered_user_metrics is user_metrics:
                self._session._unanswered_user_metrics = None

        current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, speech_handle.interrupted)
        _record_interruption(speech_handle)
        if speech_handle.interrupted and segment_outputs:
            current_span.set_attribute(
                trace_types.ATTR_PLAYOUT_POSITION,
                sum(out.playback_position for out in segment_outputs),
            )

        forwarded_text = "".join(out.forwarded_text for out in segment_outputs)
        if speech_handle.interrupted:
            # forward_generation already cleared the buffer and waited for playout
            await utils.aio.cancel_and_wait(*tasks)
        elif read_transcript_from_tts and any(
            out.played != "skipped" and out.text_out is not None and not out.text_out.text
            for out in segment_outputs
        ):
            logger.warning(
                "`use_tts_aligned_transcript` is enabled but no agent transcript was returned from tts"
            )

        if forwarded_text:
            # forwarded_text carries the raw LLM output including any expressive markup
            # (the transcript forwarder strips it only for the room transcript), so the
            # markup lives directly on the stored assistant message.
            extra_kwargs: dict = {}
            if llm_gen_data.generated_extra:
                extra_kwargs["extra"] = llm_gen_data.generated_extra
            msg = chat_ctx.add_message(
                role="assistant",
                content=forwarded_text,
                id=llm_gen_data.id,
                # a reply cut short by a failed TTS reads as interrupted to the LLM
                interrupted=speech_handle.interrupted
                or any(out.tts_failed for out in segment_outputs),
                created_at=reply_started_at,
                metrics=assistant_metrics,
                **extra_kwargs,
            )
            self._agent._chat_ctx.insert(msg)
            self._session._conversation_item_added(msg)
            speech_handle._item_added([msg])
            current_span.set_attribute(trace_types.ATTR_RESPONSE_TEXT, forwarded_text)

        if not speech_handle.interrupted and len(tool_output.output) > 0:
            self._session._update_agent_state("thinking")
            self._on_end_of_agent_speech(ended_at=time.time())
            if self.interruption_enabled:
                self.interruption_by_audio_activity_enabled = True
        elif self._session.agent_state == "speaking":
            # a running tool keeps the agent busy; "listening" would arm the away timer
            tool_running = not speech_handle.interrupted and not exe_task.done()
            self._session._update_agent_state("thinking" if tool_running else "listening")
            self._on_end_of_agent_speech(ended_at=time.time())
            if self.interruption_enabled:
                self.interruption_by_audio_activity_enabled = True

        for out in segment_outputs:
            if out.audio_out is not None and not out.audio_out.first_frame_fut.done():
                out.audio_out.first_frame_fut.cancel()

        speech_handle._mark_generation_done()  # mark the playout done before waiting for the tool execution  # noqa: E501

        if speech_handle.interrupted:
            timeout_cancel: asyncio.CancelledError | None = None
            try:
                await utils.aio.cancel_and_wait(exe_task)
            except asyncio.CancelledError as e:
                # the interruption timeout stopped waiting for the tools: release them as an
                # async tool's first update does, and commit that update below
                timeout_cancel = e
                await _release_running_tools(self._session, started_calls, speech_handle)
                await asyncio.wait([exe_task])

            # commit results of tools that finished despite the interruption (#3702), so
            # the next inference doesn't run them again
            interrupted_calls: list[llm.FunctionCall] = []
            interrupted_fnc_outputs: list[llm.FunctionCallOutput] = []
            for sanitized_out in tool_output.output:
                interrupted_calls.append(sanitized_out.fnc_call)
                interrupted_fnc_outputs.append(_interrupted_tool_output(sanitized_out))

            if interrupted_tool_messages := interrupted_calls + interrupted_fnc_outputs:
                self._session.emit(
                    "function_tools_executed",
                    FunctionToolsExecutedEvent(
                        function_calls=interrupted_calls,
                        function_call_outputs=interrupted_fnc_outputs,
                    ),
                )
                self._agent._chat_ctx.insert(interrupted_tool_messages)
                self._session._tool_items_added(interrupted_tool_messages)
            if timeout_cancel is not None:
                raise timeout_cancel
            return

        # wait for the tool execution to complete
        self._background_speeches.add(speech_handle)
        try:
            await exe_task
        finally:
            self._background_speeches.discard(speech_handle)

        # important: no agent output should be used after this point

        # the reply chain goes on through a tool reply, a handoff, or an inline task handing
        # back to the tool that awaited it; otherwise it ends here and nothing answers the turn
        chain_continues = False
        if len(tool_output.output) > 0:
            max_steps_reached = speech_handle.num_steps >= self._session.options.max_tool_steps + 1

            if max_steps_reached:
                logger.warning(
                    "maximum number of function calls steps reached, "
                    "generating final response with tool_choice='none'",
                    extra={"speech_id": speech_handle.id},
                )

            speech_handle._num_steps += 1

            new_calls: list[llm.FunctionCall] = []
            new_fnc_outputs: list[llm.FunctionCallOutput] = []
            new_agent_task: Agent | None = None
            ignore_task_switch = False
            fnc_executed_ev = FunctionToolsExecutedEvent(
                function_calls=[], function_call_outputs=[]
            )
            for sanitized_out in tool_output.output:
                new_calls.append(sanitized_out.fnc_call)
                new_fnc_outputs.append(sanitized_out.fnc_call_out)

                fnc_executed_ev.function_calls.append(sanitized_out.fnc_call)
                fnc_executed_ev.function_call_outputs.append(sanitized_out.fnc_call_out)

                if new_agent_task is not None and sanitized_out.agent_task is not None:
                    logger.error("expected to receive only one AgentTask from the tool executions")
                    ignore_task_switch = True
                    # TODO(long): should we mark the function call as failed to notify the LLM?

                if sanitized_out.agent_task is not None:
                    new_agent_task = sanitized_out.agent_task

            if new_agent_task and not ignore_task_switch:
                fnc_executed_ev._handoff_required = True

            self._session.emit("function_tools_executed", fnc_executed_ev)

            draining = self.scheduling_paused
            if fnc_executed_ev._handoff_required and new_agent_task and not ignore_task_switch:
                self._session.update_agent(new_agent_task)
                draining = True

            chain_continues = (
                fnc_executed_ev.has_tool_reply
                or self._session._agent is not self._agent
                or (isinstance(self._agent, AgentTask) and self._agent.done())
            )

            tool_messages = new_calls + new_fnc_outputs
            # commit now so results survive even if the reply speech never runs (#3702)
            if tool_messages:
                self._agent._chat_ctx.insert(tool_messages)
                self._session._tool_items_added(tool_messages)

            if fnc_executed_ev.has_tool_reply and not speech_handle.interrupted:
                # forwarding chat_ctx to the tool reply: drop the in-progress placeholders
                # (the next turn re-injects from the live running set)
                _strip_running_tool_calls(chat_ctx)

                # refresh conversation items added during tool execution: a tool that
                # awaits an inline AgentTask runs a whole sub-conversation, merged into
                # the agent's chat_ctx at handoff-return - this turn's snapshot predates
                # it. Without the refresh, the tool response is generated blind to what
                # was actually said inside the tool call (and re-asks captured fields).
                # Conversational analog of the update_instructions() refresh below.
                # tool_messages must be added first so merge() dedups them by id.
                chat_ctx.items.extend(tool_messages)
                chat_ctx.merge(self._agent._chat_ctx, exclude_instructions=True)

                # refresh instructions in chat_ctx so that any update_instructions()
                # calls made inside tool functions are reflected in the tool response
                # generation (fixes #4242)
                update_instructions(
                    chat_ctx,
                    instructions=self._agent._instructions,
                    modality=speech_handle.input_details.modality,
                    add_if_missing=False,
                )

                tool_response_task = self._create_speech_task(
                    self._pipeline_reply_task(
                        speech_handle=speech_handle,
                        chat_ctx=chat_ctx,
                        tools=tools,
                        model_settings=ModelSettings(
                            # Avoid setting tool_choice to "required" or a specific function when
                            # passing tool response back to the LLM.
                            # Force tool_choice="none" when max steps reached to guarantee
                            # a final text response instead of silently stopping.
                            tool_choice="none"
                            if max_steps_reached or draining or model_settings.tool_choice == "none"
                            else _reply_tool_choice(
                                out.reply_tool_choice
                                for out in tool_output.output
                                if out.fnc_call_out.reply_required
                            )
                            or "auto",
                        ),
                        # the tool reply answers whatever user turn is still unanswered: this
                        # one if the reply only generated tools, or the last turn of a
                        # sub-conversation an inline AgentTask ran inside the tool
                        _previous_user_metrics=self._session._unanswered_user_metrics,
                    ),
                    speech_handle=speech_handle,
                    name="AgentActivity.pipeline_reply",
                )
                tool_response_task.add_done_callback(self._on_pipeline_reply_done)
                self._schedule_speech(
                    speech_handle, SpeechHandle.SPEECH_PRIORITY_NORMAL, force=True
                )

        if not chain_continues:
            self._session._unanswered_user_metrics = None

    @utils.log_exceptions(logger=logger)
    async def _realtime_reply_task(
        self,
        *,
        speech_handle: SpeechHandle,
        model_settings: ModelSettings,
        tools: list[llm.Tool | llm.Toolset] | None = None,
        user_input: str | None = None,
        instructions: str | None = None,
        tool_reply: bool = False,
        text: str | AsyncIterable[str] | None = None,
    ) -> None:
        assert self._rt_session is not None, "rt_session is not available"
        # realtime_reply_task is called only when there's text input, native audio input is handled by _realtime_generation_task
        authorization_tasks: list[asyncio.Future[Any]] = [
            asyncio.ensure_future(speech_handle._wait_for_authorization()),
            asyncio.ensure_future(self._authorization_allowed.wait()),
        ]
        if speech_handle.allow_interruptions and not self._rt_overlapping_speech_enabled:
            authorization_tasks.append(asyncio.ensure_future(self._user_silence_event.wait()))
        await speech_handle.wait_if_not_interrupted(authorization_tasks)
        # the queue wait is recorded by _realtime_generation_task, which owns the agent_turn span
        if speech_handle.interrupted:
            await utils.aio.cancel_and_wait(*authorization_tasks)
            return

        if text is not None:
            try:
                generation_ev = await self._rt_session.say(text)
            except llm.RealtimeError as e:
                logger.error("failed to say text: %s", str(e))
                speech_handle._mark_done(error=e)
                return

            await self._realtime_generation_task(
                speech_handle=speech_handle,
                generation_ev=generation_ev,
                model_settings=model_settings,
            )
            return

        if user_input is not None:
            try:
                async with self._rt_chat_ctx_lock:
                    chat_ctx = self._rt_session.chat_ctx.copy()
                    msg = chat_ctx.add_message(role="user", content=user_input)
                    await self._rt_session.update_chat_ctx(chat_ctx)
            except llm.RealtimeError as e:
                # the push is best-effort (the items were sent; only the ack timed out),
                # so still generate the reply rather than dropping the whole turn
                logger.warning(
                    "failed to update the chat context before generating the reply",
                    extra={"error": str(e)},
                )
            except Exception as e:
                logger.exception("failed to update the chat context before generating the reply")
                speech_handle._mark_done(error=e)
                return
            self._agent._chat_ctx._upsert_item(msg)
            self._session._conversation_item_added(msg)

        # inside on_enter, hide flagged tools even when no tools= was passed (fall back to self.tools)
        turn_tools: NotGivenOr[list[llm.Tool]] = NOT_GIVEN
        tool_ctx = llm.ToolContext(tools if tools is not None else self.tools)
        on_enter_ignored = self._on_enter_ignored_tools(tool_ctx)
        if tools is not None or on_enter_ignored:
            tool_ctx._exclude(on_enter_ignored)
            turn_tools = tool_ctx.flatten()

        ori_tools: NotGivenOr[list[llm.Tool]] = NOT_GIVEN
        try:
            if not (
                per_response_tool_choice
                := self._rt_session.realtime_model.capabilities.per_response_tool_choice
            ):
                # update the tool and tool choice at the session level if they are specified
                if (
                    is_given(model_settings.tool_choice)
                    and model_settings.tool_choice != self._tool_choice
                ):
                    self._rt_tool_choice_overridden = True
                    self._rt_session.update_options(tool_choice=model_settings.tool_choice)

                if is_given(turn_tools):
                    ori_tools = self._rt_session.tools.flatten()
                    await self._rt_session.update_tools(turn_tools)

            if speech_handle.input_details.modality == "text":
                self._realtime_user_input_answered_at = time.time()
                self._session._unanswered_user_metrics = None
            generate_reply_fut = self._rt_session.generate_reply(
                instructions=instructions or NOT_GIVEN,
                tool_choice=(model_settings.tool_choice if per_response_tool_choice else NOT_GIVEN),
                tools=(turn_tools if per_response_tool_choice else NOT_GIVEN),
            )
            await speech_handle.wait_if_not_interrupted([generate_reply_fut])
            if speech_handle.interrupted:
                # cancel the pending generation; the plugin emits response.cancel
                if not generate_reply_fut.done():
                    generate_reply_fut.cancel()
                else:
                    # the response already landed, cancelling the future no longer reaches it
                    self._rt_session.interrupt()
                return

            try:
                generation_ev = await generate_reply_fut
            except llm.RealtimeError as e:
                logger.error(
                    "failed to generate a reply%s: %s",
                    " after tool execution" if tool_reply else "",
                    str(e),
                )
                speech_handle._mark_done(error=e)
                self._session._update_agent_state("listening")
                return

            # _realtime_generation_task will clear the authorization
            await self._realtime_generation_task(
                speech_handle=speech_handle,
                generation_ev=generation_ev,
                model_settings=model_settings,
                instructions=instructions,
            )
        finally:
            # reset tool_choice and tools
            self._restore_rt_tool_choice()

            if is_given(ori_tools):
                try:
                    await self._rt_session.update_tools(ori_tools)
                except Exception:
                    logger.exception("failed to reset tools")

    def _restore_rt_tool_choice(self) -> None:
        """Put the activity's tool_choice back on the realtime session after an ask overrode it."""
        if not self._rt_tool_choice_overridden or self._rt_session is None:
            return
        self._rt_tool_choice_overridden = False
        try:
            self._rt_session.update_options(tool_choice=self._tool_choice)
        except Exception:
            logger.exception("failed to reset tool_choice")

    @utils.log_exceptions(logger=logger)
    async def _realtime_generation_task(
        self,
        *,
        speech_handle: SpeechHandle,
        generation_ev: llm.GenerationCreatedEvent,
        model_settings: ModelSettings,
        instructions: str | None = None,
    ) -> None:
        with _agent_turn(
            speech_handle,
            root_context=self._session._root_span_context,
            agent_label=self._agent.label,
        ):
            inference_span = tracer.start_span("realtime_inference")
            try:
                await self._realtime_generation_task_impl(
                    speech_handle=speech_handle,
                    generation_ev=generation_ev,
                    model_settings=model_settings,
                    instructions=instructions,
                    inference_span=inference_span,
                )
            finally:
                inference_span.end()

    async def _realtime_generation_task_impl(
        self,
        *,
        speech_handle: SpeechHandle,
        generation_ev: llm.GenerationCreatedEvent,
        model_settings: ModelSettings,
        instructions: str | None = None,
        inference_span: trace.Span,
    ) -> None:
        current_span = trace.get_current_span(context=speech_handle._agent_turn_context)
        current_span.set_attribute(trace_types.ATTR_SPEECH_ID, speech_handle.id)

        room_io = self._session._room_io
        if room_io and room_io.room.isconnected():
            _set_participant_attributes(current_span, room_io.room.local_participant)

        assert self._rt_session is not None, "rt_session is not available"
        assert isinstance(self.llm, llm.RealtimeModel), "llm is not a realtime model"

        audio_output = self._session.output.audio if self._session.output.audio_enabled else None
        text_output = (
            self._session.output.transcription
            if self._session.output.transcription_enabled
            else None
        )

        gen_ai_telemetry.set_request_attributes(
            inference_span,
            operation=trace_types.GenAIOperationName.GENERATE_CONTENT,
            provider=self.llm.provider,
            model=self.llm.model,
            stream=True,
            # a realtime model can be configured text-only
            output_type=(
                trace_types.GenAIOutputType.SPEECH
                if audio_output is not None
                else trace_types.GenAIOutputType.TEXT
            ),
        )
        # the provider metrics land here rather than on `agent_turn`; they can arrive after
        # the turn ends, in which case record_realtime_metrics opens its own child span
        if self._realtime_spans is not None and generation_ev.response_id:
            self._realtime_spans[generation_ev.response_id] = inference_span
        tool_ctx = llm.ToolContext(self.tools)

        tasks: list[asyncio.Task[Any]] = []
        tees: list[utils.aio.itertools.Tee[Any]] = []

        msg_tee = utils.aio.itertools.tee(generation_ev.message_stream, 2)
        msg_stream, msg_stream_to_drain = msg_tee
        tees.append(msg_tee)

        fnc_tee = utils.aio.itertools.tee(generation_ev.function_stream, 2)
        fnc_stream, fnc_stream_for_tracing = fnc_tee
        tees.append(fnc_tee)

        function_calls: list[llm.FunctionCall] = []
        generation_ended = False

        async def _read_fnc_stream() -> None:
            async for fnc in fnc_stream_for_tracing:
                function_calls.append(fnc)

        async def _drain_msg_stream() -> None:
            async for _ in msg_stream_to_drain:
                pass

        async def _watch_generation_end() -> None:
            # the provider closes both streams when it ends the response
            nonlocal generation_ended
            await asyncio.gather(_drain_msg_stream(), _read_fnc_stream())
            generation_ended = True

        tasks.append(
            asyncio.create_task(
                _watch_generation_end(),
                name="AgentActivity.realtime_generation.watch_end",
            )
        )

        authorization_tasks: list[asyncio.Future[Any]] = [
            asyncio.ensure_future(speech_handle._wait_for_authorization()),
            asyncio.ensure_future(self._authorization_allowed.wait()),
        ]
        if speech_handle.allow_interruptions and not self._rt_overlapping_speech_enabled:
            authorization_tasks.append(asyncio.ensure_future(self._user_silence_event.wait()))
        await speech_handle.wait_if_not_interrupted(authorization_tasks)
        speech_handle._clear_authorization()
        _record_queue_wait(speech_handle)

        if speech_handle.interrupted:
            # nothing was played, but the response may still be generating server-side
            if not generation_ended:
                self._rt_session.interrupt()
            await utils.aio.cancel_and_wait(*authorization_tasks, *tasks)
            for tee in tees:
                await tee.aclose()
            current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, True)
            _record_interruption(speech_handle)
            return  # TODO(theomonnom): remove the message from the serverside history

        started_speaking_at: float | None = None
        stopped_speaking_at: float | None = None
        started_forwarding_at: float | None = None
        e2e_latency: float | None = None
        first_played_message_id: str | None = None

        def _on_first_frame(
            fut: asyncio.Future[float] | asyncio.Future[None], audio_out: _AudioOutput | None = None
        ) -> None:
            """
            Callback to update the agent state when the first frame is captured:
            1. _AudioOutput.first_frame_fut (float)
            2. _TextOutput.first_text_fut (None)
            """
            nonlocal started_speaking_at, started_forwarding_at, e2e_latency
            # only the first message's first frame should trigger state transitions
            if started_speaking_at is not None:
                return
            try:
                started_speaking_at = fut.result() or time.time()
                started_forwarding_at = (
                    audio_out.started_forwarding_at
                    if audio_out and audio_out.started_forwarding_at is not None
                    else started_speaking_at
                )
            except BaseException:
                return

            if speech_handle.input_details.modality == "audio":
                last_speaking_time = self._last_user_speaking_time
                if (
                    last_speaking_time is not None
                    and last_speaking_time > self._realtime_user_input_answered_at
                    and last_speaking_time <= started_speaking_at
                ):
                    e2e_latency = started_speaking_at - last_speaking_time
                    current_span.set_attribute(trace_types.ATTR_E2E_LATENCY, e2e_latency)
                # A late VAD EOS must not make the same speech eligible for another reply.
                self._realtime_user_input_answered_at = max(
                    self._realtime_user_input_answered_at, started_speaking_at
                )
                self._session._unanswered_user_metrics = None

            early_metrics: llm.MetricsReport = {
                "playback_latency": started_speaking_at - started_forwarding_at
            }
            if e2e_latency is not None:
                early_metrics["e2e_latency"] = e2e_latency
            self._session._early_assistant_metrics = early_metrics

            self._session._update_agent_state(
                "speaking",
                start_time=started_speaking_at,
                otel_context=speech_handle._agent_turn_context,
            )
            if self._audio_recognition:
                self._audio_recognition._on_start_of_agent_speech(started_at=started_speaking_at)
            if self.interruption_enabled:
                self._disable_vad_interruption_soon()

        read_transcript_from_tts = False

        # multiple message items may be produced for a single realtime response
        # (e.g. GPT-Realtime-2.0). We process each one serially: push frames,
        # flush, wait_for_playout
        @dataclass
        class _MsgOutput:
            msg: MessageGeneration
            out: _ForwardOutput

        message_outputs: list[_MsgOutput] = []

        async def _process_one_message(msg: MessageGeneration) -> _MsgOutput:
            """Resolve a message's audio/text sources, then forward and wait for playout."""
            nonlocal read_transcript_from_tts
            assert isinstance(self.llm, llm.RealtimeModel)

            msg_modalities = await msg.modalities
            tts_text_input: AsyncIterable[str] | None = None
            if "audio" not in msg_modalities and self.tts:
                if self.llm.capabilities.audio_output:
                    logger.warning(
                        "text response received from realtime API, falling back to use a TTS model."  # noqa: E501
                    )
                tee = utils.aio.itertools.tee(msg.text_stream, 2)
                tts_text_input, tr_text_input = tee
                tees.append(tee)
            else:
                tr_text_input = msg.text_stream.__aiter__()

            audio_source: AsyncIterable[rtc.AudioFrame] | None = None
            if audio_output is not None:
                if tts_text_input is not None:
                    tts_task, tts_gen_data = perform_tts_inference(
                        node=self._agent.tts_node,
                        input=tts_text_input,
                        model_settings=model_settings,
                        text_transforms=self._session.options.tts_text_transforms,
                        model=self.tts.model if self.tts else None,
                        provider=self.tts.provider if self.tts else None,
                    )

                    if (
                        self.use_tts_aligned_transcript
                        and (tts := self.tts)
                        and (tts.capabilities.aligned_transcript or not tts.capabilities.streaming)
                        and (timed_texts := await tts_gen_data.timed_texts_fut)
                    ):
                        tr_text_input = _aligned_transcript_or_text(timed_texts, tr_text_input)
                        read_transcript_from_tts = True

                    tasks.append(tts_task)
                    audio_source = tts_gen_data.audio_ch
                elif "audio" in msg_modalities:
                    realtime_audio = self._agent.realtime_audio_output_node(
                        msg.audio_stream, model_settings
                    )
                    audio_source = (
                        await realtime_audio
                        if asyncio.iscoroutine(realtime_audio)
                        else realtime_audio
                    )
                elif self.llm.capabilities.audio_output:
                    logger.error(
                        "Text message received from Realtime API with audio modality. "
                        "This usually happens when text chat context is synced to the API. "
                        "Try to add a TTS model as fallback or use text modality with TTS instead."  # noqa: E501
                    )
                else:
                    logger.warning(
                        "audio output is enabled but neither tts nor realtime audio is available",
                    )

            tr_node = self._agent.transcription_node(tr_text_input, model_settings)
            text_source = await tr_node if asyncio.iscoroutine(tr_node) else tr_node

            def _on_message_first_frame(
                fut: asyncio.Future[float] | asyncio.Future[None],
                audio_out: _AudioOutput | None = None,
            ) -> None:
                nonlocal first_played_message_id
                _on_first_frame(fut, audio_out)
                if first_played_message_id is None and started_speaking_at is not None:
                    first_played_message_id = msg.message_id

            out = await forward_generation(
                speech_handle=speech_handle,
                audio_output=audio_output,
                text_output=text_output,
                audio_source=audio_source,
                text_source=text_source,
                on_first_frame=_on_message_first_frame,
                reconcile_playout_pause=lambda: self._reconcile_playout_pause(speech_handle),
            )
            return _MsgOutput(msg=msg, out=out)

        @utils.log_exceptions(logger=logger)
        async def _process_messages() -> None:
            async for msg in msg_stream:
                if speech_handle.interrupted:
                    # remaining messages are left out of message_outputs so
                    # update_chat_ctx below removes them server-side.
                    break
                entry = await _process_one_message(msg)
                message_outputs.append(entry)
                if entry.out.played == "partial":
                    break

        process_msg_task = asyncio.create_task(
            _process_messages(), name="AgentActivity.realtime_generation.process_messages"
        )
        tasks.append(process_msg_task)

        started_calls: list[llm.FunctionCall] = []

        # messages in RunResult are ordered by the `created_at` field
        def _tool_execution_started_cb(fnc_call: llm.FunctionCall) -> None:
            # function call is created during the realtime generation, before the assistant
            # message it belongs to is placed at `started_speaking_at`
            # reset the `created_at` to the start time of the tool execution
            fnc_call.created_at = time.time()
            started_calls.append(fnc_call)
            speech_handle._item_added([fnc_call])
            self._agent._chat_ctx._upsert_item(fnc_call)
            self._session._tool_items_added([fnc_call])

        def _tool_execution_completed_cb(out: ToolExecutionOutput) -> None:
            speech_handle._item_added([out.fnc_call_out])

        exe_task, tool_output = perform_tool_executions(
            session=self._session,
            speech_handle=speech_handle,
            tool_ctx=tool_ctx,
            tool_choice=model_settings.tool_choice,
            function_stream=fnc_stream,
            tool_execution_started_cb=_tool_execution_started_cb,
            tool_execution_completed_cb=_tool_execution_completed_cb,
        )

        await speech_handle.wait_if_not_interrupted([*tasks])

        # the cancel is session-wide, so send it only while this response is still generating
        if speech_handle.interrupted and not generation_ended:
            self._rt_session.interrupt()

        current_span.set_attribute(trace_types.ATTR_SPEECH_INTERRUPTED, speech_handle.interrupted)
        _record_interruption(speech_handle)
        current_span.set_attribute(
            trace_types.ATTR_RESPONSE_FUNCTION_CALLS,
            json.dumps([fnc.model_dump(exclude={"type", "created_at"}) for fnc in function_calls]),
        )

        # _process_messages handles its own playout waits and interrupt cleanup
        await process_msg_task

        self._session._update_agent_state("thinking" if self._background_speeches else "listening")
        self._on_end_of_agent_speech(ended_at=time.time())
        if self.interruption_enabled:
            self.interruption_by_audio_activity_enabled = True

        stopped_speaking_at = time.time()

        def _create_assistant_message(
            message_id: str, forwarded_text: str, interrupted: bool
        ) -> llm.ChatMessage:
            assistant_metrics: llm.MetricsReport = {}

            if generation_ev.response_id:
                assistant_metrics["provider_request_ids"] = [generation_ev.response_id]
            if e2e_latency is not None and message_id == first_played_message_id:
                assistant_metrics["e2e_latency"] = e2e_latency

            if stopped_speaking_at and started_speaking_at:
                assistant_metrics["started_speaking_at"] = started_speaking_at
                assistant_metrics["stopped_speaking_at"] = stopped_speaking_at

                if started_forwarding_at is not None:
                    assistant_metrics["playback_latency"] = (
                        started_speaking_at - started_forwarding_at
                    )

            msg = llm.ChatMessage(
                role="assistant",
                content=[forwarded_text],
                id=message_id,
                interrupted=interrupted,
            )
            if started_speaking_at is not None:
                msg.created_at = started_speaking_at
            msg.metrics = assistant_metrics
            return msg

        if (
            not speech_handle.interrupted
            and read_transcript_from_tts
            and any(
                e.out.played != "skipped" and e.out.text_out is not None and not e.out.text_out.text
                for e in message_outputs
            )
        ):
            logger.warning(
                "`use_tts_aligned_transcript` is enabled but no agent transcript was returned from tts"  # noqa: E501
            )

        # create assistant message per generated message
        trace_text_parts: list[str] = []
        any_skipped = False
        for entry in message_outputs:
            if entry.out.played == "skipped":
                any_skipped = True
                continue

            msg_interrupted = entry.out.played == "partial"
            forwarded_text = entry.out.forwarded_text

            if msg_interrupted and self.llm.capabilities.message_truncation:
                msg_modalities = await entry.msg.modalities
                self._rt_session.truncate(
                    message_id=entry.msg.message_id,
                    modalities=msg_modalities,
                    audio_end_ms=int(entry.out.playback_position * 1000),
                    audio_transcript=forwarded_text,
                )

            if not forwarded_text:
                continue

            trace_text_parts.append(forwarded_text)
            chat_msg = _create_assistant_message(
                message_id=entry.msg.message_id,
                forwarded_text=forwarded_text,
                interrupted=msg_interrupted,
            )
            self._agent._chat_ctx._upsert_item(chat_msg)
            speech_handle._item_added([chat_msg])
            self._session._conversation_item_added(chat_msg)

        if trace_text_parts:
            current_span.set_attribute(trace_types.ATTR_RESPONSE_TEXT, "\n".join(trace_text_parts))

        # sync local chat ctx to the realtime server to remove any items the
        # model added but the user never heard (interrupted before we pulled
        # them, or message_outputs entries left in "skipped")
        if speech_handle.interrupted and any_skipped and self.llm.capabilities.mutable_chat_context:
            try:
                async with self._rt_chat_ctx_lock:
                    await self._rt_session.update_chat_ctx(self._agent._chat_ctx)
            except llm.RealtimeError as e:
                logger.warning(
                    "failed to sync chat context to remove never-played messages",
                    extra={"error": str(e)},
                )

        for entry in message_outputs:
            if entry.out.audio_out is not None and not entry.out.audio_out.first_frame_fut.done():
                entry.out.audio_out.first_frame_fut.cancel()

        for tee in tees:
            await tee.aclose()
        speech_handle._mark_generation_done()

        if speech_handle.interrupted:
            timeout_cancel: asyncio.CancelledError | None = None
            try:
                await utils.aio.cancel_and_wait(exe_task)
            except asyncio.CancelledError as e:
                # the interruption timeout stopped waiting for the tools: release them as an
                # async tool's first update does, and commit that update below
                timeout_cancel = e
                await _release_running_tools(self._session, started_calls, speech_handle)
                await asyncio.wait([exe_task])

            # commit results of tools that finished despite the interruption, as the pipeline
            # task does. the calls are already recorded, so each one answers or the model waits
            interrupted_calls: list[llm.FunctionCall] = []
            interrupted_fnc_outputs: list[llm.FunctionCallOutput] = []
            for sanitized_out in tool_output.output:
                interrupted_calls.append(sanitized_out.fnc_call)
                interrupted_fnc_outputs.append(_interrupted_tool_output(sanitized_out))

            if interrupted_fnc_outputs:
                self._session.emit(
                    "function_tools_executed",
                    FunctionToolsExecutedEvent(
                        function_calls=interrupted_calls,
                        function_call_outputs=interrupted_fnc_outputs,
                    ),
                )
                self._agent._chat_ctx.insert(interrupted_fnc_outputs)
                self._session._tool_items_added(interrupted_fnc_outputs)

                # unlike the pipeline, a realtime model holds the call open server-side
                try:
                    async with self._rt_chat_ctx_lock:
                        chat_ctx = self._rt_session.chat_ctx.copy()
                        chat_ctx.items.extend(interrupted_fnc_outputs)
                        await self._rt_session.update_chat_ctx(chat_ctx)
                except llm.RealtimeError as e:
                    logger.warning(
                        "failed to sync the tool results of an interrupted generation",
                        extra={"error": str(e)},
                    )
            if timeout_cancel is not None:
                raise timeout_cancel
            return

        # wait for the tool execution to complete
        tool_output.first_tool_started_fut.add_done_callback(
            lambda _: self._session._update_agent_state("thinking")
        )

        self._background_speeches.add(speech_handle)
        try:
            await exe_task
        finally:
            self._background_speeches.discard(speech_handle)

        # important: no agent output should be used after this point

        tool_reply_expected = False
        if len(tool_output.output) > 0:
            max_steps_reached = speech_handle.num_steps >= self._session.options.max_tool_steps + 1
            speech_handle._num_steps += 1

            new_fnc_outputs: list[llm.FunctionCallOutput] = []
            fnc_executed_ev = FunctionToolsExecutedEvent(
                function_calls=[], function_call_outputs=[]
            )
            new_agent_task: Agent | None = None
            ignore_task_switch = False

            for sanitized_out in tool_output.output:
                fnc_executed_ev.function_calls.append(sanitized_out.fnc_call)
                fnc_executed_ev.function_call_outputs.append(sanitized_out.fnc_call_out)

                new_fnc_outputs.append(sanitized_out.fnc_call_out)

                # record the call with its output, as the pipeline task does. a call rejected
                # before execution never reached the started callback
                self._agent._chat_ctx._upsert_item(sanitized_out.fnc_call)
                self._agent._chat_ctx._upsert_item(sanitized_out.fnc_call_out)
                self._session._tool_items_added(
                    [sanitized_out.fnc_call, sanitized_out.fnc_call_out]
                )

                if new_agent_task is not None and sanitized_out.agent_task is not None:
                    logger.error(
                        "expected to receive only one Agent from the tool executions",
                    )
                    ignore_task_switch = True

                if sanitized_out.agent_task is not None:
                    new_agent_task = sanitized_out.agent_task

            if new_agent_task and not ignore_task_switch:
                fnc_executed_ev._handoff_required = True

            self._session.emit("function_tools_executed", fnc_executed_ev)

            draining = self.scheduling_paused
            if fnc_executed_ev._handoff_required and new_agent_task and not ignore_task_switch:
                self._session.update_agent(new_agent_task)
                draining = True

            if len(new_fnc_outputs) > 0:
                # wait all speeches played before updating the tool output and generating the response
                # most realtime models don't support generating multiple responses at the same time
                while self._current_speech or self._speech_q:
                    if (
                        self._current_speech
                        and not self._current_speech.done()
                        and self._current_speech is not speech_handle
                    ):
                        await self._current_speech
                    else:
                        await asyncio.sleep(0)

                # if the realtime model auto-generates the tool reply, install a
                # placeholder so the active RunResult waits for that reply
                auto_reply_fut: asyncio.Future[None] | None = None
                if (
                    self._rt_session.capabilities.auto_tool_reply_generation
                    and fnc_executed_ev.has_tool_reply
                    and self._pending_auto_tool_reply_fut is None
                    and (run_state := self._session._global_run_state) is not None
                    and not run_state.done()
                ):
                    auto_reply_fut = asyncio.get_event_loop().create_future()
                    self._pending_auto_tool_reply_fut = auto_reply_fut
                    llm_label = self.llm._label

                    async def _wait_for_auto_tool_reply() -> None:
                        try:
                            await asyncio.wait_for(asyncio.shield(auto_reply_fut), 5.0)
                        except asyncio.TimeoutError:
                            logger.warning(
                                "timed out waiting for realtime auto tool reply from %s",
                                llm_label,
                            )
                        finally:
                            if self._pending_auto_tool_reply_fut is auto_reply_fut:
                                self._pending_auto_tool_reply_fut = None

                    task = asyncio.create_task(_wait_for_auto_tool_reply())
                    run_state._watch_handle(task)

                # a model that replies to tool output itself does so under the session's
                # tool_choice, so an ask's forced one must not outlive the call that answered it
                if self._rt_session.capabilities.auto_tool_reply_generation:
                    self._restore_rt_tool_choice()

                try:
                    async with self._rt_chat_ctx_lock:
                        chat_ctx = self._rt_session.chat_ctx.copy()
                        chat_ctx.items.extend(new_fnc_outputs)
                        await self._rt_session.update_chat_ctx(chat_ctx)
                except llm.RealtimeError as e:
                    logger.warning(
                        "failed to update chat context before generating the function calls results",  # noqa: E501
                        extra={"error": str(e)},
                    )
                    if auto_reply_fut is not None and not auto_reply_fut.done():
                        if self._pending_auto_tool_reply_fut is auto_reply_fut:
                            self._pending_auto_tool_reply_fut = None
                        auto_reply_fut.set_result(None)

            tool_reply_expected = fnc_executed_ev.has_tool_reply
            if tool_reply_expected and not self._rt_session.capabilities.auto_tool_reply_generation:
                self._rt_session.interrupt()

                if max_steps_reached:
                    logger.warning(
                        "maximum number of function calls steps reached, "
                        "generating final response with tool_choice='none'",
                        extra={"speech_id": speech_handle.id},
                    )

                self._create_speech_task(
                    self._realtime_reply_task(
                        speech_handle=speech_handle,
                        model_settings=ModelSettings(
                            # Avoid setting tool_choice to "required" or a specific function when
                            # passing tool response back to the LLM
                            tool_choice="none"
                            if max_steps_reached or draining or model_settings.tool_choice == "none"
                            else _reply_tool_choice(
                                out.reply_tool_choice
                                for out in tool_output.output
                                if out.fnc_call_out.reply_required
                            )
                            or "auto",
                        ),
                        tool_reply=True,
                    ),
                    speech_handle=speech_handle,
                    name="AgentActivity.realtime_reply",
                )
                self._schedule_speech(
                    speech_handle, SpeechHandle.SPEECH_PRIORITY_NORMAL, force=True
                )

        # no reply follows, so nothing else clears the "thinking" the tool asserted
        if not tool_reply_expected and self._no_pending_speech:
            self._session._update_agent_state(
                "thinking" if self._background_speeches else "listening"
            )

    def _disallow_interruptions(self, speech_handle: SpeechHandle) -> None:
        speech_handle.allow_interruptions = False
        paused_speech = self._paused_speech
        if paused_speech is None or paused_speech.handle is not speech_handle:
            return

        if (
            not speech_handle.done()
            and self._session.output.audio_enabled
            and self._session.output.audio is not None
        ):
            self._restore_paused_speech_state(paused_speech)

        self._reconcile_playout_pause(speech_handle)

    def _update_paused_speech(self, speech_handle: SpeechHandle, timeout: float) -> None:
        """Record that ``speech_handle`` is paused.

        If already paused for this handle, only ``timeout`` is updated — the
        ``agent_state`` captured at first pause is preserved, so the resume
        path restores the correct state even across multiple calls.
        """
        if self._paused_speech and self._paused_speech.handle is speech_handle:
            self._paused_speech.timeout = timeout
        else:
            self._paused_speech = _PausedSpeechInfo(
                handle=speech_handle,
                agent_state=self._session.agent_state,
                timeout=timeout,
            )

    def _pause_enabled(self) -> bool:
        if self._rt_overlapping_speech_enabled:
            # the framework never interrupts on the caller here, so no interruption can be false
            return False

        interruption_options = self._session.options.interruption
        return bool(
            interruption_options["resume_false_interruption"]
            and interruption_options["false_interruption_timeout"] is not None
            and self._session.output.audio_enabled
            and self._session.output.audio
            and self._session.output.audio.can_pause
        )

    def _reconcile_playout_pause(self, speech_handle: SpeechHandle) -> None:
        """Preserve, apply, or release a speech pause before forwarding audio."""
        audio_output = self._session.output.audio
        pause_is_allowed = (
            self._pause_enabled()
            and not speech_handle.interrupted
            and speech_handle.allow_interruptions
        )
        pause_is_valid = (
            self._paused_speech is not None
            and self._paused_speech.handle is speech_handle
            and pause_is_allowed
        )
        if pause_is_valid:
            # a paused playout stay paused regardless of forwarding status
            return

        # clear stale _paused_speech ref
        if self._paused_speech is not None:
            self._cancel_false_interruption_timer()
            self._paused_speech = None

        if (
            pause_is_allowed
            and self._session.agent_state != "speaking"
            and not self._user_silence_event.is_set()
        ):
            assert audio_output is not None
            # SOS arrived before this handle became current so we pause here
            # EOS/transcripts/turn commit will resolve the pause eventually
            self._update_paused_speech(speech_handle, timeout=0)
            audio_output.pause()
            return

        if audio_output is not None:
            audio_output.resume()

    def _cancel_false_interruption_timer(self) -> None:
        if self._false_interruption_timer is not None:
            self._false_interruption_timer.cancel()
            self._false_interruption_timer = None
        self._false_interruption_pending = False

    def _restore_paused_speech_state(self, paused_speech: _PausedSpeechInfo) -> None:
        self._session._update_agent_state(
            paused_speech.agent_state,
            otel_context=paused_speech.handle._agent_turn_context,
        )
        if self._audio_recognition and paused_speech.agent_state == "speaking":
            self._audio_recognition._on_start_of_agent_speech(started_at=time.time())
        if self.interruption_enabled:
            self._disable_vad_interruption_soon()

    def _start_false_interruption_timer(self, timeout: float) -> None:
        self._cancel_false_interruption_timer()

        def _on_false_interruption() -> None:
            if self._paused_speech is None or (
                self._current_speech and self._current_speech is not self._paused_speech.handle
            ):
                # already new speech is scheduled, do nothing
                self._paused_speech = None
                return

            resumed = False
            if (
                self._session.options.interruption["resume_false_interruption"]
                and (audio_output := self._session.output.audio)
                and audio_output.can_pause
                and not self._paused_speech.handle.done()
            ):
                self._restore_paused_speech_state(self._paused_speech)
                audio_output.resume()
                resumed = True
                logger.debug("resumed false interrupted speech", extra={"timeout": timeout})

            self._session.emit(
                "agent_false_interruption", AgentFalseInterruptionEvent(resumed=resumed)
            )

            self._paused_speech = None
            self._false_interruption_timer = None

        def _on_turn_settled(settled: asyncio.Task[None]) -> None:
            if not self._false_interruption_pending:
                return  # the turn committed, or the pause was resolved another way

            recognition = self._audio_recognition
            eot_task = recognition._end_of_turn_task if recognition else None
            # a newer decision superseded this one (e.g. an stt final re-armed the bounce)
            if eot_task is not None and eot_task is not settled and not eot_task.done():
                eot_task.add_done_callback(_on_turn_settled)
                return

            self._false_interruption_pending = False
            if settled.cancelled() or (recognition is not None and recognition._closing.is_set()):
                return  # torn down instead of decided; closing releases the pause itself

            _on_false_interruption()

        def _on_timeout() -> None:
            self._false_interruption_timer = None

            # an open turn decision owns the paused speech: it either commits and interrupts it
            # or drops it, and only then is the interruption known to be false
            eot_task = (
                self._audio_recognition._end_of_turn_task if self._audio_recognition else None
            )
            if eot_task is not None and not eot_task.done():
                self._false_interruption_pending = True
                eot_task.add_done_callback(_on_turn_settled)
                return

            _on_false_interruption()

        self._false_interruption_timer = self._session._loop.call_later(timeout, _on_timeout)

    async def _cancel_speech_pause(
        self, old_task: asyncio.Task[None] | None = None, *, interrupt: bool = True
    ) -> None:
        """Clear a speech pause and optionally interrupt its handle.

        Final STT transcripts and committed turns that generate replies use
        ``interrupt=True``. Activity shutdown uses ``interrupt=False`` because the
        scheduling task owns the speech.
        """
        if old_task is not None:
            try:
                await old_task
            except Exception:
                # Don't let a failed prior task poison subsequent turn completions.
                # This can happen when _wait_for_generation raises because
                # the paused speech had no active generation (race condition).
                logger.debug("previous _cancel_speech_pause task failed, ignoring")

        self._cancel_false_interruption_timer()

        if not self._paused_speech:
            return

        if (
            interrupt
            and not self._paused_speech.handle.interrupted
            and self._paused_speech.handle.allow_interruptions
        ):
            # a final transcript or a committed turn ended the pause
            self._paused_speech.handle.interrupt(source="user_turn")
            # ensure the generation is done — but only if a generation
            # was actually started; a paused speech that was never
            # authorized won't have an active generation future.
            if self._paused_speech.handle._generations:
                await self._paused_speech.handle._wait_for_generation()
        self._paused_speech = None

        if (
            self._session.options.interruption["resume_false_interruption"]
            and self._session.output.audio
        ):
            self._session.output.audio.resume()

    def _disable_vad_interruption_soon(self) -> None:
        """Disable VAD interruption after the backchannel boundary expires."""
        audio_recognition = self._audio_recognition
        if audio_recognition and audio_recognition._backchannel_boundary_active:

            def _disable_vad_interruption() -> None:
                # only disable it if the agent is still speaking
                if (
                    self._session.agent_state == "speaking"
                    and self._interruption_by_audio_activity_enabled
                ):
                    logger.trace("backchannel boundary expired")
                    self.interruption_by_audio_activity_enabled = False

            audio_recognition._backchannel_boundary_callback = _disable_vad_interruption
        # keep vad interruption active if user is still speaking
        elif audio_recognition is None or not audio_recognition._speaking:
            self.interruption_by_audio_activity_enabled = False

    def _fallback_to_vad_interruption(
        self, error: inference.InterruptionDetectionError | None = None
    ) -> None:
        """Degrade gracefully from adaptive interruption to VAD-based interruption.

        Called when the adaptive interruption detector encounters an unrecoverable error.
        Re-enables audio-activity interruption so VAD events can trigger interruptions,
        and flushes any held transcripts that were waiting on the detector.
        """
        if not self._interruption_detection_enabled:
            return

        self._interruption_detected = False
        self._interruption_detection_enabled = False
        self.interruption_by_audio_activity_enabled = True

        if isinstance(self._interruption_detector, inference.AdaptiveInterruptionDetector):
            self._interruption_detector.off("metrics_collected", self._on_metrics_collected)
            self._interruption_detector.off("error", self._on_error)

        if self._audio_recognition:
            # this also releases any held transcripts
            self._audio_recognition._update_interruption_detection(None)

        logger.info(
            "adaptive interruption disabled due to unrecoverable error, "
            "falling back to VAD-based interruption",
            extra={
                "error": str(error.error) if error is not None else None,
                "label": error.label if error is not None else None,
            },
        )

    def _init_metrics_from_end_of_turn(self, info: _EndOfTurnInfo) -> llm.MetricsReport:
        metrics_report: llm.MetricsReport = {}
        if self.stt:
            metrics_report["stt_metadata"] = self.stt.metrics_metadata
        if info.metrics.started_speaking_at is not None:
            metrics_report["started_speaking_at"] = info.metrics.started_speaking_at

        if info.metrics.stopped_speaking_at is not None:
            metrics_report["stopped_speaking_at"] = info.metrics.stopped_speaking_at

        if info.metrics.transcription_delay is not None:
            metrics_report["transcription_delay"] = info.metrics.transcription_delay

        if info.metrics.end_of_turn_delay is not None:
            metrics_report["end_of_turn_delay"] = info.metrics.end_of_turn_delay

        return metrics_report

    # move them to the end to avoid shadowing the same named modules for mypy
    @property
    def _text_only(self) -> bool:
        # text simulations run without audio: no STT/TTS/VAD
        return self._session._text_only

    @property
    def vad(self) -> vad.VAD | None:
        if self._text_only:
            return None
        return self._agent.vad if is_given(self._agent.vad) else self._session.vad

    @property
    def using_default_vad(self) -> bool:
        if is_given(self._agent.vad):
            return False
        return self._session._using_default_vad

    def _resolve_interruption_detection(self) -> inference.AdaptiveInterruptionDetector | None:
        # text simulations carry no audio to detect interruptions in
        if self._text_only:
            return None

        realtime_llm = self.llm if isinstance(self.llm, llm.RealtimeModel) else None
        if realtime_llm is not None:
            # realtime commits turns manually; barge-in withholds the commit, so no STT is needed
            can_gatekeep = not self._rt_turn_detection_enabled
        else:
            can_gatekeep = self.stt is not None

        if (
            not can_gatekeep
            or self.vad is None
            or self._turn_detection in ("manual", "realtime_llm")
        ):
            if (
                is_given(self._agent.interruption_detection)
                and self._agent.interruption_detection == "adaptive"
            ) or (
                is_given(self._session.interruption_detection)
                and self._session.interruption_detection == "adaptive"
            ):
                logger.warning(
                    "interruption_detection is provided, but it's not compatible with the current configuration and will be disabled"
                )
            return None

        if not self.allow_interruptions:
            return None

        if (
            is_given(self._agent.interruption_detection)
            and self._agent.interruption_detection == "vad"
        ):
            return None
        if (
            is_given(self._session.interruption_detection)
            and self._session.interruption_detection == "vad"
        ):
            return None

        if (
            not is_given(self._agent.interruption_detection)
            and not is_given(self._session.interruption_detection)
            and not utils.is_hosted()
            and not utils.is_dev_mode()
        ):
            logger.info("adaptive interruption is disabled by default in production mode")
            return None

        try:
            detector = inference.AdaptiveInterruptionDetector()
        except ValueError as e:
            logger.warning("failed to create AdaptiveInterruptionDetector", extra={"error": str(e)})
            return None

        return detector

    @property
    def stt(self) -> stt.STT | None:
        if self._text_only:
            return None
        return self._agent.stt if is_given(self._agent.stt) else self._session.stt

    @property
    def llm(self) -> llm.LLM | llm.RealtimeModel | None:
        return self._agent.llm if is_given(self._agent.llm) else self._session.llm

    @property
    def tts(self) -> tts.TTS | None:
        if self._text_only:
            return None
        return self._agent.tts if is_given(self._agent.tts) else self._session.tts
