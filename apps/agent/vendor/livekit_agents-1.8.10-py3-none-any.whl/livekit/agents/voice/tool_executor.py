from __future__ import annotations

import asyncio
import json
import weakref
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from typing_extensions import TypedDict

from .. import utils
from ..llm.chat_context import ChatContext, ChatItem
from ..llm.tool_context import (
    CONFIRM_DUPLICATE_PARAM,
    DuplicateMode,
    DuplicateScope,
    FunctionTool,
    RawFunctionTool,
    StopResponse,
    Tool,
    ToolChoice,
    ToolError,
    ToolFlag,
    ToolResult,
    Toolset,
    function_tool,
)
from ..llm.utils import prepare_function_arguments, validated_arguments
from ..log import logger
from ..types import NOT_GIVEN, NotGivenOr
from .events import (
    RunContext,
    ToolCallEnded,
    ToolCallStarted,
    ToolExecutionUpdatedEvent,
    ToolReplyUpdated,
)

if TYPE_CHECKING:
    from .agent import Agent
    from .agent_activity import AgentActivity
    from .agent_session import AgentSession
    from .speech_handle import SpeechHandle


UPDATE_TEMPLATE = """The tool `{function_name}` has updated, message: {message}
The task is still running, so DON'T make up or give information not included in the message above."""

DUPLICATE_REJECT = """Same tool `{function_name}` is already running:
{fnc_calls_text}"""

DUPLICATE_REJECT_WITH_CANCEL = """Same tool `{function_name}` is already running:
{fnc_calls_text}
If you want to cancel the existing one, call `lk_agents_cancel_task` with call_id.
Only do this when user explicitly requests it."""

DUPLICATE_CONFIRM = """Same tool `{function_name}` is already running:
{fnc_calls_text}
Re-call with confirm duplicate True to run a duplicate if needed.
Only run a duplicate when the user explicitly requests it."""

DUPLICATE_CONFIRM_WITH_CANCEL = """Same tool `{function_name}` is already running:
{fnc_calls_text}
Re-call with confirm duplicate True to run a duplicate if needed,
or if you want to cancel the existing one, call `lk_agents_cancel_task` with call_id.
Only run duplicate or cancel the existing one when user explicitly requests it."""

# used when the pending update is the most recent item in chat_ctx — the agent
# can't have already talked about it.
REPLY_INSTRUCTIONS_AT_TAIL = """New results arrived from background tool calls (call_ids: {call_ids}).
Summarize the results naturally. Do NOT repeat information you have already told the user."""

# used when newer items have been appended after the pending update — the agent
# may have already verbalized the result in its most recent turn.
REPLY_INSTRUCTIONS_MAYBE_COVERED = """New results arrived from background tool calls (call_ids: {call_ids}).
You may have already mentioned them in your most recent replies.
If you already told the user everything in these results, reply with an empty response (no text at all).
Otherwise, summarize only what you have not said yet, with a natural transition.
Never repeat information you have already told the user."""


class UpdatePromptArgs(TypedDict):
    """Args for the ``update`` template."""

    function_name: str
    call_id: str
    message: str


class DuplicatePromptArgs(TypedDict):
    """Args for the ``duplicate_reject`` / ``duplicate_confirm`` templates."""

    function_name: str
    fnc_calls_json: list[str]
    """JSON dump per in-flight FunctionCall — use this from callable templates."""
    fnc_calls_text: str
    """``fnc_calls_json`` joined by newlines — what the default string templates use."""


class ReplyPromptArgs(TypedDict):
    """Args for the ``reply_at_tail`` / ``reply_maybe_covered`` templates."""

    call_ids: list[str]


class AsyncToolOptions(TypedDict, total=False):
    """System-message templates injected around async tool dispatch.

    Each field is either a ``str.format()`` template or a callable returning a string,
    with the args typed as ``UpdatePromptArgs`` / ``DuplicatePromptArgs`` /
    ``ReplyPromptArgs``. Unmentioned keys keep their defaults.
    """

    update_template: str | Callable[[UpdatePromptArgs], str]
    """Wraps a user-provided ``ctx.update(message)`` string before it lands in chat_ctx."""
    duplicate_reject_template: str | Callable[[DuplicatePromptArgs], str]
    """Sent to the LLM when ``on_duplicate='reject'`` blocks a duplicate call."""
    duplicate_confirm_template: str | Callable[[DuplicatePromptArgs], str]
    """Sent to the LLM when ``on_duplicate='confirm'`` requires re-call with confirmation."""
    reply_at_tail_template: str | Callable[[ReplyPromptArgs], str]
    """Instruction for the deferred reply when the pending update is still the tail of chat_ctx."""
    reply_maybe_covered_template: str | Callable[[ReplyPromptArgs], str]
    """Instruction for the deferred reply when newer items came after the pending update."""


class ToolHandlingOptions(TypedDict, total=False):
    """Configuration for the tool handling system.

    Can be passed as a plain dict::

        AgentSession(
            tool_handling={
                "async_options": {"update_template": "..."},
            },
        )

    Set on ``AgentSession``, ``Agent``, or ``AsyncToolset`` (most specific wins).
    """

    async_options: AsyncToolOptions
    """Templates injected around async tool dispatch (``ctx.update()``, duplicate
    handling, coalesced replies). Unmentioned keys keep their defaults."""


def _render(template: str | Callable[[Any], str], args: dict[str, Any]) -> str:
    """Render a template: callables receive ``args``; strings use ``str.format(**args)``."""
    if callable(template):
        return template(args)
    return template.format(**args)


_ASYNC_TOOL_OPTIONS_DEFAULTS: AsyncToolOptions = {
    "update_template": UPDATE_TEMPLATE,
    "duplicate_reject_template": DUPLICATE_REJECT,
    "duplicate_confirm_template": DUPLICATE_CONFIRM,
    "reply_at_tail_template": REPLY_INSTRUCTIONS_AT_TAIL,
    "reply_maybe_covered_template": REPLY_INSTRUCTIONS_MAYBE_COVERED,
}


def _resolve_async_tool_options(
    config: AsyncToolOptions | None = None,
) -> AsyncToolOptions:
    """Return a fully-populated ``AsyncToolOptions`` with defaults filled in for absent keys."""
    if config is None:
        return AsyncToolOptions(**_ASYNC_TOOL_OPTIONS_DEFAULTS)
    return AsyncToolOptions(**{**_ASYNC_TOOL_OPTIONS_DEFAULTS, **config})


# session-scoped view shared across executors, so cancel_task / get_running_tasks
# see all tasks of their session but never a nested session's. weak-keyed so a
# dropped session can't leak its tasks.
_RunningTasks: weakref.WeakKeyDictionary[AgentSession, dict[str, _RunningTask]] = (
    weakref.WeakKeyDictionary()
)


@function_tool(name="lk_agents_get_running_tasks")
async def get_running_tasks(ctx: RunContext) -> list[dict]:
    """Get the list of running tool calls that are cancellable."""
    return [
        task.ctx.function_call.model_dump()
        for task in _RunningTasks.get(ctx.session, {}).values()
        if task.allow_cancellation
    ]


@function_tool(name="lk_agents_cancel_task")
async def cancel_task(ctx: RunContext, call_id: str) -> str:
    """Cancel a running tool call by call_id."""
    task = _RunningTasks.get(ctx.session, {}).get(call_id)
    if task is None:
        raise ToolError(f"Task {call_id} not found")

    if not await task.executor.cancel(call_id):
        raise ToolError(f"Task {call_id} not found or already completed")
    return f"Task {call_id} cancelled successfully."


def has_cancellable_tool(tools: Sequence[Tool | Toolset]) -> bool:
    """Return True if any tool (or nested toolset tool) has ``ToolFlag.CANCELLABLE``."""
    for tool in tools:
        if isinstance(tool, (FunctionTool, RawFunctionTool)):
            if ToolFlag.CANCELLABLE in tool.info.flags:
                return True
        elif isinstance(tool, Toolset):
            if has_cancellable_tool(tool.tools):
                return True
    return False


def _canonical_args(raw_arguments: dict[str, Any]) -> str:
    """Stable JSON for argument comparison.

    ``sort_keys`` recurses into nested objects, so a provider's key-emission order
    can't make two identical calls look different. Lists stay order-sensitive —
    ``["a", "b"]`` and ``["b", "a"]`` are genuinely different arguments.
    """
    return json.dumps(raw_arguments, sort_keys=True, default=str)


def _duplicate_key(
    *,
    fnc: FunctionTool | RawFunctionTool,
    fnc_name: str,
    scope: DuplicateScope,
    raw_arguments: dict[str, Any],
) -> tuple[str, str | None]:
    """The identity a call is deduplicated on. Always name-scoped, so two tools
    can never collide; under ``"name"`` equality reduces to name equality.

    ``"name_and_args"`` compares *validated* arguments, so an optional parameter the
    LLM omitted on one call and passed explicitly on the next still reads as the same
    call (see :func:`validated_arguments`).
    """
    if scope != "name_and_args":
        return (fnc_name, None)

    # the confirm flag is harness state, not an argument
    raw = {k: v for k, v in raw_arguments.items() if k != CONFIRM_DUPLICATE_PARAM}

    try:
        # encoding is in the try too: validated values are Python objects, so a type like
        # dict[SomeEnum, int] yields keys json can't encode
        return (fnc_name, _canonical_args(validated_arguments(fnc, raw)))
    except Exception:
        # the call raises ToolError on its own later; key on what was sent, which always
        # encodes, rather than failing the guard here
        return (fnc_name, _canonical_args(raw))


@dataclass
class _RunningTask:
    ctx: RunContext
    exe_task: asyncio.Task[Any]
    executor: _ToolExecutor
    allow_cancellation: bool
    duplicate_key: tuple[str, str | None] | None  # None when the tool is on_duplicate="allow"


@dataclass
class _PendingUpdate:
    ctx: RunContext
    items: list[ChatItem]
    target: Agent  # agent that received the eager chat_ctx insert
    tool_choice: ToolChoice | None
    """What the reply may call: an update's request, or None for a result to act on."""


def _reply_tool_choice(requests: Iterable[ToolChoice | None]) -> ToolChoice | None:
    """The tool choice of one reply step answering several tool outputs.

    The step honours a single shared request, and is otherwise unconstrained: outputs that
    disagree cannot all be satisfied, and one of them wanting the tools is enough to need them.
    """
    distinct: list[ToolChoice | None] = []
    for request in requests:
        # a named choice is a dict, so this compares rather than hashes
        if request not in distinct:
            distinct.append(request)
    return distinct[0] if len(distinct) == 1 else None


class _ToolExecutor:
    """Lifecycle manager for in-flight tool calls.

    Activity-scoped (``owning_activity`` set): tasks belong to one AgentActivity
    and are cancelled or awaited on drain depending on ``allow_cancellation``.

    Session-scoped (``owning_activity=None``): tasks survive agent handoff; replies
    are delivered to whichever agent is current at delivery time.
    """

    def __init__(
        self,
        *,
        owning_activity: AgentActivity | None = None,
        async_tool_options: AsyncToolOptions | None = None,
    ) -> None:
        self._running_tasks: dict[str, _RunningTask] = {}
        self._duplicate_check_lock = asyncio.Lock()

        self._pending_updates: list[_PendingUpdate] = []
        self._reply_task: asyncio.Task[None] | None = None

        self._owning_activity: AgentActivity | None = owning_activity
        self._tool_options: AsyncToolOptions = _resolve_async_tool_options(async_tool_options)

    def set_owning_activity(self, activity: AgentActivity | None) -> None:
        self._owning_activity = activity

    def set_tool_options(self, options: AsyncToolOptions) -> None:
        """Replace the async tool templates. Caller must pre-resolve defaults."""
        self._tool_options = options

    @property
    def has_running_tasks(self) -> bool:
        return bool(self._running_tasks)

    @property
    def has_cancellable_running_tasks(self) -> bool:
        return any(t.allow_cancellation for t in self._running_tasks.values())

    async def execute(
        self,
        *,
        tool: FunctionTool | RawFunctionTool,
        run_ctx: RunContext,
        raw_arguments: dict[str, Any],
        mock: Callable[..., Any] | None = None,
    ) -> Any:
        """Run ``tool``. Returns when the first ``ctx.update()`` lands or the tool returns."""
        call_id = run_ctx.function_call.call_id
        fnc_name = run_ctx.function_call.name
        info = tool.info
        on_duplicate: DuplicateMode = info.on_duplicate
        allow_cancellation: bool = ToolFlag.CANCELLABLE in info.flags

        confirm_duplicate: bool | None = None
        if on_duplicate == "confirm":
            confirm_duplicate = bool(raw_arguments.pop(CONFIRM_DUPLICATE_PARAM, False))

        # nothing can match an "allow" tool's key: keys are name-scoped, the mode is per tool
        dup_key: tuple[str, str | None] | None = None
        if on_duplicate != "allow":
            # derived AFTER the pop, so a confirming re-call keys like the call it confirms
            dup_key = _duplicate_key(
                fnc=tool,
                fnc_name=fnc_name,
                scope=info.duplicate_scope,
                raw_arguments=raw_arguments,
            )

            duplicate_result = await self._check_duplicate(
                dup_key, on_duplicate=on_duplicate, confirm_duplicate=confirm_duplicate
            )
            if duplicate_result is not None:
                logger.debug(
                    "duplicate tool call rejected",
                    extra={"call_id": call_id, "function": fnc_name},
                )
                return duplicate_result

        if call_id in self._running_tasks:
            raise ValueError(f"Task already running for call_id: {call_id}")

        # the future is how RunContext.update() talks back to dispatch
        first_update_fut = asyncio.Future[Any]()
        run_ctx._attach_executor(self, first_update_fut)

        # run the tool and return its raw output (or the caught exception); _on_done
        # derives the call's single terminal entry from how the task ended
        async def _execute_tool() -> Any:
            try:
                fnc_args, fnc_kwargs = prepare_function_arguments(
                    fnc=tool, json_arguments=raw_arguments, call_ctx=run_ctx
                )
                if mock is not None:
                    from .run_result import _run_mock

                    output = await _run_mock(mock, *fnc_args, **fnc_kwargs)
                else:
                    output = await tool(*fnc_args, **fnc_kwargs)
            except asyncio.CancelledError:
                logger.debug("tool cancelled", extra={"call_id": call_id, "function": fnc_name})
                if not first_update_fut.done():
                    first_update_fut.set_result(None)
                raise  # _on_done emits the cancelled terminal
            except Exception as e:
                output = e

            if not first_update_fut.done():
                # tool returned without ctx.update() — surface the result to dispatch
                if isinstance(output, BaseException):
                    first_update_fut.set_exception(output)
                else:
                    first_update_fut.set_result(output)
                return output

            if isinstance(output, BaseException) and not isinstance(output, StopResponse):
                if isinstance(output, ToolError):
                    # Keep detail out of the message body so redaction can
                    # drop it (a log body cannot be redacted).
                    logger.warning(
                        "ToolError while executing tool",
                        extra={
                            "function": fnc_name,
                            "call_id": call_id,
                            "lk.pii.error": output.message,
                        },
                    )
                else:
                    logger.error(
                        "exception occurred while executing tool",
                        extra={"function": fnc_name, "call_id": call_id},
                        exc_info=output,
                    )

            # every final return, None included, goes through the coalescer as a synthetic
            # output, so the model never waits on a result that won't come
            final = run_ctx._make_update_output(output, call_id_suffix="_final")
            if final.agent_task is not None:
                # the first update already answered dispatch, so a returned handoff cannot apply
                logger.error(
                    f"tool `{fnc_name}` returned an Agent after ctx.update(); "
                    "agent handoff after a progress update is not supported",
                    extra={"call_id": call_id, "function": fnc_name},
                )
                output = ToolError("the agent handoff did not happen")
                final = run_ctx._make_update_output(output, call_id_suffix="_final")

            pair = (final.fnc_call, final.fnc_call_out)
            run_ctx._updates.append(pair)
            # a return is a result to act on, unlike a report, so the reply that phrases it
            # is as free to call something as the reply to an ordinary tool would be
            await self._enqueue_reply(run_ctx, [pair[0], pair[1]], tool_choice=None)
            return output

        exe_task = asyncio.create_task(_execute_tool(), name=f"tool_exec_{fnc_name}")
        from .agent import _pass_through_activity_task_info

        _pass_through_activity_task_info(exe_task)

        running_task = _RunningTask(
            ctx=run_ctx,
            exe_task=exe_task,
            executor=self,
            allow_cancellation=allow_cancellation,
            duplicate_key=dup_key,
        )
        self._running_tasks[call_id] = running_task

        session = run_ctx.session
        _RunningTasks.setdefault(session, {})[call_id] = running_task

        session._tool_execution_updated(
            ToolExecutionUpdatedEvent(update=ToolCallStarted(function_call=run_ctx.function_call)),
        )

        def _on_done(task: asyncio.Task[Any]) -> None:
            self._running_tasks.pop(call_id, None)
            if (session_tasks := _RunningTasks.get(session)) is not None:
                session_tasks.pop(call_id, None)
            # detach so a stashed RunContext can't drive the executor post-completion
            run_ctx._detach_executor()

            # how the task ended: a returned value, a raised exception, or cancellation
            try:
                output = task.result()
            except BaseException as e:
                output = e

            if not first_update_fut.done():
                first_update_fut.set_result(None)  # cancelled before the first update

            # one terminal entry per call; deferred entries use the _final id
            from .agent import Agent

            if isinstance(output, ToolResult):
                output = output.output

            status: Literal["done", "error", "cancelled"]
            message: str | None
            if task.cancelled() or isinstance(output, asyncio.CancelledError):
                status, message = "cancelled", None
            elif isinstance(output, BaseException) and not isinstance(output, StopResponse):
                status, message = "error", str(output)
            elif output is None or isinstance(output, (StopResponse, Agent)):
                status, message = "done", None
            else:
                status, message = "done", str(output)

            entry_id = call_id + "_final" if run_ctx._updates else call_id
            session._tool_execution_updated(
                ToolExecutionUpdatedEvent(
                    update=ToolCallEnded(
                        id=entry_id, call_id=call_id, message=message, status=status
                    )
                ),
            )

        exe_task.add_done_callback(_on_done)

        return await first_update_fut

    async def cancel(self, call_id: str) -> bool:
        task = self._running_tasks.get(call_id)
        if task is None:
            return False

        if not task.allow_cancellation:
            raise ToolError(f"Tool call {call_id} is not cancellable")

        if not task.ctx.speech_handle.allow_interruptions:
            raise ToolError(
                f"Tool call {call_id} is not cancellable because interruptions are disallowed"
            )
        await utils.aio.cancel_and_wait(task.exe_task)
        return True

    async def cancel_all(self, *, cancellable_only: bool = False) -> None:
        """Cancel all running tasks. When ``cancellable_only=True``, tasks with
        ``allow_cancellation=False`` are awaited to completion instead (used by drain)."""
        if cancellable_only:
            to_cancel = [t.exe_task for t in self._running_tasks.values() if t.allow_cancellation]
            to_wait = [t.exe_task for t in self._running_tasks.values() if not t.allow_cancellation]
        else:
            to_cancel = [t.exe_task for t in self._running_tasks.values()]
            to_wait = []

        if to_cancel:
            await utils.aio.cancel_and_wait(*to_cancel)
        if to_wait:
            await asyncio.gather(*to_wait, return_exceptions=True)

    async def aclose(self) -> None:
        """Cancel everything and drop any buffered replies."""
        self._pending_updates.clear()
        tasks = [task.exe_task for task in self._running_tasks.values()]
        if self._reply_task is not None:
            tasks.append(self._reply_task)
        if tasks:
            await utils.aio.cancel_and_wait(*tasks)
        self._running_tasks.clear()

    async def drain(self) -> None:
        """Cancel cancellable tools, await the rest. Reply delivery is left running;
        ``_deliver_reply`` drops itself when its target activity closes."""
        await self.cancel_all(cancellable_only=True)

    async def _enqueue_reply(
        self,
        ctx: RunContext,
        items: list[ChatItem],
        *,
        tool_choice: ToolChoice | None = None,
    ) -> None:
        # eager insert so a reply firing before delivery sees the items
        target = (
            self._owning_activity.agent
            if self._owning_activity is not None
            else ctx.session.current_agent
        )
        chat_ctx = target.chat_ctx.copy()
        chat_ctx.insert(items)
        # session tools are valid for any agent, but one not yet started filters by its own tools
        await target.update_chat_ctx(
            chat_ctx, exclude_invalid_function_calls=self._owning_activity is not None
        )
        ctx.session.history.insert(items)

        if not any(item.type == "function_call_output" and item.reply_required for item in items):
            return

        self._pending_updates.append(
            _PendingUpdate(ctx=ctx, items=items, target=target, tool_choice=tool_choice)
        )

        if self._reply_task is None or self._reply_task.done():
            self._reply_task = asyncio.create_task(
                self._deliver_reply(ctx.session), name="tool_executor_deliver_reply"
            )
            # let an active RunResult wait for the deferred reply to land
            run_state = ctx.session._global_run_state
            if run_state is not None:
                run_state._watch_handle(self._reply_task)

    async def _deliver_reply(self, session: AgentSession) -> None:
        from .agent_activity import ActivityClosedError

        while True:
            try:
                if self._owning_activity is not None:
                    activity = self._owning_activity
                    await activity.wait_for_idle()
                else:
                    activity = await session.wait_for_idle()

                if not activity.scheduling_paused:
                    break

                # idle but paused: it resumes once an AgentTask returns, or closes at a handoff.
                # the AgentTask may need another run to return, so release the current one
                reply_task = asyncio.current_task()
                run_state = session._global_run_state
                suspended = False
                if reply_task and run_state and run_state._unwatch_handle(reply_task):
                    suspended = True
                    run_state._mark_done_if_needed(None)

                await activity._scheduling_resumed.wait()

                # rejoin whichever run is active on resume, as AgentTask does with its parent
                run_state = session._global_run_state
                if suspended and reply_task and run_state and not run_state.done():
                    run_state._watch_handle(reply_task)

                if activity._closed:
                    raise ActivityClosedError(f"activity {activity.agent.label} is closing")
            except ActivityClosedError:
                # a session-scoped reply follows a handoff in flight to the next agent;
                # anything else (session close included) drops it
                if (
                    self._owning_activity is not None
                    or session._is_closing()
                    or not session._activity_lock.locked()
                ):
                    logger.debug("dropping tool reply — owning activity closed")
                    self._pending_updates.clear()
                    return

                async with session._activity_lock:
                    pass

        target_agent = activity.agent

        # no await after this line

        updates = self._pending_updates[:]
        self._pending_updates.clear()

        pending_items: list[ChatItem] = []
        for update in updates:
            pending_items.extend(update.items)

        if not pending_items:
            return

        # only insert again if delivery target differs (session-scoped handoff)
        chat_ctx: NotGivenOr[ChatContext] = NOT_GIVEN
        items_to_insert = [
            item for u in updates for item in u.items if u.target is not target_agent
        ]
        if items_to_insert:
            logger.warning(
                "agent handoff happened while tool waiting for reply delivering",
                extra={
                    "tools": [
                        u.ctx.function_call.name for u in updates if u.target is not target_agent
                    ],
                },
            )
            chat_ctx = target_agent.chat_ctx.copy()
            chat_ctx.insert(items_to_insert)

        # if the update is still the tail, the agent hasn't spoken since — summarize
        # directly; otherwise let the LLM decide whether it already covered this
        at_tail = (items := target_agent.chat_ctx.items) and items[-1].id == pending_items[-1].id
        template = (
            self._tool_options["reply_at_tail_template"]
            if at_tail
            else self._tool_options["reply_maybe_covered_template"]
        )

        call_ids = [item.call_id for item in pending_items if item.type == "function_call_output"]
        tool_choice = _reply_tool_choice(u.tool_choice for u in updates)
        speech = session.generate_reply(
            instructions=_render(template, {"call_ids": call_ids}),
            tool_choice=tool_choice if tool_choice is not None else NOT_GIVEN,
            chat_ctx=chat_ctx,
        )
        session._tool_execution_updated(
            ToolExecutionUpdatedEvent(
                update=ToolReplyUpdated(
                    update_ids=call_ids, status="scheduled", speech_id=speech.id
                )
            ),
        )
        logger.debug(
            "generate async tool reply",
            extra={
                "speech_id": speech.id,
                "items": [
                    (item.name, item.call_id)
                    for item in pending_items
                    if item.type == "function_call_output"
                ],
                "updates_at_tail": at_tail,
            },
        )

        def _on_speech_done(speech: SpeechHandle) -> None:
            reply_status: Literal["completed", "interrupted", "skipped"]
            if speech.interrupted:
                reply_status = "interrupted"
            elif not speech.chat_items:
                # the LLM judged the content already covered and produced no output
                reply_status = "skipped"
            else:
                reply_status = "completed"

            if not speech.chat_items:
                logger.debug(
                    "async tool reply was done without outputs",
                    extra={"speech_id": speech.id, "interrupted": speech.interrupted},
                )
                # TODO(long): reschedule interrupted replies?

            session._tool_execution_updated(
                ToolExecutionUpdatedEvent(
                    update=ToolReplyUpdated(
                        update_ids=call_ids, status=reply_status, speech_id=speech.id
                    )
                ),
            )

        speech.add_done_callback(_on_speech_done)

    async def _check_duplicate(
        self,
        dup_key: tuple[str, str | None],
        *,
        on_duplicate: DuplicateMode,
        confirm_duplicate: bool | None,
    ) -> str | None:
        if on_duplicate == "allow":
            return None

        fnc_name = dup_key[0]

        async with self._duplicate_check_lock:
            running_fnc_calls = [
                t.ctx.function_call
                for t in self._running_tasks.values()
                if t.duplicate_key == dup_key
            ]
            if len(running_fnc_calls) == 0:
                return None

            if on_duplicate == "replace":
                # replace must honor each in-flight task's allow_cancellation flag
                non_cancellable = [
                    fnc_call
                    for fnc_call in running_fnc_calls
                    if not self._running_tasks[fnc_call.call_id].allow_cancellation
                ]
                if non_cancellable:
                    raise ToolError(
                        f"cannot replace duplicate call of `{fnc_name}`: "
                        f"running call is not cancellable (allow_cancellation=False)"
                    )

                results = await asyncio.gather(
                    *[self.cancel(fnc_call.call_id) for fnc_call in running_fnc_calls],
                    return_exceptions=True,
                )
                exceptions = [result for result in results if isinstance(result, Exception)]
                if exceptions:
                    error_messages = "\n".join([str(e) for e in exceptions])
                    raise ToolError(f"Failed to cancel duplicate tool calls: {error_messages}")
                return None

            fnc_calls_json = [fnc_call.model_dump_json() for fnc_call in running_fnc_calls]
            args: DuplicatePromptArgs = {
                "function_name": fnc_name,
                "fnc_calls_json": fnc_calls_json,
                "fnc_calls_text": "\n".join(fnc_calls_json),
            }
            # Only mention lk_agents_cancel_task when an in-flight duplicate is
            # cancellable — that tool is exposed only for ToolFlag.CANCELLABLE
            # tools (see AgentActivity.tools), so non-cancellable reject/confirm
            # must not instruct the model to call a missing function.
            can_cancel = any(
                self._running_tasks[fnc_call.call_id].allow_cancellation
                for fnc_call in running_fnc_calls
            )
            if on_duplicate == "reject":
                template = self._tool_options["duplicate_reject_template"]
                if template is DUPLICATE_REJECT and can_cancel:
                    template = DUPLICATE_REJECT_WITH_CANCEL
                return _render(template, dict(args))

            if on_duplicate == "confirm" and not confirm_duplicate:
                template = self._tool_options["duplicate_confirm_template"]
                if template is DUPLICATE_CONFIRM and can_cancel:
                    template = DUPLICATE_CONFIRM_WITH_CANCEL
                return _render(template, dict(args))

        return None


def _build_executor_map(
    *,
    toolsets: Sequence[Toolset],
    default: _ToolExecutor,
) -> dict[str, _ToolExecutor]:
    """Map each tool to its owning executor: AsyncToolset tools route to that
    toolset's own executor; everything else falls back to ``default``."""
    from ..llm.async_toolset import AsyncToolset

    mapping: dict[str, _ToolExecutor] = {}

    def walk(ts: Toolset, current: _ToolExecutor) -> None:
        if isinstance(ts, AsyncToolset):
            current = ts._executor
        for child in ts.tools:
            if isinstance(child, (FunctionTool, RawFunctionTool)):
                mapping[child.info.name] = current
            elif isinstance(child, Toolset):
                walk(child, current)

    for ts in toolsets:
        walk(ts, default)
    return mapping
