from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Iterable
from typing import Any, Generic, TypeVar, cast

from opentelemetry import context as otel_context, trace
from typing_extensions import override

import livekit.rtc as rtc
from livekit.rtc._proto.track_pb2 import AudioTrackFeature

from ...log import logger
from ...telemetry import trace_types, tracer
from ...utils import aio, log_exceptions
from ...utils.audio import silence_frame
from ..io import AudioInput, VideoInput
from ._pre_connect_audio import PreConnectAudioHandler
from .types import NoiseCancellationParams, NoiseCancellationSelector

T = TypeVar("T", bound=rtc.AudioFrame | rtc.VideoFrame)


class _ParticipantInputStream(Generic[T], ABC):
    """
    A stream that dynamically transitions between new audio and video feeds from a connected
    participant, seamlessly switching to a different stream when the linked participant changes.
    """

    def __init__(
        self,
        room: rtc.Room,
        *,
        track_source: rtc.TrackSource.ValueType | list[rtc.TrackSource.ValueType],
        processor: rtc.FrameProcessor[T] | None = None,
    ) -> None:
        self._room = room
        self._accepted_sources = (
            {track_source}
            if isinstance(track_source, rtc.TrackSource.ValueType)
            else set(track_source)
        )

        self._data_ch = aio.Chan[T]()
        self._publication: rtc.RemoteTrackPublication | None = None
        self._track: rtc.RemoteTrack | None = None
        self._stream: rtc.VideoStream | rtc.AudioStream | None = None
        self._participant_identity: str | None = None
        # when set, only this exact publication is accepted, rather than any track of the
        # linked participant whose source is accepted
        self._track_sid: str | None = None
        self._attached = True
        self._closed = False

        self._forward_atask: asyncio.Task[None] | None = None
        self._forward_tasks: set[asyncio.Task[None]] = set()
        self._tasks: set[asyncio.Task[Any]] = set()

        self._room.on("track_subscribed", self._on_track_available)
        self._room.on("track_unsubscribed", self._on_track_unsubscribed)
        self._room.on("track_unpublished", self._on_track_unavailable)

        self._processor = processor
        self._processor_owned = False

        # wait_for_<kind>_track: linked participant -> first frame (audio streams only)
        self._track_wait_span_name: str | None = None
        self._track_wait_span: trace.Span | None = None
        self._track_wait_started_at: float | None = None
        self._trace_context: otel_context.Context | None = None

    def set_trace_context(self, context: otel_context.Context | None) -> None:
        """Parent for the next track-wait span (the session's startup bar), never current."""
        self._trace_context = context

    async def __anext__(self) -> T:
        return await self._data_ch.__anext__()

    def __aiter__(self) -> AsyncIterator[T]:
        return self

    @property
    def publication_source(self) -> rtc.TrackSource.ValueType:
        if not self._publication:
            return rtc.TrackSource.SOURCE_UNKNOWN
        return self._publication.source

    def on_attached(self) -> None:
        logger.debug(
            "input stream attached",
            extra={
                "participant": self._participant_identity,
                "source": rtc.TrackSource.Name(self.publication_source),
                "accepted_sources": [
                    rtc.TrackSource.Name(source) for source in self._accepted_sources
                ],
            },
        )
        self._attached = True

    def on_detached(self) -> None:
        logger.debug(
            "input stream detached",
            extra={
                "participant": self._participant_identity,
                "source": rtc.TrackSource.Name(self.publication_source),
                "accepted_sources": [
                    rtc.TrackSource.Name(source) for source in self._accepted_sources
                ],
            },
        )
        self._attached = False

    def set_track_sid(self, track_sid: str | None) -> None:
        """Pin the stream to one publication of the linked participant.

        ``None`` restores the default, which takes any track whose source is accepted.
        """
        if self._track_sid == track_sid:
            return

        self._track_sid = track_sid
        self._close_stream()

        if (identity := self._participant_identity) is None:
            return

        if (participant := self._room.remote_participants.get(identity)) is not None:
            for publication in participant.track_publications.values():
                if publication.track:
                    self._on_track_available(publication.track, publication, participant)

    def set_participant(self, participant: rtc.RemoteParticipant | str | None) -> None:
        # set_participant can be called before the participant is connected
        participant_identity = (
            participant.identity if isinstance(participant, rtc.RemoteParticipant) else participant
        )
        if self._participant_identity == participant_identity:
            return

        self._participant_identity = participant_identity
        self._close_stream()
        self._end_track_wait()

        if participant_identity is None:
            return

        self._begin_track_wait(participant_identity)
        participant = (
            participant
            if isinstance(participant, rtc.RemoteParticipant)
            else self._room.remote_participants.get(participant_identity)
        )
        if participant:
            for publication in participant.track_publications.values():
                if not publication.track:
                    continue
                self._on_track_available(publication.track, publication, participant)

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True

        stream = self._stream
        self._stream = None
        self._track = None
        self._publication = None
        self._end_track_wait()
        if stream:
            await stream.aclose()
        if self._processor:
            self._processor._close()
            self._processor = None
        if self._forward_tasks:
            await aio.cancel_and_wait(*self._forward_tasks)
        self._forward_atask = None

        self._room.off("track_subscribed", self._on_track_available)
        self._room.off("track_unsubscribed", self._on_track_unsubscribed)
        self._room.off("track_unpublished", self._on_track_unavailable)
        self._data_ch.close()

    @log_exceptions(logger=logger)
    async def _forward_task(
        self,
        old_task: asyncio.Task[None] | None,
        stream: rtc.VideoStream | rtc.AudioStream,
        track: rtc.RemoteTrack,
        publication: rtc.RemoteTrackPublication,
        participant: rtc.RemoteParticipant,
    ) -> None:
        if old_task:
            await aio.cancel_and_wait(old_task)

        extra = {
            "participant": participant.identity,
            "source": rtc.TrackSource.Name(publication.source),
        }
        logger.debug("start reading stream", extra=extra)
        async for event in stream:
            self._on_first_frame()
            if not self._attached:
                # drop frames if the stream is detached
                continue
            frame = cast(T, event.frame)
            self._process_frame(frame)
            await self._data_ch.send(frame)

        logger.debug("stream closed", extra=extra)

    def _process_frame(self, frame: T) -> None:
        """Hook for subclasses to process frames in-place before forwarding."""
        pass

    def _begin_track_wait(self, participant_identity: str) -> None:
        if self._track_wait_span_name is None:
            return
        self._track_wait_started_at = time.time()
        self._track_wait_span = tracer.start_span(
            self._track_wait_span_name,
            context=self._trace_context,
            attributes={trace_types.ATTR_PARTICIPANT_IDENTITY: participant_identity},
        )

    def _on_first_frame(self) -> None:
        span = self._track_wait_span
        if span is None or not span.is_recording():
            return
        now = time.time()
        span.add_event("first_frame", timestamp=int(now * 1_000_000_000))
        if self._track_wait_started_at is not None:
            span.set_attribute(
                trace_types.ATTR_FIRST_FRAME_DELAY, max(now - self._track_wait_started_at, 0.0)
            )
        self._end_track_wait()

    def _end_track_wait(self) -> None:
        span, self._track_wait_span = self._track_wait_span, None
        self._track_wait_started_at = None
        if span is not None and span.is_recording():
            span.end()

    @abstractmethod
    def _create_stream(
        self, track: rtc.RemoteTrack, participant: rtc.Participant
    ) -> rtc.VideoStream | rtc.AudioStream: ...

    def _update_processor(self, processor: rtc.FrameProcessor[T] | None) -> None:
        if processor is None and not self._processor_owned:
            return

        old = self._processor
        if old is not None and old is not processor and self._processor_owned:
            old._close()
        self._processor = processor
        self._processor_owned = processor is not None

    def _close_stream(self) -> None:
        stream = self._stream
        self._stream = None
        self._track = None
        self._publication = None
        if stream is not None:
            task = asyncio.create_task(stream.aclose())
            task.add_done_callback(self._tasks.discard)
            self._tasks.add(task)
        self._update_processor(None)

    def _on_track_available(
        self,
        track: rtc.RemoteTrack,
        publication: rtc.RemoteTrackPublication,
        participant: rtc.RemoteParticipant,
    ) -> bool:
        if (
            self._closed
            or self._participant_identity != participant.identity
            or publication.source not in self._accepted_sources
            or (self._track_sid is not None and publication.sid != self._track_sid)
            or (
                self._publication is not None
                and self._publication.sid == publication.sid
                and self._track is track
            )
        ):
            return False

        self._close_stream()
        self._stream = self._create_stream(track, participant)
        self._track = track
        self._publication = publication
        if (span := self._track_wait_span) is not None and span.is_recording():
            span.add_event(
                "track_subscribed",
                {
                    trace_types.ATTR_TRACK_SID: publication.sid,
                    trace_types.ATTR_TRACK_SOURCE: rtc.TrackSource.Name(publication.source),
                },
            )
        forward_task = asyncio.create_task(
            self._forward_task(self._forward_atask, self._stream, track, publication, participant)
        )
        self._forward_atask = forward_task
        self._forward_tasks.add(forward_task)
        forward_task.add_done_callback(self._forward_tasks.discard)
        return True

    def _on_track_unsubscribed(
        self,
        track: rtc.RemoteTrack,
        publication: rtc.RemoteTrackPublication,
        participant: rtc.RemoteParticipant,
    ) -> None:
        if (
            self._track is not track
            or not self._publication
            or self._publication.sid != publication.sid
            or participant.identity != self._participant_identity
        ):
            return

        self._close_stream()

        # Same-publication replacements arrive through track_subscribed.
        for candidate in participant.track_publications.values():
            if candidate.sid == publication.sid or candidate.track is None:
                continue
            if self._on_track_available(candidate.track, candidate, participant):
                return

    def _on_track_unavailable(
        self, publication: rtc.RemoteTrackPublication, participant: rtc.RemoteParticipant
    ) -> None:
        if (
            not self._publication
            or self._publication.sid != publication.sid
            or participant.identity != self._participant_identity
        ):
            return

        self._close_stream()

        # subscribe to the first available track
        for publication in participant.track_publications.values():
            if publication.track is None:
                continue
            if self._on_track_available(publication.track, publication, participant):
                return


class _ParticipantAudioInputStream(_ParticipantInputStream[rtc.AudioFrame], AudioInput):
    def __init__(
        self,
        room: rtc.Room,
        *,
        sample_rate: int,
        num_channels: int,
        noise_cancellation: rtc.NoiseCancellationOptions
        | NoiseCancellationSelector
        | rtc.FrameProcessor[rtc.AudioFrame]
        | None,
        auto_gain_control: bool = True,
        pre_connect_audio_handler: PreConnectAudioHandler | None,
        frame_size_ms: int = 50,
        track_source: rtc.TrackSource.ValueType
        | list[rtc.TrackSource.ValueType] = rtc.TrackSource.SOURCE_MICROPHONE,
    ) -> None:
        _ParticipantInputStream.__init__(
            self,
            room=room,
            track_source=track_source,
            processor=(
                noise_cancellation if isinstance(noise_cancellation, rtc.FrameProcessor) else None
            ),
        )
        AudioInput.__init__(self, label="RoomIO")
        self._track_wait_span_name = "wait_for_audio_track"
        if frame_size_ms <= 0:
            raise ValueError("frame_size_ms must be greater than 0")

        self._sample_rate = sample_rate
        self._num_channels = num_channels
        self._frame_size_ms = frame_size_ms
        self._noise_cancellation = noise_cancellation
        self._pre_connect_audio_handler = pre_connect_audio_handler
        self._pre_connect_audio_publications: set[tuple[str, str]] = set()
        self._apm: rtc.AudioProcessingModule | None = None
        if auto_gain_control:
            self._apm = rtc.AudioProcessingModule(auto_gain_control=True)

    @override
    def _process_frame(self, frame: rtc.AudioFrame) -> None:
        if self._apm is not None:
            self._apm.process_stream(frame)

    @override
    def _create_stream(self, track: rtc.Track, participant: rtc.Participant) -> rtc.AudioStream:
        noise_cancellation = self._noise_cancellation
        if callable(noise_cancellation):
            noise_cancellation = noise_cancellation(NoiseCancellationParams(participant, track))
            if isinstance(noise_cancellation, rtc.FrameProcessor):
                self._update_processor(noise_cancellation)
            else:
                self._update_processor(None)

        publication = participant.track_publications.get(track.sid)
        if (
            noise_cancellation is not None
            and publication is not None
            and AudioTrackFeature.TF_ENHANCED_NOISE_CANCELLATION in publication.audio_features
        ):
            logger.warning(
                "the participant's audio track already has enhanced noise cancellation enabled, "
                "applying noise cancellation again on the agent side degrades audio quality. "
                "disable it on either the client or the agent",
                extra={"participant": participant.identity, "track_id": track.sid},
            )

        return rtc.AudioStream.from_track(
            track=track,
            sample_rate=self._sample_rate,
            num_channels=self._num_channels,
            frame_size_ms=self._frame_size_ms,
            noise_cancellation=noise_cancellation,
            auto_close_noise_cancellation=False,
        )

    @override
    async def _forward_task(
        self,
        old_task: asyncio.Task[None] | None,
        stream: rtc.AudioStream,  # type: ignore[override]
        track: rtc.RemoteTrack,
        publication: rtc.RemoteTrackPublication,
        participant: rtc.RemoteParticipant,
    ) -> None:
        if old_task:
            await aio.cancel_and_wait(old_task)

        pre_connect_key = (participant.identity, publication.sid)
        if (
            self._pre_connect_audio_handler
            and AudioTrackFeature.TF_PRECONNECT_BUFFER in publication.audio_features
            and pre_connect_key not in self._pre_connect_audio_publications
        ):
            logging_extra = {
                "track_id": track.sid,
                "participant": participant.identity,
            }
            try:
                duration: float = 0
                frames = await self._pre_connect_audio_handler.wait_for_data(
                    logging_extra["track_id"]
                )
                self._pre_connect_audio_publications.add(pre_connect_key)
                for frame in self._resample_frames(self._apply_audio_processor(frames)):
                    if self._attached:
                        await self._data_ch.send(frame)
                        duration += frame.duration
                if frames:
                    logger.debug(
                        "pre-connect audio buffer pushed",
                        extra={"duration": duration, **logging_extra},
                    )
                    if (span := self._track_wait_span) is not None and span.is_recording():
                        span.add_event(
                            "pre_connect_audio",
                            {trace_types.ATTR_PRE_CONNECT_AUDIO_DURATION: duration},
                        )

            except asyncio.TimeoutError:
                self._pre_connect_audio_publications.add(pre_connect_key)
                logger.warning(
                    "timeout waiting for pre-connect audio buffer",
                    extra=logging_extra,
                )

            except Exception as e:
                self._pre_connect_audio_publications.add(pre_connect_key)
                logger.error(
                    "error reading pre-connect audio buffer", extra=logging_extra, exc_info=e
                )

        await super()._forward_task(None, stream, track, publication, participant)
        if self._attached:
            await self._data_ch.send(silence_frame(0.5, self._sample_rate, self._num_channels))

    def _resample_frames(self, frames: Iterable[rtc.AudioFrame]) -> Iterable[rtc.AudioFrame]:
        resampler: rtc.AudioResampler | None = None
        for frame in frames:
            if (
                not resampler
                and self._sample_rate is not None
                and frame.sample_rate != self._sample_rate
            ):
                resampler = rtc.AudioResampler(
                    input_rate=frame.sample_rate, output_rate=self._sample_rate
                )

            if resampler:
                yield from resampler.push(frame)
            else:
                yield frame

        if resampler:
            yield from resampler.flush()

    def _apply_audio_processor(self, frames: Iterable[rtc.AudioFrame]) -> Iterable[rtc.AudioFrame]:
        for frame in frames:
            if self._processor is not None:
                try:
                    yield self._processor._process(frame)
                except Exception as e:
                    logger.warning(
                        "error pre-processing audio frame: %s",
                        e,
                    )
                    yield frame
            else:
                yield frame


class _ParticipantVideoInputStream(_ParticipantInputStream[rtc.VideoFrame], VideoInput):
    def __init__(self, room: rtc.Room) -> None:
        _ParticipantInputStream.__init__(
            self,
            room=room,
            track_source=[
                rtc.TrackSource.SOURCE_CAMERA,
                rtc.TrackSource.SOURCE_SCREENSHARE,
            ],
        )
        VideoInput.__init__(self, label="RoomIO")

    @override
    def _create_stream(self, track: rtc.Track, participant: rtc.Participant) -> rtc.VideoStream:
        return rtc.VideoStream.from_track(track=track)
