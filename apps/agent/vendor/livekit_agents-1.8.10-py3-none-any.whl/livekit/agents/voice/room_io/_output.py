from __future__ import annotations

import asyncio
import json
import time

from google.protobuf.json_format import MessageToDict
from opentelemetry import context as otel_context

from livekit import rtc
from livekit.protocol.agent_pb import agent_session as agent_pb

from ... import utils
from ...log import logger
from ...telemetry import trace_types, tracer
from ...tts._provider_format import (
    ExpressiveTag,
    TranscriptMarkupStripper,
    expression_attribute,
    split_all_markup,
    strip_all_markup,
)
from ...types import (
    ATTRIBUTE_PUBLISH_ON_BEHALF,
    ATTRIBUTE_TRANSCRIPTION_FINAL,
    ATTRIBUTE_TRANSCRIPTION_LANGUAGE,
    ATTRIBUTE_TRANSCRIPTION_SEGMENT_ID,
    ATTRIBUTE_TRANSCRIPTION_TRACK_ID,
    CLIENT_PROTOCOL_TRANSCRIPTION_STREAMS,
    TOPIC_TRANSCRIPTION,
    TimedString,
)
from .. import io
from ..transcription import find_micro_track_id


class _ParticipantAudioOutput(io.AudioOutput):
    def __init__(
        self,
        room: rtc.Room,
        *,
        sample_rate: int,
        num_channels: int,
        track_publish_options: rtc.TrackPublishOptions,
        track_name: str = "roomio_audio",
    ) -> None:
        super().__init__(
            label="RoomIO",
            next_in_chain=None,
            sample_rate=sample_rate,
            capabilities=io.AudioOutputCapabilities(pause=True),
        )
        self._room = room
        self._track_name = track_name
        self._lock = asyncio.Lock()
        self._audio_source = rtc.AudioSource(sample_rate, num_channels, queue_size_ms=200)
        self._publish_options = track_publish_options
        self._publication: rtc.LocalTrackPublication | None = None
        self._subscribed_fut = asyncio.Future[None]()

        self._audio_buf = utils.aio.Chan[rtc.AudioFrame]()
        self._audio_bstream = utils.audio.AudioByteStream(
            sample_rate, num_channels, samples_per_channel=sample_rate // 20
        )
        # flushes the byte stream's tail before the source runs dry
        self._bstream_flush_timer: asyncio.TimerHandle | None = None

        self._flush_task: asyncio.Task[None] | None = None
        self._interrupted_event = asyncio.Event()
        self._forwarding_task: asyncio.Task[None] | None = None

        self._pushed_duration: float = 0.0
        self._source_pushed_duration: float = 0.0
        self._source_discarded_duration: float = 0.0
        self._interruption_generation = 0

        # the playhead sits at `_source_pushed_duration - queued_duration`; `_dry_at` is when
        # the source runs out if nothing more is pushed, which dates a run that has ended
        self._run_offset: float = 0.0
        self._dry_at: float | None = None

        self._playback_enabled = asyncio.Event()
        self._playback_enabled.set()
        # set only when _forward_audio is neither holding nor submitting a frame
        self._forwarding_idle = asyncio.Event()
        self._forwarding_idle.set()
        # playback_started fires once per segment; a mid-segment pause/resume does not re-arm this
        self._first_frame_event = asyncio.Event()

    async def _publish_track(self) -> None:
        async with self._lock:
            track = rtc.LocalAudioTrack.create_audio_track(self._track_name, self._audio_source)
            self._publication = await self._room.local_participant.publish_track(
                track, self._publish_options
            )
            await self._publication.wait_for_subscription()
            if not self._subscribed_fut.done():
                self._subscribed_fut.set_result(None)

    @property
    def subscribed(self) -> asyncio.Future[None]:
        return self._subscribed_fut

    async def set_track_name(self, track_name: str) -> None:
        """Publish under another name.

        A track's name is fixed once published, so a published track is replaced by a new one
        on the same audio source. Waits behind the first publish, which holds until the track
        is subscribed.
        """
        async with self._lock:
            if track_name == self._track_name:
                return

            self._track_name = track_name
            if self._publication is None:
                return

            await self._room.local_participant.unpublish_track(self._publication.sid)
            track = rtc.LocalAudioTrack.create_audio_track(self._track_name, self._audio_source)
            self._publication = await self._room.local_participant.publish_track(
                track, self._publish_options
            )

    async def start(self, *, trace_context: otel_context.Context | None = None) -> None:
        self._forwarding_task = asyncio.create_task(self._forward_audio())
        # detached: publishing spawns the track's tasks, which must not inherit this span
        with tracer.detached_span("publish_audio_output", context=trace_context) as span:
            await self._publish_track()
            if self._publication is not None:
                span.set_attribute(trace_types.ATTR_TRACK_SID, self._publication.sid)

    async def aclose(self) -> None:
        if self._bstream_flush_timer:
            self._bstream_flush_timer.cancel()
        if self._flush_task:
            await utils.aio.cancel_and_wait(self._flush_task)
        if self._forwarding_task:
            await utils.aio.cancel_and_wait(self._forwarding_task)

        await self._audio_source.aclose()

    async def capture_frame(self, frame: rtc.AudioFrame) -> None:
        await self._subscribed_fut

        await super().capture_frame(frame)

        if self._flush_task and not self._flush_task.done():
            logger.error("capture_frame called while flush is in progress")
            await self._flush_task

        for f in self._audio_bstream.push(frame.data):
            self._audio_buf.send_nowait(f)
            self._pushed_duration += f.duration
        self._arm_bstream_flush()

    def flush(self) -> None:
        super().flush()
        self._flush_bstream(force=True)

        if not self._pushed_duration:
            return

        if self._flush_task and not self._flush_task.done():
            # shouldn't happen if only one active speech handle at a time
            logger.error("flush called while playback is in progress")
            self._flush_task.cancel()

        self._flush_task = asyncio.create_task(self._wait_for_playout())

    def clear_buffer(self) -> None:
        if self._bstream_flush_timer:
            self._bstream_flush_timer.cancel()
            self._bstream_flush_timer = None
        self._audio_bstream.clear()

        if not self._pushed_duration:
            return

        # a detaching sink never reaches the playout wait, so the playhead is reported here
        self._report_run(
            offset=self._source_pushed_duration - self._audio_source.queued_duration,
            ended_at=time.time(),
        )
        self._interrupted_event.set()

    def pause(self) -> None:
        super().pause()
        self._playback_enabled.clear()
        if self._bstream_flush_timer:
            self._bstream_flush_timer.cancel()
            self._bstream_flush_timer = None
        # self._audio_source.clear_queue()

    def resume(self) -> None:
        super().resume()
        self._playback_enabled.set()
        self._arm_bstream_flush()

    def _arm_bstream_flush(self, *, margin: float = 0.02) -> None:
        # audio short of a frame waits for more, and the timer flushes it `margin` seconds before
        # the output runs dry; a paused output needs no frames, so no timer runs while paused
        if self._bstream_flush_timer:
            self._bstream_flush_timer.cancel()
            self._bstream_flush_timer = None
        if not self._playback_enabled.is_set():
            return
        queued = (
            self._audio_source.queued_duration
            + self._pushed_duration
            - self._source_pushed_duration
        )
        self._bstream_flush_timer = asyncio.get_running_loop().call_later(
            max(queued - margin, 0.0), self._flush_bstream
        )

    def _flush_bstream(self, *, force: bool = False) -> None:
        if self._bstream_flush_timer:
            self._bstream_flush_timer.cancel()
            self._bstream_flush_timer = None
        # nothing plays before the first frame, so one under 20 ms waits for more instead
        if not force and not self._pushed_duration and self._audio_bstream.buffered_duration < 0.02:
            return
        for f in self._audio_bstream.flush():
            self._audio_buf.send_nowait(f)
            self._pushed_duration += f.duration

    def _report_run(
        self, *, offset: float, ended_at: float, resumes_at: float | None = None
    ) -> None:
        """Report the open run, and begin the next past any audio that never played.

        The run covers ``[_run_offset, offset)`` and stopped at ``ended_at``. The next one
        starts at ``offset``, or at ``resumes_at`` when the audio between the two was
        discarded rather than played.
        """
        if self._dry_at is not None:
            # a run cannot outlast the audio the source held, however late the caller noticed
            ended_at = min(ended_at, self._dry_at)

        duration = offset - self._run_offset
        if duration > 0:
            self.on_playback_progressed(
                started_at=ended_at - duration, offset=self._run_offset, duration=duration
            )
        self._run_offset = offset if resumes_at is None else resumes_at
        self._dry_at = None

    async def _wait_for_playout(self) -> None:
        wait_for_interruption = asyncio.create_task(self._interrupted_event.wait())

        async def _wait_buffered_audio() -> None:
            while True:
                await self._forwarding_idle.wait()
                if self._audio_buf.empty():
                    break

                await self._playback_enabled.wait()
                await asyncio.sleep(0)

            await self._audio_source.wait_for_playout()

        wait_for_playout = asyncio.create_task(_wait_buffered_audio())
        await asyncio.wait(
            [wait_for_playout, wait_for_interruption],
            return_when=asyncio.FIRST_COMPLETED,
        )

        interrupted = self._interrupted_event.is_set()
        pushed_duration = max(
            self._source_pushed_duration - self._source_discarded_duration,
            0,
        )

        if interrupted:
            self._interruption_generation += 1
            queued_duration = self._audio_source.queued_duration
            while not self._audio_buf.empty():
                self._audio_buf.recv_nowait()

            pushed_duration = max(pushed_duration - queued_duration, 0)
            # the playhead stops where the cleared queue begins
            self._report_run(
                offset=self._source_pushed_duration - queued_duration, ended_at=time.time()
            )
            self._audio_source.clear_queue()
            wait_for_playout.cancel()
        else:
            wait_for_interruption.cancel()
            # the source drained, so everything pushed has played
            self._report_run(offset=self._source_pushed_duration, ended_at=time.time())

        self._run_offset = 0.0

        self._pushed_duration = 0
        self._source_pushed_duration = 0
        self._source_discarded_duration = 0
        self._interrupted_event.clear()
        self._first_frame_event.clear()
        self.on_playback_finished(playback_position=pushed_duration, interrupted=interrupted)

    async def _forward_audio(self) -> None:
        async for frame in self._audio_buf:
            interruption_generation = self._interruption_generation
            self._forwarding_idle.clear()
            try:
                if not self._playback_enabled.is_set():
                    queued = self._audio_source.queued_duration
                    self._source_discarded_duration += queued
                    # the dropped queue never plays, so the next run resumes past it
                    self._report_run(
                        offset=self._source_pushed_duration - queued,
                        ended_at=time.time(),
                        resumes_at=self._source_pushed_duration,
                    )
                    self._audio_source.clear_queue()
                    await self._playback_enabled.wait()
                    # drop a paused frame when its original segment was interrupted.
                    if interruption_generation != self._interruption_generation:
                        continue
                    # TODO(long): ignore frames from previous syllable

                if self._interrupted_event.is_set() or self._pushed_duration == 0:
                    if self._interrupted_event.is_set() and self._flush_task:
                        await self._flush_task

                    # ignore frames if interrupted
                    continue

                if not self._first_frame_event.is_set():
                    self._first_frame_event.set()
                    self.on_playback_started(created_at=time.time())
                if self._dry_at is not None and time.time() >= self._dry_at:
                    # the source ran out before this frame arrived
                    self._report_run(offset=self._source_pushed_duration, ended_at=self._dry_at)

                self._source_pushed_duration += frame.duration
                # dated at submission: the source plays on through the await, so a stalled
                # event loop can return from it after the source has drained
                dry_at = time.time() + self._audio_source.queued_duration + frame.duration
                await self._audio_source.capture_frame(frame)
                self._dry_at = dry_at
            finally:
                self._forwarding_idle.set()


def _legacy_transcription_needed(room: rtc.Room) -> bool:
    """True while some remote participant may still rely on the deprecated
    ``rtc.Transcription`` data packet.

    ``publish_transcription`` has no destination parameter, so this is all-or-nothing for the
    room: the packet is dropped only once every considered participant advertises
    ``client_protocol >= CLIENT_PROTOCOL_TRANSCRIPTION_STREAMS``, meaning it rebuilds
    transcription events from the ``lk.transcription`` stream channel instead.

    The client protocol is read from the private ``_info``, because livekit-rtc exposes no
    public property for it. There is no fallback: the field is ``required`` in the FFI
    protobuf, and ``livekit`` is pinned to an exact version, so it is always present. A
    rename must fail loudly here rather than report 0 for every participant, which would
    silently keep legacy publishing on for good.

    Only STANDARD participants -- user-created client SDK instances -- are considered. SIP,
    INGRESS, AGENT (including avatar workers), CONNECTOR and BRIDGE participants never render
    legacy transcripts, so their client protocol tells us nothing about whether the legacy
    packet is still necessary. Counting them would also keep legacy publishing alive in every
    telephony room for good: the Go SDK does not send a client protocol at all, so SIP and
    INGRESS participants report 0 permanently. EGRESS participants join hidden and never
    reach ``remote_participants``.
    """
    local_identity = room.local_participant.identity
    return any(
        p.kind == rtc.ParticipantKind.PARTICIPANT_KIND_STANDARD
        and p._info.client_protocol < CLIENT_PROTOCOL_TRANSCRIPTION_STREAMS
        # not an avatar worker of ours that joined as STANDARD rather than AGENT
        and p.attributes.get(ATTRIBUTE_PUBLISH_ON_BEHALF) != local_identity
        for p in room.remote_participants.values()
    )


class _ParticipantLegacyTranscriptionOutput:
    def __init__(
        self,
        room: rtc.Room,
        *,
        is_delta_stream: bool = True,
        participant: rtc.Participant | str | None = None,
        track: str | None = None,
    ):
        self._room, self._is_delta_stream = room, is_delta_stream
        # the last status written to the log, so only transitions are logged. This never
        # takes part in the decision itself.
        self._legacy_status_logged: bool | None = None
        # when set, the transcript is stamped with this track rather than whichever
        # microphone track the linked participant happens to publish
        self._pinned_track_id: str | None = track
        self._track_id: str | None = track
        self._participant_identity: str | None = None

        # identity of the participant that on behalf of the current participant
        self._represented_by: str | None = None
        # stamped on each segment, so a track carrying more than one language tells them apart
        self._language = ""

        self._room.on("track_published", self._on_track_published)
        self._room.on("local_track_published", self._on_local_track_published)
        self._flush_task: asyncio.Task[None] | None = None
        self._closed = False

        self._reset_state()
        self.set_participant(participant)

    def set_participant(
        self,
        participant: rtc.Participant | str | None,
    ) -> None:
        identity = participant.identity if isinstance(participant, rtc.Participant) else participant
        if identity != self._participant_identity:
            # closed under the identity that carried it, including when the link is cleared
            self.flush()

        self._participant_identity = identity
        self._represented_by = self._participant_identity
        if self._participant_identity is None:
            return

        if self._pinned_track_id is not None:
            self.flush()
            self._reset_state()
            return

        # find track id from existing participants
        if self._participant_identity == self._room.local_participant.identity:
            for local_track in self._room.local_participant.track_publications.values():
                self._on_local_track_published(local_track, local_track.track)
                if self._track_id is not None:
                    break
        if not self._track_id:
            for p in self._room.remote_participants.values():
                if not self._is_local_proxy_participant(p):
                    continue
                for remote_track in p.track_publications.values():
                    self._on_track_published(remote_track, p)
                    if self._track_id is not None:
                        break

        self.flush()
        self._reset_state()

    def set_track(self, track_sid: str | None) -> None:
        """Stamp what follows with another track, closing the segment stamped with the last.

        ``None`` restores resolving the track from the linked participant.
        """
        if self._pinned_track_id == track_sid:
            return

        self._pinned_track_id = track_sid
        if track_sid is None:
            # re-resolve from the participant
            self.set_participant(self._participant_identity)
            return

        self.flush()
        self._track_id = track_sid
        self._reset_state()

    def set_attributes(self, attributes: dict[str, str]) -> None:
        """Take the language from the attributes; a transcription carries no others."""
        language = attributes.get(ATTRIBUTE_TRANSCRIPTION_LANGUAGE, "")
        if language == self._language:
            return

        if self._is_delta_stream:
            # a segment is in one language, so a change closes the one open under the old
            self.flush()
        self._language = language

    def _reset_state(self) -> None:
        self._current_id = utils.shortuuid("SG_")
        self._capturing = False
        self._pushed_text = ""

    @utils.log_exceptions(logger=logger)
    async def capture_text(self, text: str) -> None:
        if self._participant_identity is None or self._track_id is None:
            return

        if self._flush_task and not self._flush_task.done():
            await self._flush_task

        if not self._capturing:
            self._reset_state()
            self._capturing = True

        if self._is_delta_stream:
            self._pushed_text += text
        else:
            self._pushed_text = text

        # _pushed_text keeps the raw text (markup intact); publish the visible text only.
        # Stripping the whole accumulation each time avoids partial-tag edge cases; the
        # expression is dropped here — the deprecated rtc Transcription API has no
        # attribute channel (the stream-based output carries lk.expression instead).
        clean_text = strip_all_markup(self._pushed_text)
        await self._publish_transcription(self._current_id, clean_text, final=False)

    @utils.log_exceptions(logger=logger)
    def flush(self) -> None:
        if self._participant_identity is None or self._track_id is None or not self._capturing:
            return

        clean_text = strip_all_markup(self._pushed_text)
        # snapshot: the flush runs later, and a track or participant switch in between
        # would otherwise stamp this segment's last packet with the new one
        self._flush_task = asyncio.create_task(
            self._publish_transcription(
                self._current_id,
                clean_text,
                final=True,
                participant_identity=self._participant_identity,
                track_id=self._track_id,
                represented_by=self._represented_by,
                language=self._language,
            )
        )
        self._reset_state()

    async def aclose(self) -> None:
        if self._closed:
            return

        self._closed = True
        self._room.off("track_published", self._on_track_published)
        self._room.off("local_track_published", self._on_local_track_published)
        if self._flush_task:
            await self._flush_task

    def _should_publish(self) -> bool:
        needed = _legacy_transcription_needed(self._room)
        if needed != self._legacy_status_logged:
            self._legacy_status_logged = needed
            logger.debug(
                "legacy transcription publishing %s",
                "enabled" if needed else "disabled",
                extra={"participant": self._participant_identity},
            )

        return needed

    async def _publish_transcription(
        self,
        id: str,
        text: str,
        final: bool,
        *,
        participant_identity: str | None = None,
        track_id: str | None = None,
        represented_by: str | None = None,
        language: str | None = None,
    ) -> None:
        """``participant_identity``/``track_id``/``represented_by``/``language`` pin the
        packet to the segment it closes; without them the live fields are used, which a switch
        mid-segment has already moved on."""
        participant_identity = participant_identity or self._participant_identity
        track_id = track_id or self._track_id
        represented_by = represented_by or self._represented_by
        language = language if language is not None else self._language
        if participant_identity is None or track_id is None:
            return

        # Gate here, not in capture_text: every legacy publish carries the whole accumulated
        # segment under a stable id, so _pushed_text/_current_id must stay warm. A legacy
        # client that joins mid-segment then gets the complete segment on the very next
        # publish, and a client that only ever sees the final=True packet still gets a
        # complete, correctly-closed segment.
        if not self._should_publish():
            return

        transcription = rtc.Transcription(
            participant_identity=represented_by or participant_identity,
            track_sid=track_id,
            segments=[
                rtc.TranscriptionSegment(
                    id=id,
                    text=text,
                    start_time=0,
                    end_time=0,
                    final=final,
                    language=language,
                )
            ],
        )
        try:
            if self._room.isconnected():
                await self._room.local_participant.publish_transcription(transcription)
        except Exception as e:
            if self._room.isconnected():
                logger.warning("failed to publish agent transcription to room: %s", e)

    def _on_track_published(
        self, track: rtc.RemoteTrackPublication, participant: rtc.RemoteParticipant
    ) -> None:
        if (
            not self._is_local_proxy_participant(participant)
            or track.source != rtc.TrackSource.SOURCE_MICROPHONE
        ):
            return

        if self._pinned_track_id is not None:
            return

        self._track_id = track.sid
        self._represented_by = participant.identity

    def _on_local_track_published(
        self, track: rtc.LocalTrackPublication, _: rtc.Track | None
    ) -> None:
        if (
            self._participant_identity is None
            or self._participant_identity != self._room.local_participant.identity
            or track.source != rtc.TrackSource.SOURCE_MICROPHONE
        ):
            return

        if self._pinned_track_id is not None:
            return

        self._track_id = track.sid

    def _is_local_proxy_participant(self, participant: rtc.Participant) -> bool:
        if not self._participant_identity:
            return False

        if participant.identity == self._participant_identity or (
            (on_behalf := participant.attributes.get(ATTRIBUTE_PUBLISH_ON_BEHALF)) is not None
            and on_behalf == self._participant_identity
        ):
            return True

        return False


class _ParticipantStreamTranscriptionOutput:
    def __init__(
        self,
        room: rtc.Room,
        *,
        is_delta_stream: bool = True,
        participant: rtc.Participant | str | None = None,
        attributes: dict[str, str] | None = None,
        json_format: bool = False,
        track: str | None = None,
    ):
        self._room, self._is_delta_stream = room, is_delta_stream
        # see _ParticipantLegacyTranscriptionOutput
        self._pinned_track_id: str | None = track
        self._track_id: str | None = track
        self._participant_identity: str | None = None
        self._additional_attributes = attributes or {}
        self._writer: rtc.TextStreamWriter | None = None
        self._json_format = json_format

        self._room.on("track_published", self._on_track_published)
        self._room.on("local_track_published", self._on_local_track_published)
        self._flush_atask: asyncio.Task[None] | None = None
        self._closed = False

        self._reset_state()
        self.set_participant(participant)

    def set_participant(
        self,
        participant: rtc.Participant | str | None,
    ) -> None:
        identity = participant.identity if isinstance(participant, rtc.Participant) else participant
        if identity != self._participant_identity:
            # closed under the identity that carried it, including when the link is cleared
            self.flush()

        self._participant_identity = identity
        if self._participant_identity is None:
            return

        if self._pinned_track_id is None:
            try:
                self._track_id = find_micro_track_id(self._room, self._participant_identity)
            except ValueError:
                # track id is optional for TextStream when audio is not published
                self._track_id = None

        self.flush()
        self._reset_state()

    def set_track(self, track_sid: str | None) -> None:
        """Stamp what follows with another track, closing the segment stamped with the last.

        ``None`` restores resolving the track from the linked participant.
        """
        if self._pinned_track_id == track_sid:
            return

        self._pinned_track_id = track_sid
        if track_sid is None:
            # re-resolve from the participant
            self.set_participant(self._participant_identity)
            return

        self.flush()
        self._track_id = track_sid
        self._reset_state()

    def _reset_state(self) -> None:
        self._current_id = utils.shortuuid("SG_")
        self._capturing = False
        self._latest_text = ""
        # per-segment markup stripping: delta streams strip incrementally (buffering a tag
        # split across chunks); non-delta streams re-strip the full text each time and keep
        # the latest tags here for the expression attribute (see TranscriptMarkupStripper)
        self._stripper = TranscriptMarkupStripper()
        self._segment_tags: list[ExpressiveTag] = []

    def set_attributes(self, attributes: dict[str, str]) -> None:
        """Replace the extra attributes stamped on segments from here on.

        A delta segment's header is written when it opens, so a change closes the open one
        under its old attributes. A whole-text segment is republished on every capture and
        simply carries the new ones.
        """
        attributes = dict(attributes)
        if attributes == self._additional_attributes:
            return

        if self._is_delta_stream:
            self.flush()
        self._additional_attributes = attributes

    def _encode(self, clean_text: str, timing_src: str | None = None) -> str:
        """Wrap visible text for the wire (JSON TimedString when json_format, else raw)."""
        if not self._json_format:
            return clean_text

        ts_pb = agent_pb.TimedString(text=clean_text)
        if isinstance(timing_src, TimedString):
            if utils.is_given(timing_src.start_time):
                ts_pb.start_time = timing_src.start_time
            if utils.is_given(timing_src.end_time):
                ts_pb.end_time = timing_src.end_time
            if utils.is_given(timing_src.confidence):
                ts_pb.confidence = timing_src.confidence
            if utils.is_given(timing_src.start_time_offset):
                ts_pb.start_time_offset = timing_src.start_time_offset
        return json.dumps(MessageToDict(ts_pb, preserving_proto_field_name=True)) + "\n"

    async def _create_text_writer(
        self,
        attributes: dict[str, str] | None = None,
        extra: dict[str, str] | None = None,
        sender_identity: str | None = None,
        additional_attributes: dict[str, str] | None = None,
    ) -> rtc.TextStreamWriter:
        sender_identity = sender_identity or self._participant_identity
        assert sender_identity is not None, "participant_identity is not set"

        if not attributes:
            attributes = {
                ATTRIBUTE_TRANSCRIPTION_FINAL: "false",
            }
            if self._track_id:
                attributes[ATTRIBUTE_TRANSCRIPTION_TRACK_ID] = self._track_id
        attributes[ATTRIBUTE_TRANSCRIPTION_SEGMENT_ID] = self._current_id
        # overlaid rather than replacing, so the caller can add a key without
        # dropping the transcription attributes the protocol requires
        if extra:
            attributes.update(extra)

        if additional_attributes is None:
            additional_attributes = self._additional_attributes
        for key, val in additional_attributes.items():
            if key not in attributes:
                attributes[key] = val

        return await self._room.local_participant.stream_text(
            topic=TOPIC_TRANSCRIPTION,
            sender_identity=sender_identity,
            attributes=attributes,
        )

    @utils.log_exceptions(logger=logger)
    async def capture_text(self, text: str) -> None:
        if self._participant_identity is None:
            return

        if self._flush_atask and not self._flush_atask.done():
            await self._flush_atask

        if not self._capturing:
            self._reset_state()
            self._capturing = True

        # the raw text (expressive markup intact) arrives here; publish only the visible
        # text. Skip a chunk that strips to nothing (a partial tag still buffering, or a
        # markup-only token) so the transcript cadence isn't disturbed.
        if self._is_delta_stream:
            clean_text = self._stripper.push(text)
        else:
            clean_text, self._segment_tags = split_all_markup(text)
        if not clean_text:
            return

        payload = self._encode(clean_text, text)
        self._latest_text = payload

        try:
            if self._room.isconnected():
                if self._is_delta_stream:  # reuse the existing writer
                    if self._writer is None:
                        segment_id, track_id = self._current_id, self._track_id
                        additional_attributes = dict(self._additional_attributes)
                        # the leading expression is stripped before any visible text, so it is
                        # already known here. Put it on the opening header as well as the closing
                        # one, or a frontend can't colour the turn until the agent stops talking.
                        writer = await self._create_text_writer(
                            extra=expression_attribute(self._stripper.tags)
                        )
                        if self._current_id != segment_id or not self._capturing:
                            # the segment was closed while its stream opened, so the flush had
                            # no stream to close; this text is the segment's, and closes it
                            await writer.write(payload)
                            await writer.aclose(
                                attributes={
                                    ATTRIBUTE_TRANSCRIPTION_FINAL: "true",
                                    **(
                                        {ATTRIBUTE_TRANSCRIPTION_TRACK_ID: track_id}
                                        if track_id
                                        else {}
                                    ),
                                    **additional_attributes,
                                }
                            )
                            return

                        self._writer = writer

                    await self._writer.write(payload)
                else:  # always create a new writer
                    tmp_writer = await self._create_text_writer()
                    await tmp_writer.write(payload)
                    await tmp_writer.aclose()
        except Exception as e:
            logger.warning("failed to publish agent transcription to room: %s", e)

    async def _flush_task(
        self,
        writer: rtc.TextStreamWriter | None,
        extra_attributes: dict[str, str] | None = None,
        pending_text: str = "",
        track_id: str | None = None,
        sender_identity: str | None = None,
        additional_attributes: dict[str, str] | None = None,
    ) -> None:
        """``track_id``/``sender_identity``/``additional_attributes`` belong to the segment
        being closed, taken when the flush was scheduled rather than read now, which a switch
        has already moved on."""
        attributes = {ATTRIBUTE_TRANSCRIPTION_FINAL: "true"}
        if track_id:
            attributes[ATTRIBUTE_TRANSCRIPTION_TRACK_ID] = track_id
        for key, val in (extra_attributes or {}).items():
            attributes.setdefault(key, val)
        for key, val in (additional_attributes or {}).items():
            attributes.setdefault(key, val)

        try:
            if self._room.isconnected():
                if self._is_delta_stream:
                    if writer:
                        if pending_text:  # visible text left in the strip buffer
                            await writer.write(pending_text)
                        await writer.aclose(attributes=attributes)
                else:
                    tmp_writer = await self._create_text_writer(
                        attributes=attributes,
                        sender_identity=sender_identity,
                        additional_attributes=additional_attributes,
                    )
                    await tmp_writer.write(self._latest_text)
                    await tmp_writer.aclose()
        except Exception as e:
            logger.warning("failed to publish agent transcription to room: %s", e)

    def flush(self) -> None:
        # only emit on a segment that captured text (keeps lk.transcription cadence intact).
        # The leading expression the sinks stripped rides along on the closing header as the
        # lk.expression attribute.
        if self._participant_identity is None or not self._capturing:
            return

        self._capturing = False
        curr_writer = self._writer
        self._writer = None

        if self._is_delta_stream:
            remaining = self._stripper.flush()
            tags = self._stripper.tags
        else:
            remaining = ""
            tags = self._segment_tags

        pending_text = self._encode(remaining) if remaining else ""
        # snapshot: see _ParticipantLegacyTranscriptionOutput.flush
        self._flush_atask = asyncio.create_task(
            self._flush_task(
                curr_writer,
                expression_attribute(tags),
                pending_text,
                track_id=self._track_id,
                sender_identity=self._participant_identity,
                additional_attributes=dict(self._additional_attributes),
            )
        )

    async def aclose(self) -> None:
        if self._closed:
            return

        self._closed = True
        self._room.off("track_published", self._on_track_published)
        self._room.off("local_track_published", self._on_local_track_published)

        if self._flush_atask:
            await self._flush_atask

        if self._writer:
            writer = self._writer
            self._writer = None
            await writer.aclose()

    def _on_track_published(
        self, track: rtc.RemoteTrackPublication, participant: rtc.RemoteParticipant
    ) -> None:
        if (
            self._participant_identity is None
            or participant.identity != self._participant_identity
            or track.source != rtc.TrackSource.SOURCE_MICROPHONE
        ):
            return

        if self._pinned_track_id is not None:
            return

        self._track_id = track.sid

    def _on_local_track_published(self, track: rtc.LocalTrackPublication, _: rtc.Track) -> None:
        if (
            self._participant_identity is None
            or self._participant_identity != self._room.local_participant.identity
            or track.source != rtc.TrackSource.SOURCE_MICROPHONE
        ):
            return

        if self._pinned_track_id is not None:
            return

        self._track_id = track.sid


# Keep this utility private for now
class _ParticipantTranscriptionOutput(io.TextOutput):
    def __init__(
        self,
        *,
        room: rtc.Room,
        is_delta_stream: bool = True,
        participant: rtc.Participant | str | None = None,
        next_in_chain: io.TextOutput | None = None,
        json_format: bool = False,
        track: str | None = None,
    ) -> None:
        """``track`` stamps the transcript with that publication instead of resolving the
        linked participant's microphone track, so a transcript can be attributed to a track
        the participant is not publishing as their microphone."""
        super().__init__(label="RoomIO", next_in_chain=next_in_chain)

        self.__outputs: list[
            _ParticipantLegacyTranscriptionOutput | _ParticipantStreamTranscriptionOutput
        ] = [
            _ParticipantLegacyTranscriptionOutput(
                room=room,
                is_delta_stream=is_delta_stream,
                participant=participant,
                track=track,
            ),
            _ParticipantStreamTranscriptionOutput(
                room=room,
                is_delta_stream=is_delta_stream,
                participant=participant,
                json_format=json_format,
                track=track,
            ),
        ]
        self.__closed = False

    def set_participant(self, participant: rtc.Participant | str | None) -> None:
        for source in self.__outputs:
            source.set_participant(participant)

    def set_track(self, track_sid: str | None) -> None:
        for source in self.__outputs:
            source.set_track(track_sid)

    def set_attributes(self, attributes: dict[str, str]) -> None:
        """Replace the extra attributes stamped on segments from here on.

        A text stream carries them all; a legacy transcription only has a field for the
        language, which it takes from ``lk.transcription_language``.
        """
        for source in self.__outputs:
            source.set_attributes(attributes)

    async def capture_text(self, text: str) -> None:
        await asyncio.gather(*[sink.capture_text(text) for sink in self.__outputs])

        if self.next_in_chain:
            await self.next_in_chain.capture_text(text)

    def flush(self) -> None:
        for source in self.__outputs:
            source.flush()

        if self.next_in_chain:
            self.next_in_chain.flush()

    async def aclose(self) -> None:
        if self.__closed:
            return

        self.__closed = True
        await asyncio.gather(*[source.aclose() for source in self.__outputs])
