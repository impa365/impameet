from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, TypeAlias, cast

import httpx2 as httpx
import openai
from openai.types.chat import (
    ChatCompletionChunk,
    ChatCompletionMessageParam,
    ChatCompletionPredictionContentParam,
    ChatCompletionToolChoiceOptionParam,
    ChatCompletionToolParam,
    completion_create_params,
)
from openai.types.chat.chat_completion_chunk import Choice
from openai.types.shared.reasoning import Reasoning
from openai.types.shared.reasoning_effort import ReasoningEffort
from openai.types.shared_params import Metadata, Reasoning as ReasoningParam
from typing_extensions import TypedDict

from .. import llm
from .._exceptions import APIConnectionError, APIStatusError, APITimeoutError
from ..llm import ToolChoice, utils as llm_utils
from ..llm.chat_context import ChatContext
from ..llm.tool_context import Tool
from ..log import logger
from ..types import (
    DEFAULT_API_CONNECT_OPTIONS,
    NOT_GIVEN,
    APIConnectOptions,
    NotGiven,
    NotGivenOr,
)
from ..utils import is_given, resolve_env_int
from ._realtime_models import is_duplex_model, is_realtime_model
from ._utils import (
    HEADER_INFERENCE_PROVIDER,
    InferenceClass,
    create_access_token,
    extract_quota_usage,
    get_default_inference_url,
    get_inference_headers,
    resolve_credentials,
)

lk_oai_debug = resolve_env_int("LK_OPENAI_DEBUG")

# Reasoning models don't support sampling parameters.
# See: https://platform.openai.com/docs/guides/reasoning
_REASONING_UNSUPPORTED_PARAMS: set[str] = {
    "temperature",
    "top_p",
    "presence_penalty",
    "frequency_penalty",
    "logit_bias",
    "logprobs",
    "top_logprobs",
    "n",
}

# xAI reasoning models only restrict presence_penalty, frequency_penalty, stop.
# They still support temperature and top_p.
_XAI_REASONING_UNSUPPORTED_PARAMS: set[str] = {
    "presence_penalty",
    "frequency_penalty",
    "stop",
}

# gpt-6 rejects these while it reasons, and accepts every one of them again at
# reasoning_effort "none" (probed 2026-10-20 on gpt-6.1-sol over both the chat
# and responses transports, gpt-6-sol and gpt-6-luna). It differs from the
# o-series/gpt-5 set in two ways: n is accepted while reasoning so it is absent
# here, and stop is rejected so it is added. seed is in neither set.
_GPT6_REASONING_UNSUPPORTED_PARAMS: set[str] = {
    "temperature",
    "top_p",
    "presence_penalty",
    "frequency_penalty",
    "logit_bias",
    "logprobs",
    "top_logprobs",
    "stop",
}

# Model prefix -> set of param names that should be dropped
_UNSUPPORTED_PARAMS: dict[str, set[str]] = {
    "o1": _REASONING_UNSUPPORTED_PARAMS,
    "o3": _REASONING_UNSUPPORTED_PARAMS,
    "o4": _REASONING_UNSUPPORTED_PARAMS,
    "gpt-5": _REASONING_UNSUPPORTED_PARAMS,
    "gpt-6": _GPT6_REASONING_UNSUPPORTED_PARAMS,
    "grok-4-1-fast-reasoning": _XAI_REASONING_UNSUPPORTED_PARAMS,
    "grok-4.20-0309-reasoning": _XAI_REASONING_UNSUPPORTED_PARAMS,
    "grok-4.20-multi-agent": _XAI_REASONING_UNSUPPORTED_PARAMS,
}

# temperature/top_p are accepted by gpt-5.1+ only at reasoning_effort
# "none"; see the note in drop_unsupported_params.
_SAMPLING_PARAMS: set[str] = {"temperature", "top_p"}

# Params OpenAI accepts again at reasoning_effort "none", by model prefix. The
# keys mirror the prefixes in _UNSUPPORTED_PARAMS, and these sets are read-only:
# drop_unsupported_params subtracts from them, never mutates them.
_KEPT_AT_EFFORT_NONE: dict[str, set[str]] = {
    "gpt-5": _SAMPLING_PARAMS,
    "gpt-6": _GPT6_REASONING_UNSUPPORTED_PARAMS,
}

# models that don't support reasoning_effort when function tools are present
_REASONING_EFFORT_TOOL_INCOMPATIBLE_PREFIXES: set[str] = {"gpt-5.2", "gpt-5.4"}

_MODEL_THINK_TAGS = {
    "google/gemma-4-31b-it": ("<|channel>thought", "<channel|>"),
}


def drop_unsupported_params(
    model: str, params: dict[str, Any], tools: list[Any] | None = None
) -> dict[str, Any]:
    """Remove parameters that are not supported by the given model.

    Strips any provider prefix (e.g. ``openai/o3-pro`` -> ``o3-pro``) before
    matching against known model prefixes.
    """
    model_name = model.split("/")[-1] if "/" in model else model
    if tools and any(
        model_name.startswith(p) for p in _REASONING_EFFORT_TOOL_INCOMPATIBLE_PREFIXES
    ):
        params = {k: v for k, v in params.items() if k != "reasoning_effort"}
    for prefix, unsupported in _UNSUPPORTED_PARAMS.items():
        if model_name.startswith(prefix):
            kept_at_none = _KEPT_AT_EFFORT_NONE.get(prefix)
            if (
                kept_at_none
                and min_reasoning_effort(model_name) == "none"
                and _reasoning_effort_is_none(params)
            ):
                # These models accept their sampling params again at effort
                # "none" (their lowest supported effort). Verified against the
                # API on gpt-5.6-luna (2026-10): "none" + temperature -> 200,
                # "low" + temperature -> 400, on both the chat completions and
                # responses APIs; re-verified for gpt-6 on gpt-6.1-sol,
                # gpt-6-sol and gpt-6-luna (2026-10-20). The reasoning guide no
                # longer documents this restriction. Applies only to models in
                # _MIN_REASONING_EFFORT whose floor is "none" — new gpt-5.1+
                # and gpt-6 models must be added there or the params stay
                # stripped.
                unsupported = unsupported - kept_at_none
            params = {k: v for k, v in params.items() if k not in unsupported}
            break
    return params


def _reasoning_effort_is_none(params: dict[str, Any]) -> bool:
    # chat completions sends effort as params["reasoning_effort"]; the
    # responses LLMs send it as params["reasoning"], an openai Reasoning
    # object or a plain dict
    if params.get("reasoning_effort") == "none":
        return True
    reasoning = params.get("reasoning")
    if isinstance(reasoning, dict):
        return reasoning.get("effort") == "none"
    return getattr(reasoning, "effort", None) == "none"


# lowest supported reasoning effort per model; "none" requires gpt-5.1+
_MIN_REASONING_EFFORT: dict[str, ReasoningEffort] = {
    "gpt-5.1": "none",
    "gpt-5.2": "none",
    "gpt-5.4": "none",
    "gpt-5.4-mini": "none",
    "gpt-5.4-nano": "none",
    "gpt-5.5": "none",
    "gpt-5.6-luna": "none",
    "gpt-5.6-sol": "none",
    "gpt-5.6-terra": "none",
    "gpt-6-luna": "none",
    "gpt-6-sol": "none",
    "gpt-6.1-sol": "low",
    "gpt-5": "minimal",
    "gpt-5-mini": "minimal",
    "gpt-5-nano": "minimal",
}


_GPT_VERSION = re.compile(r"^gpt-(\d+)(?:\.(\d+))?")
_BREAKPOINT_FORMATS = ("openai", "openai.responses")


def supports_prompt_cache_breakpoints(model: str) -> bool:
    """Whether an OpenAI model accepts ``prompt_cache_breakpoint`` content parts.

    OpenAI supports breakpoints on GPT-5.6 and later, so any ``gpt-<major>.<minor>``
    at or above 5.6 qualifies, future families such as gpt-6 included. Every other
    name is out: gpt-oss, the o-series, the chat-latest aliases, and models from
    other providers (``google/...``). Older models answer HTTP 400 to the field.
    """
    provider, _, name = model.lower().rpartition("/")
    if provider not in ("", "openai"):
        return False
    version = _GPT_VERSION.match(name)
    if version is None:
        return False
    return (int(version.group(1)), int(version.group(2) or 0)) >= (5, 6)


def min_reasoning_effort(model: str) -> ReasoningEffort | None:
    """Lowest reasoning effort the model supports, or None if the model has no
    reasoning-effort control.

    Strips any provider prefix (e.g. ``openai/gpt-5`` -> ``gpt-5``) before matching.
    """
    return _MIN_REASONING_EFFORT.get(model.split("/")[-1])


ReasoningSetting: TypeAlias = ReasoningEffort | Reasoning | ReasoningParam
"""A reasoning effort such as ``"low"``, or a Responses ``reasoning`` object such as
``{"effort": "low", "summary": "auto"}``."""

# least to most; the values of ReasoningEffort
_EFFORT_ORDER: tuple[str, ...] = ("none", "minimal", "low", "medium", "high", "xhigh", "max")


def _reasoning_fields(reasoning: ReasoningSetting) -> dict[str, Any]:
    """Return a reasoning setting as Responses ``reasoning`` fields.

    A bare effort becomes ``{"effort": ...}`` and ``None`` becomes ``{}``. Unset fields are
    dropped, since the Responses API rejects explicit nulls on its enum fields.
    """
    if reasoning is None:
        return {}
    if isinstance(reasoning, str):
        return {"effort": reasoning}
    if isinstance(reasoning, Reasoning):
        return reasoning.model_dump(exclude_none=True)
    return {k: v for k, v in reasoning.items() if v is not None}


def _to_reasoning_effort(reasoning: ReasoningSetting) -> ReasoningEffort:
    """Return the effort of a reasoning setting, for the chat completions API.

    Raises:
        ValueError: The setting has a field other than the effort, such as ``summary``,
            which chat completions has no place for.
    """
    fields = _reasoning_fields(reasoning)
    unsupported = sorted(set(fields) - {"effort"})
    if unsupported:
        raise ValueError(
            f"chat completions takes only a reasoning effort, not {', '.join(unsupported)}; "
            "use inference.responses.LLM for those"
        )
    return cast(ReasoningEffort, fields.get("effort"))


def _reject_responses_reasoning(kwargs: Mapping[str, Any]) -> None:
    """Reject the Responses ``reasoning`` field in chat completions ``extra_kwargs``.

    The openai SDK has no such chat completions argument: its ``TypeError`` reached the
    caller as a connection error, after every retry.

    Raises:
        ValueError: ``kwargs`` has a ``reasoning`` key.
    """
    if "reasoning" in kwargs:
        raise ValueError(
            "extra_kwargs['reasoning'] is a Responses API field; inference.LLM takes "
            "reasoning= or extra_kwargs['reasoning_effort']"
        )


def _warn_if_below_min_effort(model: str, effort: str | None) -> None:
    """Log a warning when ``effort`` is below the lowest the model supports.

    Only warns, and never changes the effort: :func:`min_reasoning_effort` can lag
    behind the API, so the request is still sent as configured.
    """
    lowest = min_reasoning_effort(model)
    if effort not in _EFFORT_ORDER or lowest is None:
        return
    if _EFFORT_ORDER.index(effort) < _EFFORT_ORDER.index(lowest):
        logger.warning(
            "reasoning effort is below the lowest the model supports, the API may reject it",
            extra={"model": model, "effort": effort, "lowest": lowest},
        )


OpenAIModels = Literal[
    "openai/gpt-4o",
    "openai/gpt-4o-mini",
    "openai/gpt-4.1",
    "openai/gpt-4.1-mini",
    "openai/gpt-4.1-nano",
    "openai/gpt-5",
    "openai/gpt-5-mini",
    "openai/gpt-5-nano",
    "openai/gpt-5.1",
    "openai/gpt-5.1-chat-latest",
    "openai/gpt-5.2",
    "openai/gpt-5.2-chat-latest",
    "openai/gpt-5.3-chat-latest",
    "openai/gpt-5.4",
    "openai/gpt-5.4-mini",
    "openai/gpt-5.4-nano",
    "openai/gpt-5.5",
    "openai/gpt-5.6-luna",
    "openai/gpt-5.6-sol",
    "openai/gpt-5.6-terra",
    "openai/gpt-6-luna",
    "openai/gpt-6-sol",
    "openai/gpt-6.1-sol",
    "openai/chat-latest",
    "openai/gpt-oss-120b",
]

GoogleModels = Literal[
    "google/gemini-4-argon",
    "google/gemini-3.1-pro",
    "google/gemini-3-flash",
    "google/gemini-3.1-flash-lite",
    "google/gemini-3.5-flash",
    "google/gemini-2.5-pro",
    "google/gemini-2.5-flash",
    "google/gemini-2.5-flash-lite",
]

KimiModels = Literal[
    "moonshotai/kimi-k2.5",
    "moonshotai/kimi-k2.6",
]

DeepSeekModels = Literal[
    "deepseek-ai/deepseek-v3",
    "deepseek-ai/deepseek-v3.2",
]

ZAIModels = Literal["zai/glm-5.1"]

XAIModels = Literal[
    "xai/grok-4-1-fast-non-reasoning",
    "xai/grok-4-1-fast-reasoning",
    "xai/grok-4.20-0309-non-reasoning",
    "xai/grok-4.20-0309-reasoning",
    "xai/grok-4.20-multi-agent-0309",
    "xai/grok-4.3",
    "xai/grok-4.5",
]

LLMModels = OpenAIModels | GoogleModels | KimiModels | DeepSeekModels | ZAIModels | XAIModels


PromptCacheOptions: TypeAlias = completion_create_params.PromptCacheOptions


class ChatCompletionOptions(TypedDict, total=False):
    frequency_penalty: float | None
    logit_bias: dict[str, int] | None
    logprobs: bool | None
    max_completion_tokens: int | None
    max_tokens: int | None
    metadata: Metadata | None
    modalities: list[Literal["text", "audio"]] | None
    n: int | None
    parallel_tool_calls: bool
    prediction: ChatCompletionPredictionContentParam | None
    presence_penalty: float | None
    prompt_cache_key: str
    prompt_cache_options: PromptCacheOptions
    prompt_cache_retention: Literal["in_memory", "24h"] | None
    reasoning_effort: ReasoningEffort | None
    safety_identifier: str
    seed: int | None
    service_tier: Literal["auto", "default", "flex", "scale", "priority"] | None
    stop: str | None | list[str] | None
    store: bool | None
    temperature: float | None
    top_logprobs: int | None
    top_p: float | None
    user: str
    verbosity: Literal["low", "medium", "high"] | None
    web_search_options: completion_create_params.WebSearchOptions

    # livekit-typed arguments
    tool_choice: ToolChoice
    # TODO(theomonnomn): support repsonse format
    # response_format: completion_create_params.ResponseFormat


@dataclass
class _LLMOptions:
    model: LLMModels | str
    provider: str | None
    base_url: str
    api_key: str
    api_secret: str
    inference_class: InferenceClass | None
    extra_kwargs: ChatCompletionOptions | dict[str, Any]
    prompt_cache_breakpoints: bool | Literal["auto"]
    reasoning_effort: ReasoningEffort = None


class LLM(llm.LLM):
    def __init__(
        self,
        model: LLMModels | str,
        *,
        provider: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        api_secret: str | None = None,
        inference_class: InferenceClass | None = None,
        extra_kwargs: ChatCompletionOptions | dict[str, Any] | None = None,
        prompt_cache_breakpoints: bool | Literal["auto"] = "auto",
        reasoning: NotGivenOr[ReasoningSetting] = NOT_GIVEN,
    ) -> None:
        """
        Args:
            prompt_cache_breakpoints: Send each :class:`llm.CacheBreakpoint` in the chat
                context as an OpenAI ``prompt_cache_breakpoint``. ``"auto"`` sends them
                when :func:`supports_prompt_cache_breakpoints` accepts the current model;
                ``True`` or ``False`` overrides that.
            reasoning: How much the model reasons, such as ``"low"``, sent as
                ``reasoning_effort``. It takes the same values as
                ``inference.responses.LLM``, but only the effort: a ``summary`` or other
                Responses field raises ``ValueError``, as does
                ``extra_kwargs["reasoning"]``. It overrides
                ``extra_kwargs["reasoning_effort"]``, and a ``chat()`` call's own
                ``extra_kwargs["reasoning_effort"]`` overrides it for that turn. Unset, no
                effort is sent and the provider's default applies.
        """
        super().__init__()

        _reject_responses_reasoning(extra_kwargs or {})
        reasoning_effort = _to_reasoning_effort(reasoning) if is_given(reasoning) else None
        lk_base_url = base_url if base_url else get_default_inference_url()

        lk_api_key, lk_api_secret = resolve_credentials(api_key, api_secret)

        self._opts = _LLMOptions(
            model=model,
            provider=provider,
            base_url=lk_base_url,
            api_key=lk_api_key,
            api_secret=lk_api_secret,
            inference_class=inference_class,
            extra_kwargs=extra_kwargs or {},
            prompt_cache_breakpoints=prompt_cache_breakpoints,
            reasoning_effort=reasoning_effort,
        )
        self._check_reasoning()
        self._client = openai.AsyncClient(
            api_key=create_access_token(self._opts.api_key, self._opts.api_secret),
            base_url=self._opts.base_url,
            max_retries=0,
            http_client=httpx.AsyncClient(
                timeout=httpx.Timeout(connect=15.0, read=5.0, write=5.0, pool=5.0),
                follow_redirects=True,
                limits=httpx.Limits(
                    max_connections=50, max_keepalive_connections=50, keepalive_expiry=120
                ),
            ),
        )

    async def _prewarm_impl(self) -> None:
        await self._client.models.list()

    async def aclose(self) -> None:
        await super().aclose()
        await self._client.close()

    @classmethod
    def from_model_string(cls, model: str) -> LLM:
        """Create a LLM instance from a model string"""
        return cls(model)

    def update_options(
        self,
        *,
        model: NotGivenOr[LLMModels | str] = NOT_GIVEN,
        extra_kwargs: NotGivenOr[ChatCompletionOptions | dict[str, Any]] = NOT_GIVEN,
        prompt_cache_breakpoints: NotGivenOr[bool | Literal["auto"]] = NOT_GIVEN,
        reasoning: NotGivenOr[ReasoningSetting] = NOT_GIVEN,
    ) -> None:
        """Update LLM configuration options.

        Each option is read on the next ``chat()`` call, so a swap
        takes effect on the agent's next turn without recreating the
        LLM. ``extra_kwargs`` *replaces* the persistent kwargs dict
        rather than merging — pass ``{}`` to clear it. ``reasoning``
        changes only the effort and leaves ``extra_kwargs`` as is;
        ``None`` clears it.
        """
        # validated first, so a rejected setting changes nothing
        if is_given(extra_kwargs):
            _reject_responses_reasoning(extra_kwargs)
        reasoning_effort = _to_reasoning_effort(reasoning) if is_given(reasoning) else NOT_GIVEN
        if is_given(model):
            self._opts.model = model
        if is_given(extra_kwargs):
            self._opts.extra_kwargs = dict(extra_kwargs)
        # isinstance rather than is_given: mypy cannot narrow the bool | Literal union through it
        if not isinstance(prompt_cache_breakpoints, NotGiven):
            self._opts.prompt_cache_breakpoints = prompt_cache_breakpoints
        if not isinstance(reasoning_effort, NotGiven):
            self._opts.reasoning_effort = reasoning_effort
        if is_given(model) or is_given(extra_kwargs) or is_given(reasoning):
            self._check_reasoning()

    def _check_reasoning(self) -> None:
        """Warn about a reasoning effort that is unlikely to do what the caller meant.

        Logs when it overrides a different ``extra_kwargs["reasoning_effort"]``, or is
        below the model's lowest. It only warns; nothing it checks is changed.
        """
        effort = self._opts.reasoning_effort
        if effort is None:
            return
        configured = self._opts.extra_kwargs.get("reasoning_effort")
        if configured is not None and configured != effort:
            logger.warning(
                "reasoning overrides extra_kwargs['reasoning_effort']",
                extra={"reasoning": effort, "reasoning_effort": configured},
            )
        _warn_if_below_min_effort(self._opts.model, effort)

    @property
    def model(self) -> str:
        """Get the model name for this LLM instance."""
        return self._opts.model

    @property
    def provider(self) -> str:
        return "livekit"

    def chat(
        self,
        *,
        chat_ctx: ChatContext,
        tools: list[Tool] | None = None,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
        parallel_tool_calls: NotGivenOr[bool] = NOT_GIVEN,
        tool_choice: NotGivenOr[ToolChoice] = NOT_GIVEN,
        response_format: NotGivenOr[
            completion_create_params.ResponseFormat | type[llm_utils.ResponseFormatT]
        ] = NOT_GIVEN,
        inference_class: NotGivenOr[InferenceClass] = NOT_GIVEN,
        extra_kwargs: NotGivenOr[dict[str, Any]] = NOT_GIVEN,
    ) -> LLMStream:
        extra = {}
        if is_given(extra_kwargs):
            _reject_responses_reasoning(extra_kwargs)
            extra.update(extra_kwargs)

        parallel_tool_calls = (
            parallel_tool_calls
            if is_given(parallel_tool_calls)
            else self._opts.extra_kwargs.get("parallel_tool_calls", NOT_GIVEN)
        )
        if is_given(parallel_tool_calls):
            extra["parallel_tool_calls"] = parallel_tool_calls

        extra_tool_choice = self._opts.extra_kwargs.get("tool_choice", NOT_GIVEN)
        tool_choice = tool_choice if is_given(tool_choice) else extra_tool_choice
        if is_given(tool_choice):
            oai_tool_choice: ChatCompletionToolChoiceOptionParam
            if isinstance(tool_choice, dict):
                oai_tool_choice = {
                    "type": "function",
                    "function": {"name": tool_choice["function"]["name"]},
                }
                extra["tool_choice"] = oai_tool_choice
            elif tool_choice in ("auto", "required", "none"):
                oai_tool_choice = tool_choice
                extra["tool_choice"] = oai_tool_choice

        if is_given(response_format):
            extra["response_format"] = llm_utils.to_openai_response_format(response_format)  # type: ignore

        extra.update(self._opts.extra_kwargs)
        if self._opts.reasoning_effort is not None:
            # a turn's own extra_kwargs override it, as on inference.responses.LLM
            turn = extra_kwargs if is_given(extra_kwargs) else {}
            extra["reasoning_effort"] = turn.get("reasoning_effort", self._opts.reasoning_effort)

        effective_inference_class = (
            inference_class if is_given(inference_class) else self._opts.inference_class
        )

        self._client.api_key = create_access_token(self._opts.api_key, self._opts.api_secret)
        return LLMStream(
            self,
            model=self._opts.model,
            provider=self._opts.provider,
            inference_class=effective_inference_class,
            strict_tool_schema=True,
            client=self._client,
            chat_ctx=chat_ctx,
            tools=tools or [],
            conn_options=conn_options,
            extra_kwargs=extra,
            prompt_cache_breakpoints=self._resolve_prompt_cache_breakpoints(),
        )

    def _resolve_prompt_cache_breakpoints(self) -> bool:
        # resolved per chat() so update_options(model=...) re-evaluates "auto"
        setting = self._opts.prompt_cache_breakpoints
        if isinstance(setting, bool):
            return setting
        return supports_prompt_cache_breakpoints(self._opts.model)


class LLMStream(llm.LLMStream):
    def __init__(
        self,
        llm_v: LLM | llm.LLM,
        *,
        model: LLMModels | str,
        provider: str | None = None,
        inference_class: InferenceClass | None = None,
        strict_tool_schema: bool,
        client: openai.AsyncClient,
        chat_ctx: llm.ChatContext,
        tools: list[Tool],
        conn_options: APIConnectOptions,
        extra_kwargs: dict[str, Any],
        provider_fmt: str = "openai",  # used internally for chat_ctx format
        prompt_cache_breakpoints: bool = False,
    ) -> None:
        super().__init__(llm_v, chat_ctx=chat_ctx, tools=tools, conn_options=conn_options)
        self._model = model
        self._provider = provider
        self._inference_class = inference_class
        self._provider_fmt = provider_fmt
        # the other formatters take no such argument and drop CacheBreakpoint themselves
        self._prompt_cache_breakpoints = prompt_cache_breakpoints and (
            provider_fmt in _BREAKPOINT_FORMATS
        )
        self._strict_tool_schema = strict_tool_schema
        self._client = client
        self._llm = llm_v
        self._extra_kwargs = drop_unsupported_params(model, extra_kwargs, tools=tools)
        self._tool_ctx = llm.ToolContext(tools)

    async def _run(self) -> None:
        # current function call that we're waiting for full completion (args are streamed)
        # (defined inside the _run method to make sure the state is reset for each run/attempt)
        self._oai_stream: openai.AsyncStream[ChatCompletionChunk] | None = None
        self._tool_call_id: str | None = None
        self._fnc_name: str | None = None
        self._fnc_raw_arguments: str | None = None
        self._tool_extra: dict[str, Any] | None = None
        self._tool_index: int | None = None
        retryable = True

        try:
            fmt_kwargs: dict[str, Any] = {}
            if self._prompt_cache_breakpoints:
                fmt_kwargs["prompt_cache_breakpoints"] = True
            chat_ctx, _ = self._chat_ctx.to_provider_format(format=self._provider_fmt, **fmt_kwargs)
            tool_schemas = cast(
                list[ChatCompletionToolParam],
                self._tool_ctx.parse_function_tools("openai", strict=self._strict_tool_schema),
            )
            if lk_oai_debug:
                tool_choice = self._extra_kwargs.get("tool_choice", NOT_GIVEN)
                logger.debug(
                    "chat.completions.create",
                    extra={
                        "fnc_ctx": tool_schemas,
                        "tool_choice": tool_choice,
                        "lk.pii.chat_ctx": chat_ctx,
                    },
                )
            if not self._tools:
                # remove tool_choice from extra_kwargs if no tools are provided
                self._extra_kwargs.pop("tool_choice", None)

            extra_headers = self._extra_kwargs.setdefault("extra_headers", {})
            extra_headers.update(get_inference_headers(inference_class=self._inference_class))
            if self._provider:
                extra_headers[HEADER_INFERENCE_PROVIDER] = self._provider

            self._oai_stream = stream = await self._client.chat.completions.create(
                messages=cast(list[ChatCompletionMessageParam], chat_ctx),
                tools=tool_schemas or openai.omit,
                model=self._model,
                stream_options={"include_usage": True},
                stream=True,
                timeout=httpx.Timeout(self._conn_options.timeout),
                **self._extra_kwargs,
            )

            thinking_filter = llm_utils.ThinkingTokenFilter(
                *_MODEL_THINK_TAGS.get(
                    self._model, (llm_utils.THINK_TAG_START, llm_utils.THINK_TAG_END)
                )
            )
            async with stream:
                async for chunk in stream:
                    for choice in chunk.choices:
                        chat_chunk = self._parse_choice(chunk.id, choice, thinking_filter)
                        if chat_chunk is not None:
                            if chat_chunk.has_response():
                                retryable = False
                            self._event_ch.send_nowait(chat_chunk)

                    if chunk.usage is not None:
                        tokens_details = chunk.usage.prompt_tokens_details
                        cached_tokens = tokens_details.cached_tokens if tokens_details else 0
                        cache_creation_tokens = (
                            tokens_details.cache_write_tokens if tokens_details else 0
                        )
                        completion_details = chunk.usage.completion_tokens_details
                        reasoning_tokens = (
                            completion_details.reasoning_tokens if completion_details else 0
                        )
                        usage_chunk = llm.ChatChunk(
                            id=chunk.id,
                            usage=llm.CompletionUsage(
                                completion_tokens=chunk.usage.completion_tokens or 0,
                                prompt_tokens=chunk.usage.prompt_tokens or 0,
                                prompt_cached_tokens=cached_tokens or 0,
                                cache_creation_tokens=cache_creation_tokens or 0,
                                reasoning_tokens=reasoning_tokens or 0,
                                total_tokens=chunk.usage.total_tokens or 0,
                                service_tier=getattr(chunk, "service_tier", None),
                            ),
                        )
                        self._event_ch.send_nowait(usage_chunk)

        except openai.APITimeoutError:
            raise APITimeoutError(retryable=retryable) from None
        except httpx.TimeoutException as e:
            # Only the request call runs inside the openai client's error mapping, so a
            # timeout waiting on the stream body arrives as the raw httpx exception.
            raise APITimeoutError(retryable=retryable) from e
        except openai.APIStatusError as e:
            if e.status_code == 429:
                self._log_rate_limited(e)
            raise APIStatusError(
                e.message,
                status_code=e.status_code,
                request_id=e.request_id,
                body=e.body,
                retryable=retryable,
            ) from None
        except Exception as e:
            raise APIConnectionError(retryable=retryable) from e

    def _log_rate_limited(self, e: openai.APIStatusError) -> None:
        """Log the gateway's quota snapshot when a request is rejected with 429.

        The gateway stamps X-LiveKit-Inference-{RPM,TPM,Credits}-{Limit,Used}
        on rejections so customers can see which limit they hit and by how much.
        """
        extra: dict[str, Any] = {"model": self._model, "request_id": e.request_id}
        extra.update(extract_quota_usage(e.response.headers))
        logger.warning("LLM request rate limited by inference gateway", extra=extra)

    def _parse_choice(
        self, id: str, choice: Choice, thinking_filter: llm_utils.ThinkingTokenFilter
    ) -> llm.ChatChunk | None:
        delta = choice.delta

        # https://github.com/livekit/agents/issues/688
        # the delta can be None when using Azure OpenAI (content filtering)
        if delta is None:
            return None

        delta.content = llm_utils.strip_thinking_tokens(
            delta.content, thinking_filter, final=choice.finish_reason is not None
        )

        # Calls completed by this delta. A provider can send several parallel calls
        # in one chunk (e.g. Ollama), so they are collected and emitted together.
        completed: list[llm.FunctionToolCall] = []

        if delta.tool_calls:
            for tool in delta.tool_calls:
                if not tool.function:
                    continue

                if self._fnc_raw_arguments is not None and (
                    tool.index != self._tool_index
                    or (tool.id and self._tool_call_id and tool.id != self._tool_call_id)
                ):
                    if self._fnc_name:
                        completed.append(
                            llm.FunctionToolCall(
                                arguments=self._fnc_raw_arguments or "",
                                name=self._fnc_name or "",
                                call_id=self._tool_call_id or "",
                                extra=self._tool_extra,
                            )
                        )
                    self._tool_call_id = self._fnc_name = self._fnc_raw_arguments = None
                    self._tool_extra = None

                if tool.function.name:
                    if self._fnc_name or tool.index != self._tool_index:
                        self._tool_call_id = self._fnc_raw_arguments = None
                    self._tool_index = tool.index
                    self._tool_call_id = tool.id or self._tool_call_id
                    self._fnc_name = tool.function.name
                    self._fnc_raw_arguments = self._fnc_raw_arguments or ""
                    self._fnc_raw_arguments += tool.function.arguments or ""
                    # Extract extra from tool call (e.g., Google thought signatures)
                    self._tool_extra = getattr(tool, "extra_content", None)
                elif tool.function.arguments:
                    if self._fnc_raw_arguments is None:
                        self._tool_index = tool.index
                        self._tool_call_id = tool.id
                        self._fnc_raw_arguments = ""
                    self._fnc_raw_arguments += tool.function.arguments

        if choice.finish_reason in ("tool_calls", "stop") and self._tool_call_id and self._fnc_name:
            completed.append(
                llm.FunctionToolCall(
                    arguments=self._fnc_raw_arguments or "",
                    name=self._fnc_name or "",
                    call_id=self._tool_call_id or "",
                    extra=self._tool_extra,
                )
            )
            self._tool_call_id = self._fnc_name = self._fnc_raw_arguments = None
            self._tool_extra = None

        if completed:
            return llm.ChatChunk(
                id=id,
                delta=llm.ChoiceDelta(
                    role="assistant",
                    content=delta.content,
                    extra=getattr(delta, "extra_content", None),
                    tool_calls=completed,
                ),
            )

        # Extract extra from delta (e.g., Google thought signatures on text parts)
        delta_extra = getattr(delta, "extra_content", None)

        if not delta.content and not delta_extra:
            return None

        return llm.ChatChunk(
            id=id,
            delta=llm.ChoiceDelta(
                content=delta.content,
                role="assistant",
                extra=delta_extra,
            ),
        )


def llm_from_model_string(model: str) -> llm.LLM | llm.RealtimeModel | llm.DuplexModel:
    """Create the inference model a ``llm=`` string names.

    Duplex model strings resolve to :class:`livekit.agents.inference.DuplexModel`,
    realtime (speech-to-speech) model strings to
    :class:`livekit.agents.inference.RealtimeModel`, every other string to
    :class:`livekit.agents.inference.LLM`.
    """
    if is_duplex_model(model):
        # imported lazily: the realtime package imports this module
        from .realtime import DuplexModel

        return DuplexModel.from_model_string(model)

    if is_realtime_model(model):
        # imported lazily: the realtime package imports this module
        from .realtime import RealtimeModel

        return RealtimeModel.from_model_string(model)

    return LLM.from_model_string(model)
