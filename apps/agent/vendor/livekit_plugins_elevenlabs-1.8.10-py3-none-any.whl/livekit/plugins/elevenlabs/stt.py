# Copyright 2023 LiveKit, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
import base64
import json
import math
import os
import weakref
from dataclasses import dataclass
from typing import Any, Literal, TypedDict
from urllib.parse import quote

import aiohttp

from livekit import rtc
from livekit.agents import (
    DEFAULT_API_CONNECT_OPTIONS,
    APIConnectionError,
    APIConnectOptions,
    APIError,
    APIStatusError,
    APITimeoutError,
    LanguageCode,
    stt,
    utils,
)
from livekit.agents.stt import SpeechData, SpeechEventType, STTCapabilities
from livekit.agents.types import NOT_GIVEN, NotGivenOr
from livekit.agents.utils import AudioBuffer, http_context, is_given
from livekit.agents.voice.io import TimedString

from ._utils import PeriodicCollector, trace_id_from_headers
from .log import logger
from .models import STTRealtimeSampleRates

API_BASE_URL_V1 = "https://api.elevenlabs.io/v1"
AUTHORIZATION_HEADER = "xi-api-key"


def _speech_confidence(words: list[dict[str, Any]] | None) -> float:
    """Aggregate ElevenLabs per-word logprobs into a [0, 1] transcription confidence.

    Scribe returns a natural-log probability (``logprob``) per token; we average the
    spoken-word logprobs and exponentiate to a probability (the geometric mean of the
    token probabilities). Returns ``0.0`` when no per-word logprobs are available.
    """
    if not words:
        return 0.0
    logprobs = [
        w["logprob"]
        for w in words
        if w.get("type") == "word" and isinstance(w.get("logprob"), (int, float))
    ]
    if not logprobs:
        return 0.0
    return min(1.0, max(0.0, math.exp(sum(logprobs) / len(logprobs))))


class VADOptions(TypedDict, total=False):
    vad_silence_threshold_secs: float | None
    """Silence threshold in seconds for VAD. Default to 1.5"""
    vad_threshold: float | None
    """Threshold for voice activity detection. Default to 0.4"""
    min_speech_duration_ms: int | None
    """Minimum speech duration in milliseconds. Default to 250"""
    min_silence_duration_ms: int | None
    """Minimum silence duration in milliseconds. Default to 2500"""


# https://elevenlabs.io/docs/overview/models#models-overview
ElevenLabsSTTModels = Literal["scribe_v1", "scribe_v2", "scribe_v2_realtime"]


@dataclass
class STTOptions:
    model_id: ElevenLabsSTTModels | str
    api_key: str
    base_url: str
    language_code: LanguageCode | None
    secondary_languages: NotGivenOr[list[LanguageCode]]
    include_language_detection: NotGivenOr[bool]
    tag_audio_events: bool
    include_timestamps: bool
    sample_rate: STTRealtimeSampleRates
    server_vad: NotGivenOr[VADOptions | None]
    keyterms: NotGivenOr[list[str]]
    no_verbatim: bool
    enable_logging: bool
    previous_text: str | None
    audio_chunk_duration_ms: int = 50


class STT(stt.STT):
    def __init__(
        self,
        *,
        api_key: NotGivenOr[str] = NOT_GIVEN,
        base_url: NotGivenOr[str] = NOT_GIVEN,
        language_code: NotGivenOr[str] = NOT_GIVEN,
        secondary_languages: NotGivenOr[list[str]] = NOT_GIVEN,
        include_language_detection: NotGivenOr[bool] = NOT_GIVEN,
        tag_audio_events: bool = True,
        use_realtime: NotGivenOr[bool] = NOT_GIVEN,  # Deprecated
        sample_rate: STTRealtimeSampleRates = 16000,
        audio_chunk_duration_ms: int = 50,
        server_vad: NotGivenOr[VADOptions | None] = NOT_GIVEN,
        include_timestamps: bool = False,
        http_session: aiohttp.ClientSession | None = None,
        model: NotGivenOr[ElevenLabsSTTModels | str] = NOT_GIVEN,
        model_id: NotGivenOr[ElevenLabsSTTModels | str] = NOT_GIVEN,  # Deprecated
        keyterms: NotGivenOr[list[str]] = NOT_GIVEN,
        no_verbatim: NotGivenOr[bool] = NOT_GIVEN,
        enable_logging: bool = True,
        previous_text: NotGivenOr[str] = NOT_GIVEN,
    ) -> None:
        """
        Create a new instance of ElevenLabs STT.

        Args:
            api_key (NotGivenOr[str]): ElevenLabs API key. Can be set via argument or `ELEVEN_API_KEY` environment variable.
            base_url (NotGivenOr[str]): Custom base URL for the API. Optional.
            language_code (NotGivenOr[str]): Language code for the STT model. Optional.
            secondary_languages (NotGivenOr[list[str]]): Additional languages that may be spoken in
                the audio, on top of `language_code`. Keeps the primary language hinted while still
                recognizing the others, which is what a code-switching speaker needs. Names and
                ISO-639-3 codes are accepted and normalized to what the API takes. Only supported
                for Scribe v2 realtime.
            include_language_detection (NotGivenOr[bool]): Whether the committed transcript reports
                the language the model actually heard. Defaults to True when no `language_code` is
                set and False otherwise. Turning it off while no `language_code` is set leaves the
                plugin with no language to report and every transcript falls back to "en". Only
                supported for Scribe v2 realtime.
            tag_audio_events (bool): Whether to tag audio events like (laughter), (footsteps), etc. in the transcription.
                Only supported for Scribe v1 model. Default is True.
            use_realtime (bool): Whether to use "scribe_v2_realtime" model for streaming mode. Default is NOT_GIVEN.
                Note that this flag is deprecated in favour of explicitly specifying the model id.
            sample_rate (STTRealtimeSampleRates): Audio sample rate in Hz. Default is 16000.
            audio_chunk_duration_ms (int): Duration of each outgoing realtime audio chunk in
                milliseconds. Must be a positive integer. Defaults to 50. Larger chunks reduce
                message frequency but increase buffering latency. Flushes send any shorter
                remaining chunk before committing. Only used for Scribe v2 realtime.
            server_vad (NotGivenOr[VADOptions | None]): Server-side VAD options, only supported for Scribe v2 realtime model.
                At construction, omit or set to None to use manual commits. Pass {} to enable server VAD defaults.
                In update_options(), omission keeps the current setting; None disables server VAD and restores manual commits.
            http_session (aiohttp.ClientSession | None): Custom HTTP session for API requests. Optional.
            model (ElevenLabsSTTModels | str): ElevenLabs STT model to use. If not specified a default model will
                be selected based on parameters provided.
            model_id (ElevenLabsSTTModels | str): Deprecated alias for `model`. Use `model` instead.
            keyterms (NotGivenOr[list[str]]): A list of keywords or phrases to bias the transcription towards.
                Supported for both Scribe v2 (batch) and Scribe v2 realtime. Batch accepts up to
                1000 keyterms of at most 50 characters each; realtime accepts up to 50 keyterms of
                at most 20 characters each. Usage incurs additional costs.
            no_verbatim (NotGivenOr[bool]): When True, the model removes filler words, false starts
                and disfluencies from the transcript, producing cleaner output. Supported for both
                Scribe v2 (batch) and Scribe v2 realtime. Default is False.
            enable_logging (bool): Enable logging of the request. When set to false, zero retention
                mode will be used. Defaults to True.
            previous_text (NotGivenOr[str]): Preceding text context sent once on the first realtime
                audio chunk to improve transcription accuracy. Only supported for Scribe v2 realtime.
        """

        if (
            isinstance(audio_chunk_duration_ms, bool)
            or not isinstance(audio_chunk_duration_ms, int)
            or audio_chunk_duration_ms <= 0
        ):
            raise ValueError("audio_chunk_duration_ms must be a positive integer")

        if is_given(model_id):
            if is_given(model):
                logger.warning(
                    "both `model` and `model_id` parameters are provided. `model_id` will be ignored."
                )
            else:
                logger.warning("`model_id` parameter is deprecated, use `model` instead.")
                model = model_id

        if is_given(use_realtime):
            if is_given(model):
                logger.warning(
                    "both `use_realtime` and `model` parameters are provided. `use_realtime` will be ignored."
                )
            else:
                logger.warning(
                    "`use_realtime` parameter is deprecated. "
                    "Specify a realtime model to enable streaming. "
                    "Defaulting model to one based on use_realtime parameter. "
                )
                model = "scribe_v2_realtime" if use_realtime else "scribe_v1"
        model = model if is_given(model) else "scribe_v1"
        use_realtime = model == "scribe_v2_realtime"

        if not use_realtime and is_given(server_vad):
            logger.warning("Server-side VAD is only supported for Scribe v2 realtime model")

        if not use_realtime and is_given(secondary_languages):
            logger.warning(
                "`secondary_languages` is only supported for Scribe v2 realtime model "
                "and will be ignored"
            )
            secondary_languages = NOT_GIVEN

        if not use_realtime and is_given(include_language_detection):
            logger.warning(
                "`include_language_detection` is only supported for Scribe v2 realtime model "
                "and will be ignored"
            )
            include_language_detection = NOT_GIVEN

        resolved_previous_text = previous_text if is_given(previous_text) else None
        if not use_realtime and resolved_previous_text is not None:
            logger.warning(
                "`previous_text` is only supported for Scribe v2 realtime model and will be ignored"
            )
            resolved_previous_text = None

        super().__init__(
            capabilities=STTCapabilities(
                streaming=use_realtime,
                interim_results=True,
                aligned_transcript="word" if include_timestamps and use_realtime else False,
                manual_flush=use_realtime and (not is_given(server_vad) or server_vad is None),
            )
        )

        elevenlabs_api_key = api_key if is_given(api_key) else os.environ.get("ELEVEN_API_KEY")
        if not elevenlabs_api_key:
            raise ValueError(
                "ElevenLabs API key is required, either as argument or "
                "set ELEVEN_API_KEY environmental variable"
            )

        self._opts = STTOptions(
            api_key=elevenlabs_api_key,
            base_url=base_url if is_given(base_url) else API_BASE_URL_V1,
            language_code=LanguageCode(language_code) if language_code else None,
            secondary_languages=[LanguageCode(language) for language in secondary_languages]
            if is_given(secondary_languages)
            else NOT_GIVEN,
            include_language_detection=include_language_detection,
            tag_audio_events=tag_audio_events,
            sample_rate=sample_rate,
            audio_chunk_duration_ms=audio_chunk_duration_ms,
            server_vad=server_vad,
            include_timestamps=include_timestamps,
            model_id=model,
            keyterms=keyterms,
            no_verbatim=no_verbatim if is_given(no_verbatim) else False,
            enable_logging=enable_logging,
            previous_text=resolved_previous_text,
        )
        self._session = http_session
        self._streams = weakref.WeakSet[SpeechStream]()

    @property
    def model(self) -> str:
        return self._opts.model_id

    @property
    def provider(self) -> str:
        return "ElevenLabs"

    def _ensure_session(self) -> aiohttp.ClientSession:
        if not self._session:
            self._session = http_context.http_session()

        return self._session

    async def _recognize_impl(
        self,
        buffer: AudioBuffer,
        *,
        language: NotGivenOr[str] = NOT_GIVEN,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> stt.SpeechEvent:
        request_language = (
            LanguageCode(language) if is_given(language) else self._opts.language_code
        )

        wav_bytes = rtc.combine_audio_frames(buffer).to_wav_bytes()
        form = aiohttp.FormData()
        form.add_field("file", wav_bytes, filename="audio.wav", content_type="audio/x-wav")
        form.add_field("model_id", self._opts.model_id)
        form.add_field("tag_audio_events", str(self._opts.tag_audio_events).lower())
        if request_language:
            form.add_field("language_code", request_language)
        if is_given(self._opts.keyterms):
            for keyterm in self._opts.keyterms:
                form.add_field("keyterms", keyterm)
        if self._opts.no_verbatim:
            form.add_field("no_verbatim", "true")

        try:
            async with self._ensure_session().post(
                _synthesize_url(self._opts),
                data=form,
                headers={AUTHORIZATION_HEADER: self._opts.api_key},
            ) as response:
                if response.status != 200:
                    # check the status first: an error body may be empty or not JSON
                    text = await response.text()
                    try:
                        body: Any = json.loads(text)
                    except ValueError:
                        body = text
                    detail = body.get("detail") if isinstance(body, dict) else None
                    if isinstance(detail, dict):
                        detail = detail.get("message", detail)
                    raise APIStatusError(
                        message=str(detail or text or "Unknown ElevenLabs error"),
                        status_code=response.status,
                        request_id=trace_id_from_headers(response.headers),
                        body=body,
                    )
                response_json = await response.json()
                extracted_text = response_json.get("text")
                language_code = response_json.get("language_code")
                speaker_id = None
                start_time, end_time = 0, 0
                words = response_json.get("words")
                if words:
                    speaker_id = words[0].get("speaker_id", None)
                    start_time = min(w.get("start", 0) for w in words)
                    end_time = max(w.get("end", 0) for w in words)

        except asyncio.TimeoutError as e:
            raise APITimeoutError() from e
        except aiohttp.ClientResponseError as e:
            raise APIStatusError(
                message=e.message,
                status_code=e.status,
                request_id=trace_id_from_headers(e.headers),
                body=None,
            ) from e
        except APIStatusError:
            raise
        except Exception as e:
            raise APIConnectionError() from e

        normalized_language = LanguageCode(language_code or request_language or "")
        return self._transcription_to_speech_event(
            language_code=normalized_language,
            text=extracted_text,
            start_time=start_time,
            end_time=end_time,
            speaker_id=speaker_id,
            words=words,
        )

    def _transcription_to_speech_event(
        self,
        language_code: str,
        text: str,
        start_time: float,
        end_time: float,
        speaker_id: str | None,
        words: list[dict[str, Any]] | None = None,
    ) -> stt.SpeechEvent:
        return stt.SpeechEvent(
            type=SpeechEventType.FINAL_TRANSCRIPT,
            alternatives=[
                stt.SpeechData(
                    text=text,
                    language=LanguageCode(language_code),
                    speaker_id=speaker_id,
                    start_time=start_time,
                    end_time=end_time,
                    confidence=_speech_confidence(words),
                    words=[
                        TimedString(
                            text=word.get("text", ""),
                            start_time=word.get("start", 0),
                            end_time=word.get("end", 0),
                        )
                        for word in words
                    ]
                    if words
                    else None,
                )
            ],
        )

    def update_options(
        self,
        *,
        tag_audio_events: NotGivenOr[bool] = NOT_GIVEN,
        server_vad: NotGivenOr[VADOptions | None] = NOT_GIVEN,
        keyterms: NotGivenOr[list[str]] = NOT_GIVEN,
        secondary_languages: NotGivenOr[list[str]] = NOT_GIVEN,
        no_verbatim: NotGivenOr[bool] = NOT_GIVEN,
    ) -> None:
        """Update STT options. Omitted options keep their current values.

        Set server_vad to None to disable server VAD and use manual commits.
        Pass {} to enable server VAD with defaults, or a VADOptions dict to configure it.
        Changing server_vad reconnects active streams and can discard unfinished transcripts.
        Wait for the current turn's final transcript before changing the commit strategy.
        """
        if is_given(tag_audio_events):
            self._opts.tag_audio_events = tag_audio_events

        if is_given(server_vad):
            self._opts.server_vad = server_vad
            self._capabilities.manual_flush = self._capabilities.streaming and server_vad is None

        if is_given(keyterms):
            self._opts.keyterms = keyterms

        if is_given(secondary_languages):
            if self._opts.model_id == "scribe_v2_realtime":
                self._opts.secondary_languages = [
                    LanguageCode(language) for language in secondary_languages
                ]
            else:
                logger.warning(
                    "`secondary_languages` is only supported for Scribe v2 realtime model "
                    "and will be ignored"
                )
                secondary_languages = NOT_GIVEN

        if is_given(no_verbatim):
            self._opts.no_verbatim = no_verbatim

        for stream in self._streams:
            stream.update_options(
                server_vad=server_vad,
                no_verbatim=no_verbatim,
                keyterms=keyterms,
                secondary_languages=secondary_languages,
            )

    def stream(
        self,
        *,
        language: NotGivenOr[str] = NOT_GIVEN,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> SpeechStream:
        stream = SpeechStream(
            stt=self,
            opts=self._opts,
            conn_options=conn_options,
            language=LanguageCode(language) if is_given(language) else self._opts.language_code,
            http_session=self._ensure_session(),
        )
        self._streams.add(stream)
        return stream


class SpeechStream(stt.SpeechStream):
    """Streaming speech recognition using ElevenLabs Scribe v2 realtime API"""

    def __init__(
        self,
        *,
        stt: STT,
        opts: STTOptions,
        conn_options: APIConnectOptions,
        language: LanguageCode | None,
        http_session: aiohttp.ClientSession,
    ) -> None:
        super().__init__(stt=stt, conn_options=conn_options, sample_rate=opts.sample_rate)
        self._opts = opts
        self._language = language
        self._session = http_session
        self._reconnect_event = asyncio.Event()
        self._speaking = False  # Track if we're currently in a speech segment
        self._last_partial_text = ""
        self._final_alternatives: list[SpeechData] = []
        self._audio_duration_collector = PeriodicCollector(
            callback=self._on_audio_duration_report,
            duration=5.0,
        )

    def update_options(
        self,
        *,
        server_vad: NotGivenOr[VADOptions | None] = NOT_GIVEN,
        no_verbatim: NotGivenOr[bool] = NOT_GIVEN,
        keyterms: NotGivenOr[list[str]] = NOT_GIVEN,
        secondary_languages: NotGivenOr[list[str]] = NOT_GIVEN,
    ) -> None:
        """Update stream options. Omitted options keep their current values.

        Set server_vad to None to disable server VAD and use manual commits.
        Pass {} to enable server VAD with defaults, or a VADOptions dict to configure it.
        Changes reconnect the stream and can discard unfinished transcripts.
        Wait for the current turn's final transcript before changing these options.
        """
        if is_given(server_vad):
            self._opts.server_vad = server_vad
            self._reconnect_event.set()
        if is_given(no_verbatim):
            self._opts.no_verbatim = no_verbatim
            self._reconnect_event.set()
        if is_given(keyterms):
            self._opts.keyterms = keyterms
            self._reconnect_event.set()
        if is_given(secondary_languages):
            self._opts.secondary_languages = [
                LanguageCode(language) for language in secondary_languages
            ]
            self._reconnect_event.set()

    def _on_audio_duration_report(self, duration: float) -> None:
        usage_event = stt.SpeechEvent(
            type=stt.SpeechEventType.RECOGNITION_USAGE,
            alternatives=[],
            recognition_usage=stt.RecognitionUsage(audio_duration=duration),
        )
        self._event_ch.send_nowait(usage_event)

    @property
    def _server_vad(self) -> VADOptions | None:
        return self._opts.server_vad if is_given(self._opts.server_vad) else None

    @property
    def _language_detection(self) -> bool:
        """Whether the session reports the language the model actually heard.

        Defaults to on when no language was pinned, which is the only case where the plugin
        used to request it."""
        if is_given(self._opts.include_language_detection):
            return self._opts.include_language_detection

        return not self._language

    @property
    def _final_message_type(self) -> str:
        """The committed message this session treats as the final transcript.

        ElevenLabs sends every commit twice and puts the word timestamps and the detected
        language on the delayed copy only, so that copy is the final one whenever either is
        asked for."""
        if self._opts.include_timestamps or self._language_detection:
            return "committed_transcript_with_timestamps"

        return "committed_transcript"

    async def _run(self) -> None:
        """Run the streaming transcription session"""
        closing_ws = False

        async def keepalive_task(ws: aiohttp.ClientWebSocketResponse) -> None:
            try:
                while True:
                    # scribe_v2_realtime model requires a keepalive message instead of a ping
                    await asyncio.sleep(10)
                    await ws.send_str(
                        json.dumps(
                            {
                                "message_type": "input_audio_chunk",
                                "audio_base_64": "",
                                "commit": False,
                                "sample_rate": self._opts.sample_rate,
                            }
                        )
                    )
            except Exception:
                return

        @utils.log_exceptions(logger=logger)
        async def send_task(ws: aiohttp.ClientWebSocketResponse) -> None:
            nonlocal closing_ws

            # Buffer audio into chunks of the configured duration.
            samples_per_chunk = self._opts.sample_rate * self._opts.audio_chunk_duration_ms // 1000
            audio_bstream = utils.audio.AudioByteStream(
                sample_rate=self._opts.sample_rate,
                num_channels=1,
                samples_per_channel=samples_per_chunk,
            )

            # Scribe closes the session on a commit with less than 0.3s of audio since the
            # previous commit or the connect
            min_commit_samples = self._opts.sample_rate * 3 // 10
            uncommitted_samples = 0
            has_ended = False
            try:
                async for data in self._input_ch:
                    # Write audio bytes to the buffer and get complete chunks
                    frames: list[rtc.AudioFrame] = []
                    if isinstance(data, rtc.AudioFrame):
                        uncommitted_samples += data.samples_per_channel
                        frames.extend(audio_bstream.write(data.data.tobytes()))
                    elif isinstance(data, self._FlushSentinel):
                        frames.extend(audio_bstream.flush())
                        if (missing := min_commit_samples - uncommitted_samples) > 0:
                            frames.append(rtc.AudioFrame.create(self._opts.sample_rate, 1, missing))
                        has_ended = True

                    for frame in frames:
                        self._audio_duration_collector.push(frame.duration)
                        audio_b64 = base64.b64encode(frame.data.tobytes()).decode("utf-8")
                        await ws.send_str(
                            json.dumps(
                                {
                                    "message_type": "input_audio_chunk",
                                    "audio_base_64": audio_b64,
                                    "commit": False,
                                    "sample_rate": self._opts.sample_rate,
                                }
                            )
                        )

                    if has_ended:
                        self._audio_duration_collector.flush()
                        await ws.send_str(
                            json.dumps(
                                {
                                    "message_type": "input_audio_chunk",
                                    "audio_base_64": "",
                                    "commit": True,
                                    "sample_rate": self._opts.sample_rate,
                                }
                            )
                        )
                        uncommitted_samples = 0
                        has_ended = False

                closing_ws = True
            except (aiohttp.ClientError, ConnectionError) as e:
                if closing_ws or self._session.closed:
                    return
                raise APIConnectionError("ElevenLabs STT connection closed unexpectedly") from e

        @utils.log_exceptions(logger=logger)
        async def recv_task(ws: aiohttp.ClientWebSocketResponse) -> None:
            nonlocal closing_ws

            monitor = utils.aio.WebSocketMonitor(
                ws, liveness_timeout=self._conn_options.liveness_timeout
            )
            while True:
                msg = await monitor.receive()

                if msg.type in (
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSING,
                ):
                    if closing_ws or self._session.closed:
                        return
                    raise APIStatusError(
                        message="ElevenLabs STT connection closed unexpectedly",
                        status_code=ws.close_code or -1,
                        body=f"{msg.data=} {msg.extra=}",
                    )

                if msg.type != aiohttp.WSMsgType.TEXT:
                    logger.warning("unexpected ElevenLabs STT message type %s", msg.type)
                    continue

                try:
                    parsed = json.loads(msg.data)
                    self._process_stream_event(parsed)
                    if parsed.get("message_type") in (
                        "partial_transcript",
                        "committed_transcript",
                        "committed_transcript_with_timestamps",
                    ):
                        self._mark_provider_progress()
                except APIError:
                    raise
                except Exception:
                    logger.exception("failed to process ElevenLabs STT message")

        ws: aiohttp.ClientWebSocketResponse | None = None

        while True:
            try:
                ws = await self._connect_ws()
                self._input_ch.restart_provider_clock()
                self._last_partial_text = ""
                self._final_alternatives = []
                if self._opts.previous_text:
                    # Must be the first input_audio_chunk on the connection.
                    await ws.send_str(
                        json.dumps(
                            {
                                "message_type": "input_audio_chunk",
                                "audio_base_64": "",
                                "commit": False,
                                "sample_rate": self._opts.sample_rate,
                                "previous_text": self._opts.previous_text,
                            }
                        )
                    )
                tasks = [
                    asyncio.create_task(send_task(ws)),
                    asyncio.create_task(recv_task(ws)),
                    asyncio.create_task(keepalive_task(ws)),
                ]
                tasks_group = asyncio.gather(*tasks)
                wait_reconnect_task = asyncio.create_task(self._reconnect_event.wait())

                try:
                    done, _ = await asyncio.wait(
                        (tasks_group, wait_reconnect_task),
                        return_when=asyncio.FIRST_COMPLETED,
                    )

                    for task in done:
                        if task != wait_reconnect_task:
                            task.result()

                    if wait_reconnect_task not in done:
                        break

                    self._reconnect_event.clear()
                finally:
                    await utils.aio.gracefully_cancel(*tasks, wait_reconnect_task)
                    tasks_group.cancel()
                    tasks_group.exception()  # Retrieve exception to prevent it from being logged
            finally:
                if ws is not None:
                    await ws.close()

    async def _connect_ws(self) -> aiohttp.ClientWebSocketResponse:
        """Establish WebSocket connection to ElevenLabs Scribe v2 API"""
        commit_strategy = "vad" if self._server_vad is not None else "manual"
        params = [
            f"model_id={self._opts.model_id}",
            f"audio_format=pcm_{self._opts.sample_rate}",
            f"commit_strategy={commit_strategy}",
            f"enable_logging={str(self._opts.enable_logging).lower()}",
        ]

        if self._language_detection:
            params.append("include_language_detection=true")

        if (server_vad := self._server_vad) is not None:
            if (
                vad_silence_threshold_secs := server_vad.get("vad_silence_threshold_secs")
            ) is not None:
                params.append(f"vad_silence_threshold_secs={vad_silence_threshold_secs}")
            if (vad_threshold := server_vad.get("vad_threshold")) is not None:
                params.append(f"vad_threshold={vad_threshold}")
            if (min_speech_duration_ms := server_vad.get("min_speech_duration_ms")) is not None:
                params.append(f"min_speech_duration_ms={min_speech_duration_ms}")
            if (min_silence_duration_ms := server_vad.get("min_silence_duration_ms")) is not None:
                params.append(f"min_silence_duration_ms={min_silence_duration_ms}")

        # the realtime API takes a bare ISO-639-1/639-3 code and rejects the session on a
        # region-tagged one ("ru-RU"), so both language params go on the wire without the region
        if self._language:
            params.append(f"language_code={quote(self._language.language)}")

        if is_given(self._opts.secondary_languages):
            params.extend(
                f"secondary_languages={quote(language.language)}"
                for language in self._opts.secondary_languages
            )

        if self._opts.include_timestamps:
            params.append("include_timestamps=true")

        if self._opts.no_verbatim:
            params.append("no_verbatim=true")

        if is_given(self._opts.keyterms):
            params.extend(f"keyterms={quote(keyterm)}" for keyterm in self._opts.keyterms)

        query_string = "&".join(params)

        # Convert HTTPS URL to WSS
        base_url = self._opts.base_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = f"{base_url}/speech-to-text/realtime?{query_string}"

        try:
            ws = await asyncio.wait_for(
                self._session.ws_connect(
                    ws_url,
                    headers={AUTHORIZATION_HEADER: self._opts.api_key},
                    autoping=False,
                ),
                self._conn_options.timeout,
            )
        except aiohttp.WSServerHandshakeError as e:
            raise APIStatusError(
                message=e.message,
                status_code=e.status,
                request_id=trace_id_from_headers(e.headers),
            ) from e
        except (aiohttp.ClientConnectorError, asyncio.TimeoutError) as e:
            raise APIConnectionError("Failed to connect to ElevenLabs") from e

        return ws

    def _process_stream_event(self, data: dict) -> None:
        """Process incoming WebSocket messages from ElevenLabs"""
        message_type = data.get("message_type")
        text = data.get("text", "")
        words = data.get("words", [])
        start_time = words[0].get("start", 0) if words else 0
        end_time = words[-1].get("end", 0) if words else 0
        language_code = data.get("language_code") or self._language

        normalized_language = LanguageCode(language_code) if language_code else LanguageCode("en")

        # 11labs only sends word timestamps for final transcripts
        speech_data = stt.SpeechData(
            language=normalized_language,
            text=text,
            start_time=start_time + self.start_time_offset,
            end_time=end_time + self.start_time_offset,
            confidence=_speech_confidence(words),
        )
        if words and self._opts.include_timestamps:
            speech_data.words = [
                TimedString(
                    text=word.get("text", ""),
                    start_time=word.get("start", 0) + self.start_time_offset,
                    end_time=word.get("end", 0) + self.start_time_offset,
                    start_time_offset=self.start_time_offset,
                )
                for word in words
            ]

        if message_type == "partial_transcript":
            logger.debug("Received message type partial_transcript", extra={"lk.pii.data": data})

            if text and text != self._last_partial_text:
                self._last_partial_text = text

                # Send START_OF_SPEECH if we're not already speaking
                if not self._speaking:
                    self._event_ch.send_nowait(
                        stt.SpeechEvent(type=SpeechEventType.START_OF_SPEECH)
                    )
                    self._speaking = True

                # Send INTERIM_TRANSCRIPT
                interim_event = stt.SpeechEvent(
                    type=SpeechEventType.INTERIM_TRANSCRIPT,
                    alternatives=[speech_data],
                )
                self._event_ch.send_nowait(interim_event)

        # 11labs sends every commit twice; _final_message_type picks the copy this session reads
        elif message_type == self._final_message_type:
            # Final committed transcripts - these are sent to the LLM/TTS layer in LiveKit agents
            # and trigger agent responses (unlike partial transcripts which are UI-only)
            self._last_partial_text = ""

            if text:
                # Send START_OF_SPEECH if we're not already speaking
                if not self._speaking:
                    self._event_ch.send_nowait(
                        stt.SpeechEvent(type=SpeechEventType.START_OF_SPEECH)
                    )
                    self._speaking = True

                # Send FINAL_TRANSCRIPT but keep speaking=True
                # Multiple commits can occur within the same speech segment
                self._final_alternatives = [speech_data] if end_time > 0 else []
                final_event = stt.SpeechEvent(
                    type=SpeechEventType.FINAL_TRANSCRIPT,
                    alternatives=[speech_data],
                )
                self._event_ch.send_nowait(final_event)

            if self._speaking and (not text or self._server_vad is not None):
                self._event_ch.send_nowait(
                    stt.SpeechEvent(
                        type=SpeechEventType.END_OF_SPEECH,
                        alternatives=self._final_alternatives,
                    )
                )
                self._final_alternatives = []
                self._speaking = False

        elif message_type in ("committed_transcript", "committed_transcript_with_timestamps"):
            # the other copy of a commit the branch above already emitted
            pass

        elif message_type == "session_started":
            # Session initialization message - informational only
            session_id = data.get("session_id", "unknown")
            logger.debug("Session started with ID: %s", session_id)

        # Error handling for known ElevenLabs error types
        elif message_type in (
            "auth_error",
            "quota_exceeded",
            "transcriber_error",
            "input_error",
            "error",
        ):
            logger.error(
                "ElevenLabs STT error [%s]",
                message_type,
                extra={"lk.pii.data": data},
            )
            raise APIConnectionError(
                f"ElevenLabs STT error [{message_type}]",
                retryable=message_type not in ("auth_error", "quota_exceeded", "input_error"),
            ) from None
        else:
            logger.warning(
                "ElevenLabs STT unknown message type: %s",
                message_type,
                extra={"lk.pii.data": data},
            )


def _synthesize_url(opts: STTOptions) -> str:
    base_url = opts.base_url
    url = f"{base_url}/speech-to-text?enable_logging={str(opts.enable_logging).lower()}"
    return url
