from __future__ import annotations

import asyncio
import json
import os
import weakref
from dataclasses import dataclass, replace

import aiohttp

from livekit.agents import (
    APIConnectionError,
    APIConnectOptions,
    APIError,
    APIStatusError,
    APITimeoutError,
    tokenize,
    tts,
    utils,
)
from livekit.agents.types import (
    DEFAULT_API_CONNECT_OPTIONS,
    NOT_GIVEN,
    NotGivenOr,
)
from livekit.agents.utils import is_given

from ._utils import _to_deepgram_url
from .log import logger
from .models import FluxTTSModels

# Flux TTS is served on the /v2/speak endpoint over both WebSocket (streaming) and
# REST (batch). A single https base URL works for both: `_to_deepgram_url` flips the
# scheme to wss when a WebSocket connection is requested.
# https://developers.deepgram.com/docs/flux-tts/overview
BASE_URL_V2 = "https://api.deepgram.com/v2/speak"
NUM_CHANNELS = 1

# Encodings the LiveKit pipeline can decode, mapped to their mime type. Deepgram Flux
# also offers mulaw/alaw, but those aren't playable through the pipeline yet, so they're
# intentionally omitted here.
_ENCODING_TO_MIMETYPE: dict[str, str] = {
    "linear16": "audio/pcm",
    "mp3": "audio/mp3",
    "opus": "audio/opus",
    "flac": "audio/flac",
    "aac": "audio/aac",
}


def _encoding_to_mimetype(encoding: str) -> str:
    try:
        return _ENCODING_TO_MIMETYPE[encoding]
    except KeyError:
        raise ValueError(
            f"unsupported Deepgram Flux TTS encoding {encoding!r}; "
            f"supported encodings are: {', '.join(_ENCODING_TO_MIMETYPE)}"
        ) from None


# Speaking rate accepted by Flux TTS: 0.5 to 1.5 in 0.05 steps. Anything else is rejected
# with a 400, which on the WebSocket path surfaces only as a failed handshake.
MIN_SPEED = 0.5
MAX_SPEED = 1.5
SPEED_STEP = 0.05


def _validated_speed(speed: float) -> float:
    # a little slack at the ends for float noise (0.1 * 3 * 5 == 1.5000000000000002);
    # also rejects nan and infinities before any rounding
    if not MIN_SPEED - 1e-6 <= speed <= MAX_SPEED + 1e-6:
        raise ValueError(f"speed must be between {MIN_SPEED} and {MAX_SPEED}, but got {speed}")
    steps = speed / SPEED_STEP
    if abs(steps - round(steps)) > 1e-6:
        raise ValueError(f"speed must be a multiple of {SPEED_STEP}, but got {speed}")
    # the exact step (1.5, not 1.5000000000000002), since the API rejects anything off
    # the 0.05 grid
    return round(round(steps) * SPEED_STEP, 2)


@dataclass
class _TTSOptionsV2:
    model: FluxTTSModels | str
    encoding: str
    sample_rate: int
    word_tokenizer: tokenize.WordTokenizer
    base_url: str
    api_key: str
    mip_opt_out: bool = False
    bit_rate: int | None = None
    speed: float | None = None


class TTSv2(tts.TTS):
    def __init__(
        self,
        *,
        model: FluxTTSModels | str = "flux-alexis-en",
        encoding: str = "linear16",
        sample_rate: int = 24000,
        bit_rate: int | None = None,
        speed: float | None = None,
        api_key: str | None = None,
        base_url: str = BASE_URL_V2,
        word_tokenizer: NotGivenOr[tokenize.WordTokenizer] = NOT_GIVEN,
        http_session: aiohttp.ClientSession | None = None,
        mip_opt_out: bool = False,
    ) -> None:
        """
        Create a new instance of Deepgram Flux TTS (the /v2/speak endpoint).

        Args:
            model (FluxTTSModels | str): Flux TTS model to use. Defaults to "flux-alexis-en".
                Model names follow the `flux-{voice}-{language}` format.
                See https://developers.deepgram.com/docs/flux-tts/overview for available voices.
            encoding (str): Audio encoding to use. Defaults to "linear16".
                The streaming path (stream(), what voice agents use) only supports raw
                "linear16" end-to-end through the LiveKit pipeline. Compressed encodings
                (mp3/opus/flac/aac) are available on the batch synthesize() path only.
            sample_rate (int): Sample rate of audio. Defaults to 24000.
            bit_rate (int | None): Bit rate for compressed encodings (e.g. mp3). Defaults to None.
                Applies to the batch synthesize() path only; it has no effect on the
                linear16 streaming path.
            speed (float | None): Speaking rate, from 0.5 to 1.5 in 0.05 steps; 1.0 is the normal
                rate. Defaults to None, which leaves it out of the request.
                See https://developers.deepgram.com/docs/tts-voice-controls
            api_key (str): Deepgram API key. If not provided, will look for DEEPGRAM_API_KEY in environment.
            base_url (str): Base URL for Deepgram Flux TTS API. Defaults to "https://api.deepgram.com/v2/speak"
            word_tokenizer (tokenize.WordTokenizer): Tokenizer for processing text. Defaults to basic WordTokenizer.
            http_session (aiohttp.ClientSession): Optional aiohttp session to use for requests.
            mip_opt_out (bool): Opt out of the Deepgram Model Improvement Program. Defaults to
                False (requests may be used to improve models). See https://dpgr.am/deepgram-mip

        """  # noqa: E501
        super().__init__(
            capabilities=tts.TTSCapabilities(streaming=True),
            sample_rate=sample_rate,
            num_channels=NUM_CHANNELS,
        )

        api_key = api_key or os.environ.get("DEEPGRAM_API_KEY")
        if not api_key:
            raise ValueError("Deepgram API key required. Set DEEPGRAM_API_KEY or provide api_key.")

        if speed is not None:
            speed = _validated_speed(speed)

        if not is_given(word_tokenizer):
            word_tokenizer = tokenize.basic.WordTokenizer(ignore_punctuation=False)

        self._opts = _TTSOptionsV2(
            model=model,
            encoding=encoding,
            sample_rate=sample_rate,
            bit_rate=bit_rate,
            speed=speed,
            word_tokenizer=word_tokenizer,
            base_url=base_url,
            api_key=api_key,
            mip_opt_out=mip_opt_out,
        )
        self._session = http_session
        self._streams = weakref.WeakSet[SynthesizeStreamv2]()

        self._pool = utils.ConnectionPool[aiohttp.ClientWebSocketResponse](
            connect_cb=self._connect_ws,
            close_cb=self._close_ws,
            max_session_duration=3600,  # 1 hour
            mark_refreshed_on_get=False,
        )

    @property
    def model(self) -> str:
        return self._opts.model

    @property
    def provider(self) -> str:
        return "Deepgram"

    async def _connect_ws(self, timeout: float) -> aiohttp.ClientWebSocketResponse:
        session = self._ensure_session()
        # Streaming only supports linear16 end-to-end, so bit_rate (compressed batch
        # output only) is intentionally not forwarded here.
        config: dict = {
            "encoding": self._opts.encoding,
            "model": self._opts.model,
            "sample_rate": self._opts.sample_rate,
            "mip_opt_out": self._opts.mip_opt_out,
        }
        if self._opts.speed is not None:
            config["speed"] = self._opts.speed
        ws = await asyncio.wait_for(
            session.ws_connect(
                _to_deepgram_url(config, self._opts.base_url, websocket=True),
                headers={"Authorization": f"Token {self._opts.api_key}"},
            ),
            timeout,
        )
        ws_headers = {
            k: v for k, v in ws._response.headers.items() if k.startswith("dg-") or k == "Date"
        }
        logger.debug(
            "Established new Deepgram Flux TTS WebSocket connection:",
            extra={"headers": ws_headers},
        )

        return ws

    async def _close_ws(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        try:
            # Send Flush and Close messages to ensure Deepgram processes all remaining audio
            # and properly terminates the session, preventing lingering TTS sessions
            await ws.send_str(SynthesizeStreamv2._FLUSH_MSG)
            await ws.send_str(SynthesizeStreamv2._CLOSE_MSG)

            # Wait for server acknowledgment to prevent race conditions and ensure
            # proper cleanup, avoiding 429 Too Many Requests errors from lingering sessions
            try:
                await asyncio.wait_for(ws.receive(), timeout=1.0)
            except asyncio.TimeoutError:
                pass
        except Exception as e:
            logger.warning(f"Error during WebSocket close sequence: {e}")
        finally:
            await ws.close()

    def _ensure_session(self) -> aiohttp.ClientSession:
        if not self._session:
            self._session = utils.http_context.http_session()
        return self._session

    def update_options(
        self,
        *,
        model: NotGivenOr[FluxTTSModels | str] = NOT_GIVEN,
        encoding: NotGivenOr[str] = NOT_GIVEN,
        sample_rate: NotGivenOr[int] = NOT_GIVEN,
        bit_rate: NotGivenOr[int | None] = NOT_GIVEN,
        speed: NotGivenOr[float | None] = NOT_GIVEN,
    ) -> None:
        """
        Args:
            model (FluxTTSModels | str): Flux TTS model to use.
            encoding (str): Audio encoding to use.
            sample_rate (int): Sample rate of audio in Hz.
            bit_rate (int | None): Bit rate for compressed encodings (e.g. mp3).
            speed (float | None): Speaking rate, from 0.5 to 1.5 in 0.05 steps; None leaves it
                out of the request.
        """
        if is_given(speed) and speed is not None:
            speed = _validated_speed(speed)

        connection_params_changed = False
        if is_given(model):
            self._opts.model = model
            connection_params_changed = True
        if is_given(encoding):
            self._opts.encoding = encoding
            connection_params_changed = True
        if is_given(sample_rate):
            self._opts.sample_rate = sample_rate
            self._sample_rate = sample_rate  # keep base class property in sync
            connection_params_changed = True
        if is_given(bit_rate):
            self._opts.bit_rate = bit_rate
            connection_params_changed = True
        if is_given(speed):
            self._opts.speed = speed
            connection_params_changed = True

        if connection_params_changed:
            # These params are baked into the WebSocket URL at connection time, so any
            # existing pooled connection must be invalidated to avoid serving audio at
            # the wrong rate/encoding/speed.
            self._pool.invalidate()

    def synthesize(
        self, text: str, *, conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS
    ) -> ChunkedStreamv2:
        return ChunkedStreamv2(tts=self, input_text=text, conn_options=conn_options)

    def stream(
        self, *, conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS
    ) -> SynthesizeStreamv2:
        stream = SynthesizeStreamv2(tts=self, conn_options=conn_options)
        self._streams.add(stream)
        return stream

    def prewarm(self) -> None:
        self._pool.prewarm()

    async def aclose(self) -> None:
        for stream in list(self._streams):
            await stream.aclose()

        self._streams.clear()

        await self._pool.aclose()


class ChunkedStreamv2(tts.ChunkedStream):
    def __init__(self, *, tts: TTSv2, input_text: str, conn_options: APIConnectOptions) -> None:
        super().__init__(tts=tts, input_text=input_text, conn_options=conn_options)
        self._tts: TTSv2 = tts
        self._opts = replace(tts._opts)

    async def _run(self, output_emitter: tts.AudioEmitter) -> None:
        try:
            http_params: dict = {
                "encoding": self._opts.encoding,
                "container": "none",
                "model": self._opts.model,
                "sample_rate": self._opts.sample_rate,
                "mip_opt_out": self._opts.mip_opt_out,
            }
            if self._opts.bit_rate is not None:
                http_params["bit_rate"] = self._opts.bit_rate
            if self._opts.speed is not None:
                http_params["speed"] = self._opts.speed
            async with self._tts._ensure_session().post(
                _to_deepgram_url(http_params, self._opts.base_url, websocket=False),
                headers={
                    "Authorization": f"Token {self._opts.api_key}",
                    "Content-Type": "application/json",
                },
                json={"text": self._input_text},
                timeout=aiohttp.ClientTimeout(total=30, sock_connect=self._conn_options.timeout),
            ) as resp:
                resp.raise_for_status()

                output_emitter.initialize(
                    request_id=utils.shortuuid(),
                    sample_rate=self._opts.sample_rate,
                    num_channels=NUM_CHANNELS,
                    mime_type=_encoding_to_mimetype(self._opts.encoding),
                )

                async for data, _ in resp.content.iter_chunks():
                    output_emitter.push(data)

                output_emitter.flush()

        except asyncio.TimeoutError:
            raise APITimeoutError() from None
        except aiohttp.ClientResponseError as e:
            raise APIStatusError(
                message=e.message, status_code=e.status, request_id=None, body=None
            ) from None
        except Exception as e:
            raise APIConnectionError() from e


class SynthesizeStreamv2(tts.SynthesizeStream):
    _FLUSH_MSG: str = json.dumps({"type": "Flush"})
    _CLOSE_MSG: str = json.dumps({"type": "Close"})

    def __init__(self, *, tts: TTSv2, conn_options: APIConnectOptions):
        super().__init__(tts=tts, conn_options=conn_options)
        self._tts: TTSv2 = tts
        self._opts = replace(tts._opts)

    async def _run(self, output_emitter: tts.AudioEmitter) -> None:
        # Only linear16 is playable end-to-end through the LiveKit pipeline on the
        # streaming path. Fail fast with a clear message instead of at connect time.
        if self._opts.encoding != "linear16":
            raise ValueError(
                f"Deepgram Flux TTS streaming only supports 'linear16' encoding, got "
                f"{self._opts.encoding!r}. Use synthesize() for compressed batch output."
            )

        segments_ch = utils.aio.Chan[tokenize.WordStream]()
        request_id = utils.shortuuid()
        output_emitter.initialize(
            request_id=request_id,
            sample_rate=self._opts.sample_rate,
            num_channels=1,
            mime_type="audio/pcm",
            stream=True,
        )

        async def _tokenize_input() -> None:
            # Converts incoming text into WordStreams and sends them into segments_ch
            word_stream = None
            async for input in self._input_ch:
                if isinstance(input, str):
                    if word_stream is None:
                        word_stream = self._opts.word_tokenizer.stream()
                        segments_ch.send_nowait(word_stream)
                    word_stream.push_text(input)
                elif isinstance(input, self._FlushSentinel):
                    if word_stream:
                        word_stream.end_input()
                    word_stream = None

            segments_ch.close()

        async def _run_segments() -> None:
            async for word_stream in segments_ch:
                await self._run_ws(word_stream, output_emitter)

        tasks = [
            asyncio.create_task(_tokenize_input()),
            asyncio.create_task(_run_segments()),
        ]
        try:
            await asyncio.gather(*tasks)
        except asyncio.TimeoutError:
            raise APITimeoutError() from None
        except APIError:
            raise
        except aiohttp.ClientResponseError as e:
            raise APIStatusError(
                message=e.message, status_code=e.status, request_id=request_id, body=None
            ) from None
        except Exception as e:
            raise APIConnectionError() from e
        finally:
            await utils.aio.gracefully_cancel(*tasks)

    async def _run_ws(
        self, word_stream: tokenize.WordStream, output_emitter: tts.AudioEmitter
    ) -> None:
        segment_id = utils.shortuuid()
        output_emitter.start_segment(segment_id=segment_id)
        input_sent_event = asyncio.Event()

        async def send_task(ws: aiohttp.ClientWebSocketResponse) -> None:
            async for word in word_stream:
                speak_msg = {"type": "Speak", "text": f"{word.token} "}
                self._mark_started()
                await ws.send_str(json.dumps(speak_msg))
                input_sent_event.set()

            # always flush after a segment to end the active turn
            await ws.send_str(self._FLUSH_MSG)
            input_sent_event.set()

        async def recv_task(ws: aiohttp.ClientWebSocketResponse) -> None:
            await input_sent_event.wait()
            while True:
                msg = await ws.receive(timeout=self._conn_options.timeout)
                if msg.type in (
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.CLOSING,
                ):
                    raise APIStatusError(
                        "Deepgram websocket connection closed unexpectedly",
                        status_code=ws.close_code or -1,
                        body=f"{msg.data=} {msg.extra=}",
                    )

                if msg.type == aiohttp.WSMsgType.BINARY:
                    output_emitter.push(msg.data)
                elif msg.type == aiohttp.WSMsgType.TEXT:
                    resp = json.loads(msg.data)
                    mtype = resp.get("type")
                    # Flux server messages:
                    # https://developers.deepgram.com/docs/flux-tts/overview
                    if mtype == "SpeechMetadata":
                        # Authoritative end-of-turn marker: all audio for the turn has
                        # been sent between SpeechStarted and this message. The server
                        # emits a trailing Flushed frame after this; on a pooled reuse it
                        # is harmlessly absorbed as a no-op at the top of the next turn.
                        output_emitter.end_segment()
                        break
                    elif mtype in ("Connected", "SpeechStarted", "Flushed", "SessionMetadata"):
                        # lifecycle / telemetry messages, no audio action needed
                        pass
                    elif mtype == "Warning":
                        logger.warning(
                            "Deepgram warning: %s (code: %s)",
                            resp.get("description") or resp.get("warn_msg"),
                            resp.get("code"),
                        )
                    elif mtype in ("Error", "error"):
                        raise APIError(message="Deepgram Flux TTS returned error", body=resp)
                    else:
                        logger.warning("Unknown Deepgram message type: %s", resp)

        async with self._tts._pool.connection(timeout=self._conn_options.timeout) as ws:
            self._acquire_time = self._tts._pool.last_acquire_time
            self._connection_reused = self._tts._pool.last_connection_reused
            tasks = [
                asyncio.create_task(send_task(ws)),
                asyncio.create_task(recv_task(ws)),
            ]

            try:
                await asyncio.gather(*tasks)
            finally:
                input_sent_event.set()
                await utils.aio.gracefully_cancel(*tasks)
